--
-- PostgreSQL database dump
--

\restrict fPRxRki7NaUFuf8HGNrbQbnVm7SZArPXRn3k1R837Yb89MABXaEGftiKAPORbw6

-- Dumped from database version 17.11
-- Dumped by pg_dump version 18.7 (Ubuntu 18.7-1.pgdg26.04+5)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS "withdrawals_update_authorized" ON "public"."withdrawals";
DROP POLICY IF EXISTS "withdrawals_select_authorized" ON "public"."withdrawals";
DROP POLICY IF EXISTS "withdrawals_insert_authorized" ON "public"."withdrawals";
DROP POLICY IF EXISTS "variants_update_authorized" ON "public"."variants";
DROP POLICY IF EXISTS "variants_select_authorized" ON "public"."variants";
DROP POLICY IF EXISTS "variants_insert_authorized" ON "public"."variants";
DROP POLICY IF EXISTS "treasury_reconciliations_select_authorized" ON "public"."treasury_reconciliations";
DROP POLICY IF EXISTS "treasury_reconciliations_insert_authorized" ON "public"."treasury_reconciliations";
DROP POLICY IF EXISTS "treasury_movements_update_authorized" ON "public"."treasury_movements";
DROP POLICY IF EXISTS "treasury_movements_select_authorized" ON "public"."treasury_movements";
DROP POLICY IF EXISTS "treasury_movements_insert_authorized" ON "public"."treasury_movements";
DROP POLICY IF EXISTS "treasury_accounts_update_authorized" ON "public"."treasury_accounts";
DROP POLICY IF EXISTS "treasury_accounts_select_authorized" ON "public"."treasury_accounts";
DROP POLICY IF EXISTS "treasury_accounts_insert_authorized" ON "public"."treasury_accounts";
DROP POLICY IF EXISTS "sales_update_authorized" ON "public"."sales";
DROP POLICY IF EXISTS "sales_select_authorized" ON "public"."sales";
DROP POLICY IF EXISTS "sales_insert_authorized" ON "public"."sales";
DROP POLICY IF EXISTS "profiles_select_authorized" ON "public"."profiles";
DROP POLICY IF EXISTS "price_changes_select_authorized" ON "public"."price_changes";
DROP POLICY IF EXISTS "price_changes_insert_authorized" ON "public"."price_changes";
DROP POLICY IF EXISTS "partners_update_authorized" ON "public"."partners";
DROP POLICY IF EXISTS "partners_select_authorized" ON "public"."partners";
DROP POLICY IF EXISTS "orders_update_authorized" ON "public"."orders";
DROP POLICY IF EXISTS "orders_select_authorized" ON "public"."orders";
DROP POLICY IF EXISTS "orders_insert_authorized" ON "public"."orders";
DROP POLICY IF EXISTS "losses_update_authorized" ON "public"."losses";
DROP POLICY IF EXISTS "losses_select_authorized" ON "public"."losses";
DROP POLICY IF EXISTS "losses_insert_authorized" ON "public"."losses";
DROP POLICY IF EXISTS "items_update_authorized" ON "public"."items";
DROP POLICY IF EXISTS "items_select_authorized" ON "public"."items";
DROP POLICY IF EXISTS "items_insert_authorized" ON "public"."items";
DROP POLICY IF EXISTS "expenses_update_authorized" ON "public"."expenses";
DROP POLICY IF EXISTS "expenses_select_authorized" ON "public"."expenses";
DROP POLICY IF EXISTS "expenses_insert_authorized" ON "public"."expenses";
DROP POLICY IF EXISTS "expense_categories_update_authorized" ON "public"."expense_categories";
DROP POLICY IF EXISTS "expense_categories_select_authorized" ON "public"."expense_categories";
DROP POLICY IF EXISTS "expense_categories_insert_authorized" ON "public"."expense_categories";
DROP POLICY IF EXISTS "categories_update_authorized" ON "public"."categories";
DROP POLICY IF EXISTS "categories_select_authorized" ON "public"."categories";
DROP POLICY IF EXISTS "categories_insert_authorized" ON "public"."categories";
DROP POLICY IF EXISTS "audit_log_select_authorized" ON "public"."audit_log";
DROP POLICY IF EXISTS "app_settings_select_authorized" ON "public"."app_settings";
DROP POLICY IF EXISTS "ad_spends_update_authorized" ON "public"."ad_spends";
DROP POLICY IF EXISTS "ad_spends_select_authorized" ON "public"."ad_spends";
DROP POLICY IF EXISTS "ad_spends_insert_authorized" ON "public"."ad_spends";
ALTER TABLE IF EXISTS ONLY "public"."withdrawals" DROP CONSTRAINT IF EXISTS "withdrawals_treasury_account_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."withdrawals" DROP CONSTRAINT IF EXISTS "withdrawals_partner_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."variants" DROP CONSTRAINT IF EXISTS "variants_item_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."treasury_reconciliations" DROP CONSTRAINT IF EXISTS "treasury_reconciliations_account_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."treasury_movements" DROP CONSTRAINT IF EXISTS "treasury_movements_account_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."sales" DROP CONSTRAINT IF EXISTS "sales_variant_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."sales" DROP CONSTRAINT IF EXISTS "sales_treasury_account_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."profiles" DROP CONSTRAINT IF EXISTS "profiles_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."price_changes" DROP CONSTRAINT IF EXISTS "price_changes_variant_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."price_changes" DROP CONSTRAINT IF EXISTS "price_changes_item_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_treasury_account_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."losses" DROP CONSTRAINT IF EXISTS "losses_variant_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."items" DROP CONSTRAINT IF EXISTS "items_order_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."items" DROP CONSTRAINT IF EXISTS "items_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."expenses" DROP CONSTRAINT IF EXISTS "expenses_treasury_account_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."expenses" DROP CONSTRAINT IF EXISTS "expenses_order_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."expenses" DROP CONSTRAINT IF EXISTS "expenses_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."app_settings" DROP CONSTRAINT IF EXISTS "app_settings_updated_by_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ad_spends" DROP CONSTRAINT IF EXISTS "ad_spends_treasury_account_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ad_spends" DROP CONSTRAINT IF EXISTS "ad_spends_order_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ad_spends" DROP CONSTRAINT IF EXISTS "ad_spends_item_id_fkey";
DROP TRIGGER IF EXISTS "trg_withdrawals_updated_at" ON "public"."withdrawals";
DROP TRIGGER IF EXISTS "trg_withdrawals_treasury" ON "public"."withdrawals";
DROP TRIGGER IF EXISTS "trg_variants_updated_at" ON "public"."variants";
DROP TRIGGER IF EXISTS "trg_variants_before_update" ON "public"."variants";
DROP TRIGGER IF EXISTS "trg_treasury_movements_updated_at" ON "public"."treasury_movements";
DROP TRIGGER IF EXISTS "trg_treasury_accounts_updated_at" ON "public"."treasury_accounts";
DROP TRIGGER IF EXISTS "trg_sales_updated_at" ON "public"."sales";
DROP TRIGGER IF EXISTS "trg_sales_treasury" ON "public"."sales";
DROP TRIGGER IF EXISTS "trg_sales_before_update" ON "public"."sales";
DROP TRIGGER IF EXISTS "trg_price_changes_before_insert" ON "public"."price_changes";
DROP TRIGGER IF EXISTS "trg_partners_updated_at" ON "public"."partners";
DROP TRIGGER IF EXISTS "trg_orders_updated_at" ON "public"."orders";
DROP TRIGGER IF EXISTS "trg_orders_treasury" ON "public"."orders";
DROP TRIGGER IF EXISTS "trg_orders_reference" ON "public"."orders";
DROP TRIGGER IF EXISTS "trg_losses_updated_at" ON "public"."losses";
DROP TRIGGER IF EXISTS "trg_items_updated_at" ON "public"."items";
DROP TRIGGER IF EXISTS "trg_items_code" ON "public"."items";
DROP TRIGGER IF EXISTS "trg_items_before_update" ON "public"."items";
DROP TRIGGER IF EXISTS "trg_expenses_updated_at" ON "public"."expenses";
DROP TRIGGER IF EXISTS "trg_expenses_treasury" ON "public"."expenses";
DROP TRIGGER IF EXISTS "trg_audit_withdrawals" ON "public"."withdrawals";
DROP TRIGGER IF EXISTS "trg_audit_variants" ON "public"."variants";
DROP TRIGGER IF EXISTS "trg_audit_treasury_reconciliations" ON "public"."treasury_reconciliations";
DROP TRIGGER IF EXISTS "trg_audit_treasury_movements" ON "public"."treasury_movements";
DROP TRIGGER IF EXISTS "trg_audit_treasury_accounts" ON "public"."treasury_accounts";
DROP TRIGGER IF EXISTS "trg_audit_sales" ON "public"."sales";
DROP TRIGGER IF EXISTS "trg_audit_partners" ON "public"."partners";
DROP TRIGGER IF EXISTS "trg_audit_orders" ON "public"."orders";
DROP TRIGGER IF EXISTS "trg_audit_losses" ON "public"."losses";
DROP TRIGGER IF EXISTS "trg_audit_items" ON "public"."items";
DROP TRIGGER IF EXISTS "trg_audit_expenses" ON "public"."expenses";
DROP TRIGGER IF EXISTS "trg_audit_expense_categories" ON "public"."expense_categories";
DROP TRIGGER IF EXISTS "trg_audit_categories" ON "public"."categories";
DROP TRIGGER IF EXISTS "trg_audit_app_settings" ON "public"."app_settings";
DROP TRIGGER IF EXISTS "trg_audit_ad_spends" ON "public"."ad_spends";
DROP TRIGGER IF EXISTS "trg_ad_spends_updated_at" ON "public"."ad_spends";
DROP TRIGGER IF EXISTS "trg_ad_spends_treasury" ON "public"."ad_spends";
DROP INDEX IF EXISTS "public"."uq_variants_item_label_ci";
DROP INDEX IF EXISTS "public"."uq_treasury_movements_source";
DROP INDEX IF EXISTS "public"."uq_treasury_accounts_name_ci";
DROP INDEX IF EXISTS "public"."uq_expense_categories_name_ci";
DROP INDEX IF EXISTS "public"."uq_categories_name_ci";
DROP INDEX IF EXISTS "public"."idx_withdrawals_status";
DROP INDEX IF EXISTS "public"."idx_withdrawals_partner_id";
DROP INDEX IF EXISTS "public"."idx_withdrawals_date";
DROP INDEX IF EXISTS "public"."idx_variants_item_id";
DROP INDEX IF EXISTS "public"."idx_treasury_reconciliations_account";
DROP INDEX IF EXISTS "public"."idx_treasury_movements_status";
DROP INDEX IF EXISTS "public"."idx_treasury_movements_account_date";
DROP INDEX IF EXISTS "public"."idx_sales_variant_id";
DROP INDEX IF EXISTS "public"."idx_sales_status";
DROP INDEX IF EXISTS "public"."idx_sales_sold_at";
DROP INDEX IF EXISTS "public"."idx_price_changes_variant_id";
DROP INDEX IF EXISTS "public"."idx_price_changes_item_id";
DROP INDEX IF EXISTS "public"."idx_price_changes_changed_at";
DROP INDEX IF EXISTS "public"."idx_losses_variant_id";
DROP INDEX IF EXISTS "public"."idx_losses_status";
DROP INDEX IF EXISTS "public"."idx_items_order_id";
DROP INDEX IF EXISTS "public"."idx_items_category_id";
DROP INDEX IF EXISTS "public"."idx_expenses_status";
DROP INDEX IF EXISTS "public"."idx_expenses_order_id";
DROP INDEX IF EXISTS "public"."idx_expenses_date";
DROP INDEX IF EXISTS "public"."idx_expenses_category_id";
DROP INDEX IF EXISTS "public"."idx_audit_log_table_record";
DROP INDEX IF EXISTS "public"."idx_audit_log_changed_by";
DROP INDEX IF EXISTS "public"."idx_audit_log_changed_at";
DROP INDEX IF EXISTS "public"."idx_ad_spends_status";
DROP INDEX IF EXISTS "public"."idx_ad_spends_order_id";
DROP INDEX IF EXISTS "public"."idx_ad_spends_item_id";
DROP INDEX IF EXISTS "public"."idx_ad_spends_date";
ALTER TABLE IF EXISTS ONLY "public"."withdrawals" DROP CONSTRAINT IF EXISTS "withdrawals_pkey";
ALTER TABLE IF EXISTS ONLY "public"."variants" DROP CONSTRAINT IF EXISTS "variants_pkey";
ALTER TABLE IF EXISTS ONLY "public"."treasury_reconciliations" DROP CONSTRAINT IF EXISTS "treasury_reconciliations_pkey";
ALTER TABLE IF EXISTS ONLY "public"."treasury_movements" DROP CONSTRAINT IF EXISTS "treasury_movements_pkey";
ALTER TABLE IF EXISTS ONLY "public"."treasury_accounts" DROP CONSTRAINT IF EXISTS "treasury_accounts_pkey";
ALTER TABLE IF EXISTS ONLY "public"."sales" DROP CONSTRAINT IF EXISTS "sales_pkey";
ALTER TABLE IF EXISTS ONLY "public"."profiles" DROP CONSTRAINT IF EXISTS "profiles_pkey";
ALTER TABLE IF EXISTS ONLY "public"."price_changes" DROP CONSTRAINT IF EXISTS "price_changes_pkey";
ALTER TABLE IF EXISTS ONLY "public"."partners" DROP CONSTRAINT IF EXISTS "partners_slot_key";
ALTER TABLE IF EXISTS ONLY "public"."partners" DROP CONSTRAINT IF EXISTS "partners_pkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_reference_key";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_pkey";
ALTER TABLE IF EXISTS ONLY "public"."losses" DROP CONSTRAINT IF EXISTS "losses_pkey";
ALTER TABLE IF EXISTS ONLY "public"."items" DROP CONSTRAINT IF EXISTS "items_pkey";
ALTER TABLE IF EXISTS ONLY "public"."items" DROP CONSTRAINT IF EXISTS "items_code_key";
ALTER TABLE IF EXISTS ONLY "public"."expenses" DROP CONSTRAINT IF EXISTS "expenses_pkey";
ALTER TABLE IF EXISTS ONLY "public"."expense_categories" DROP CONSTRAINT IF EXISTS "expense_categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."categories" DROP CONSTRAINT IF EXISTS "categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."audit_log" DROP CONSTRAINT IF EXISTS "audit_log_pkey";
ALTER TABLE IF EXISTS ONLY "public"."app_settings" DROP CONSTRAINT IF EXISTS "app_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ad_spends" DROP CONSTRAINT IF EXISTS "ad_spends_pkey";
DROP TABLE IF EXISTS "public"."withdrawals";
DROP VIEW IF EXISTS "public"."v_treasury_accounts_summary";
DROP VIEW IF EXISTS "public"."v_item_net_summary";
DROP VIEW IF EXISTS "public"."v_item_summary";
DROP VIEW IF EXISTS "public"."v_item_catalog";
DROP VIEW IF EXISTS "public"."v_dormant_stock";
DROP TABLE IF EXISTS "public"."treasury_reconciliations";
DROP TABLE IF EXISTS "public"."treasury_movements";
DROP TABLE IF EXISTS "public"."treasury_accounts";
DROP TABLE IF EXISTS "public"."profiles";
DROP TABLE IF EXISTS "public"."partners";
DROP SEQUENCE IF EXISTS "public"."order_reference_seq";
DROP SEQUENCE IF EXISTS "public"."item_code_seq";
DROP VIEW IF EXISTS "public"."export_stock";
DROP VIEW IF EXISTS "public"."export_sales";
DROP VIEW IF EXISTS "public"."export_price_changes";
DROP TABLE IF EXISTS "public"."price_changes";
DROP VIEW IF EXISTS "public"."export_orders";
DROP VIEW IF EXISTS "public"."v_order_comparison";
DROP VIEW IF EXISTS "public"."v_order_net_summary";
DROP VIEW IF EXISTS "public"."v_order_summary";
DROP VIEW IF EXISTS "public"."v_sales_detail";
DROP VIEW IF EXISTS "public"."export_losses";
DROP VIEW IF EXISTS "public"."v_variant_stock";
DROP TABLE IF EXISTS "public"."variants";
DROP TABLE IF EXISTS "public"."sales";
DROP TABLE IF EXISTS "public"."losses";
DROP VIEW IF EXISTS "public"."export_expenses";
DROP VIEW IF EXISTS "public"."export_ad_spends";
DROP TABLE IF EXISTS "public"."orders";
DROP TABLE IF EXISTS "public"."items";
DROP TABLE IF EXISTS "public"."expenses";
DROP TABLE IF EXISTS "public"."expense_categories";
DROP TABLE IF EXISTS "public"."categories";
DROP TABLE IF EXISTS "public"."audit_log";
DROP TABLE IF EXISTS "public"."app_settings";
DROP TABLE IF EXISTS "public"."ad_spends";
DROP FUNCTION IF EXISTS "public"."update_item_with_variants"("p_item_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb");
DROP FUNCTION IF EXISTS "public"."transfer_treasury"("p_from_account_id" "uuid", "p_to_account_id" "uuid", "p_amount" bigint, "p_date" "date", "p_note" "text");
DROP FUNCTION IF EXISTS "public"."stats_by_month"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."stats_by_day"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."stats_by_channel"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."stats_by_category"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."save_partners"("p_name_1" "text", "p_share_1" numeric, "p_name_2" "text", "p_share_2" numeric);
DROP FUNCTION IF EXISTS "public"."rls_auto_enable"();
DROP FUNCTION IF EXISTS "public"."reconcile_treasury_account"("p_account_id" "uuid", "p_real_balance" bigint, "p_reconciled_on" "date", "p_note" "text", "p_adjust" boolean);
DROP FUNCTION IF EXISTS "public"."is_authorized_user"();
DROP FUNCTION IF EXISTS "public"."get_period_financial_summary"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."get_partners_summary"();
DROP FUNCTION IF EXISTS "public"."get_cashflow_journey"();
DROP FUNCTION IF EXISTS "public"."fn_variants_before_update"();
DROP FUNCTION IF EXISTS "public"."fn_upsert_linked_treasury_movement"("p_account_id" "uuid", "p_direction" "text", "p_amount" bigint, "p_movement_date" "date", "p_category" "text", "p_source_type" "text", "p_source_id" "uuid", "p_note" "text", "p_is_active" boolean, "p_cancel_reason" "text");
DROP FUNCTION IF EXISTS "public"."fn_sync_withdrawal_to_treasury"();
DROP FUNCTION IF EXISTS "public"."fn_sync_sale_to_treasury"();
DROP FUNCTION IF EXISTS "public"."fn_sync_order_to_treasury"();
DROP FUNCTION IF EXISTS "public"."fn_sync_expense_to_treasury"();
DROP FUNCTION IF EXISTS "public"."fn_sync_ad_spend_to_treasury"();
DROP FUNCTION IF EXISTS "public"."fn_set_updated_at"();
DROP FUNCTION IF EXISTS "public"."fn_sales_before_update"();
DROP FUNCTION IF EXISTS "public"."fn_price_changes_before_insert"();
DROP FUNCTION IF EXISTS "public"."fn_items_before_update"();
DROP FUNCTION IF EXISTS "public"."fn_get_fallback_treasury_account_id"();
DROP FUNCTION IF EXISTS "public"."fn_generate_order_reference"();
DROP FUNCTION IF EXISTS "public"."fn_generate_item_code"();
DROP FUNCTION IF EXISTS "public"."fn_audit_trigger"();
DROP FUNCTION IF EXISTS "public"."finance_stats_by_month"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."finance_stats_by_day"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."create_sale"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_sold_total" bigint, "p_channel" "text", "p_sold_at" timestamp with time zone, "p_note" "text", "p_treasury_account_id" "uuid");
DROP FUNCTION IF EXISTS "public"."create_loss"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_reason" "text", "p_occurred_on" "date", "p_note" "text");
DROP FUNCTION IF EXISTS "public"."create_item_with_variants"("p_order_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb");
DROP FUNCTION IF EXISTS "public"."compare_periods"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."change_price"("p_item_id" "uuid", "p_variant_id" "uuid", "p_new_price" bigint, "p_note" "text");
DROP FUNCTION IF EXISTS "public"."cancel_withdrawal"("p_id" "uuid", "p_reason" "text");
DROP FUNCTION IF EXISTS "public"."cancel_sale"("p_id" "uuid", "p_reason" "text");
DROP FUNCTION IF EXISTS "public"."cancel_loss"("p_id" "uuid", "p_reason" "text");
DROP FUNCTION IF EXISTS "public"."cancel_expense"("p_id" "uuid", "p_reason" "text");
DROP FUNCTION IF EXISTS "public"."cancel_ad_spend"("p_id" "uuid", "p_reason" "text");
DROP FUNCTION IF EXISTS "public"."archive_item"("p_item_id" "uuid");
DROP SCHEMA IF EXISTS "public";
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "public";


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: archive_item("uuid"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."archive_item"("p_item_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  UPDATE items
  SET archived_at = now(), updated_at = now()
  WHERE id = p_item_id AND archived_at IS NULL;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Article introuvable ou déjà archivé.';
  END IF;
END;
$$;


--
-- Name: cancel_ad_spend("uuid", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."cancel_ad_spend"("p_id" "uuid", "p_reason" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_status text;
BEGIN
  IF p_reason IS NULL OR trim(p_reason) = '' THEN
    RAISE EXCEPTION 'Le motif d''annulation de la dépense publicitaire est obligatoire.';
  END IF;

  SELECT status INTO v_status FROM ad_spends WHERE id = p_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Dépense publicitaire introuvable.';
  END IF;
  IF v_status = 'cancelled' THEN
    RAISE EXCEPTION 'Cette dépense publicitaire est déjà annulée.';
  END IF;

  UPDATE ad_spends
  SET
    status        = 'cancelled',
    cancelled_at  = now(),
    cancelled_by  = auth.uid(),
    cancel_reason = trim(p_reason),
    updated_at    = now()
  WHERE id = p_id;
END;
$$;


--
-- Name: cancel_expense("uuid", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."cancel_expense"("p_id" "uuid", "p_reason" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_status text;
BEGIN
  IF p_reason IS NULL OR trim(p_reason) = '' THEN
    RAISE EXCEPTION 'Le motif d''annulation de la dépense est obligatoire.';
  END IF;

  SELECT status INTO v_status FROM expenses WHERE id = p_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Dépense introuvable.';
  END IF;
  IF v_status = 'cancelled' THEN
    RAISE EXCEPTION 'Cette dépense est déjà annulée.';
  END IF;

  UPDATE expenses
  SET
    status        = 'cancelled',
    cancelled_at  = now(),
    cancelled_by  = auth.uid(),
    cancel_reason = trim(p_reason),
    updated_at    = now()
  WHERE id = p_id;
END;
$$;


--
-- Name: cancel_loss("uuid", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."cancel_loss"("p_id" "uuid", "p_reason" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_status text;
BEGIN
  IF p_reason IS NULL OR trim(p_reason) = '' THEN
    RAISE EXCEPTION 'Le motif d''annulation de la perte est obligatoire.';
  END IF;

  SELECT status INTO v_status
  FROM losses
  WHERE id = p_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Perte introuvable.';
  END IF;

  IF v_status = 'cancelled' THEN
    RAISE EXCEPTION 'Cette sortie en perte est déjà annulée.';
  END IF;

  UPDATE losses
  SET
    status        = 'cancelled',
    cancelled_at  = now(),
    cancelled_by  = auth.uid(),
    cancel_reason = trim(p_reason),
    updated_at    = now()
  WHERE id = p_id;
END;
$$;


--
-- Name: FUNCTION "cancel_loss"("p_id" "uuid", "p_reason" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."cancel_loss"("p_id" "uuid", "p_reason" "text") IS 'Annule une sortie en perte avec motif obligatoire. Restitue le stock.';


--
-- Name: cancel_sale("uuid", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."cancel_sale"("p_id" "uuid", "p_reason" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_status text;
BEGIN
  IF p_reason IS NULL OR trim(p_reason) = '' THEN
    RAISE EXCEPTION 'Le motif d''annulation est obligatoire.';
  END IF;

  SELECT status INTO v_status
  FROM sales
  WHERE id = p_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Vente introuvable.';
  END IF;

  IF v_status = 'cancelled' THEN
    RAISE EXCEPTION 'Cette vente est déjà annulée.';
  END IF;

  UPDATE sales
  SET
    status        = 'cancelled',
    cancelled_at  = now(),
    cancelled_by  = auth.uid(),
    cancel_reason = trim(p_reason),
    updated_at    = now()
  WHERE id = p_id;
END;
$$;


--
-- Name: FUNCTION "cancel_sale"("p_id" "uuid", "p_reason" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."cancel_sale"("p_id" "uuid", "p_reason" "text") IS 'Annule une vente de manière irréversible avec motif obligatoire. Le stock est restitué automatiquement.';


--
-- Name: cancel_withdrawal("uuid", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."cancel_withdrawal"("p_id" "uuid", "p_reason" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_status text;
BEGIN
  IF p_reason IS NULL OR trim(p_reason) = '' THEN
    RAISE EXCEPTION 'Le motif d''annulation est obligatoire.';
  END IF;

  SELECT status INTO v_status FROM withdrawals WHERE id = p_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Opération introuvable.';
  END IF;
  IF v_status = 'cancelled' THEN
    RAISE EXCEPTION 'Cette opération est déjà annulée.';
  END IF;

  UPDATE withdrawals
  SET
    status        = 'cancelled',
    cancelled_at  = now(),
    cancelled_by  = auth.uid(),
    cancel_reason = trim(p_reason),
    updated_at    = now()
  WHERE id = p_id;
END;
$$;


--
-- Name: change_price("uuid", "uuid", bigint, "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."change_price"("p_item_id" "uuid", "p_variant_id" "uuid" DEFAULT NULL::"uuid", "p_new_price" bigint DEFAULT NULL::bigint, "p_note" "text" DEFAULT NULL::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_old_price   bigint;
  v_change_type text;
BEGIN
  IF p_new_price IS NULL OR p_new_price < 0 THEN
    RAISE EXCEPTION 'Le nouveau prix doit être un entier positif ou nul.';
  END IF;

  -- Déverrouillage éphémère de la modification de prix pour la transaction courante (B7)
  PERFORM set_config('app.allow_price_change', 'on', true);

  IF p_variant_id IS NOT NULL THEN
    -- Cas d'une variante spécifique : vérification d'existence, appartenance et verrouillage (Point 1)
    SELECT coalesce(v.price_override, i.list_price)
    INTO v_old_price
    FROM variants v
    JOIN items i ON i.id = v.item_id
    WHERE v.id = p_variant_id AND v.item_id = p_item_id
    FOR UPDATE OF v;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Variante introuvable pour cet article.';
    END IF;

    -- Contrôle du prix identique (Point mineur)
    IF p_new_price = v_old_price THEN
      RAISE EXCEPTION 'Le nouveau prix (%) est identique au prix actuel.', p_new_price;
    ELSIF p_new_price < v_old_price THEN
      v_change_type := 'markdown';
    ELSE
      v_change_type := 'increase';
    END IF;

    UPDATE variants
    SET price_override = p_new_price,
        updated_at     = now()
    WHERE id = p_variant_id;

    INSERT INTO price_changes (
      item_id,
      variant_id,
      old_price,
      new_price,
      change_type,
      note,
      changed_by
    ) VALUES (
      p_item_id,
      p_variant_id,
      v_old_price,
      p_new_price,
      v_change_type,
      p_note,
      auth.uid()
    );

  ELSE
    -- Cas de l'article global
    SELECT list_price
    INTO v_old_price
    FROM items
    WHERE id = p_item_id
    FOR UPDATE;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Article introuvable.';
    END IF;

    -- Contrôle du prix identique (Point mineur)
    IF p_new_price = v_old_price THEN
      RAISE EXCEPTION 'Le nouveau prix (%) est identique au prix actuel.', p_new_price;
    ELSIF p_new_price < v_old_price THEN
      v_change_type := 'markdown';
    ELSE
      v_change_type := 'increase';
    END IF;

    UPDATE items
    SET list_price = p_new_price,
        updated_at = now()
    WHERE id = p_item_id;

    INSERT INTO price_changes (
      item_id,
      variant_id,
      old_price,
      new_price,
      change_type,
      note,
      changed_by
    ) VALUES (
      p_item_id,
      NULL,
      v_old_price,
      p_new_price,
      v_change_type,
      p_note,
      auth.uid()
    );
  END IF;
END;
$$;


--
-- Name: FUNCTION "change_price"("p_item_id" "uuid", "p_variant_id" "uuid", "p_new_price" bigint, "p_note" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."change_price"("p_item_id" "uuid", "p_variant_id" "uuid", "p_new_price" bigint, "p_note" "text") IS 'Modifie le prix d''un article ou d''une variante et consigne la modification dans price_changes.';


--
-- Name: compare_periods("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."compare_periods"("p_from" "date", "p_to" "date") RETURNS TABLE("period_key" "text", "date_from" "date", "date_to" "date", "collected_total" bigint, "realized_margin" bigint, "ad_spends_total" bigint, "expenses_total" bigint, "net_profit" bigint, "sales_count" bigint, "sold_units" bigint)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_is_month_start boolean;
  v_prev_from      date;
  v_prev_to        date;
  v_yoy_from       date;
  v_yoy_to         date;
  v_days_span      int;
BEGIN
  v_is_month_start := (date_trunc('month', p_from::timestamp)::date = p_from);
  v_days_span := greatest(0, (p_to - p_from));

  IF v_is_month_start AND (p_to = (date_trunc('month', p_from::timestamp) + interval '1 month - 1 day')::date OR p_to >= p_from) THEN
    -- Si la période commence le 1er du mois : comparer à mois - 1 (même nombre de jours ou mois complet)
    v_prev_from := (p_from - interval '1 month')::date;
    IF p_to = (date_trunc('month', p_from::timestamp) + interval '1 month - 1 day')::date THEN
      v_prev_to := (date_trunc('month', v_prev_from::timestamp) + interval '1 month - 1 day')::date;
    ELSE
      v_prev_to := least(
        (date_trunc('month', v_prev_from::timestamp) + interval '1 month - 1 day')::date,
        (v_prev_from + v_days_span)
      );
    END IF;
  ELSE
    v_prev_to   := p_from - 1;
    v_prev_from := v_prev_to - v_days_span;
  END IF;

  v_yoy_from := (p_from - interval '1 year')::date;
  v_yoy_to   := (p_to - interval '1 year')::date;

  RETURN QUERY
  SELECT 'current'::text, p_from, p_to,
    f.collected_total, f.realized_margin, f.ad_spends_total, f.expenses_total, f.net_profit, f.sales_count, f.sold_units
  FROM get_period_financial_summary(p_from, p_to) f
  UNION ALL
  SELECT 'previous'::text, v_prev_from, v_prev_to,
    f.collected_total, f.realized_margin, f.ad_spends_total, f.expenses_total, f.net_profit, f.sales_count, f.sold_units
  FROM get_period_financial_summary(v_prev_from, v_prev_to) f
  UNION ALL
  SELECT 'last_year'::text, v_yoy_from, v_yoy_to,
    f.collected_total, f.realized_margin, f.ad_spends_total, f.expenses_total, f.net_profit, f.sales_count, f.sold_units
  FROM get_period_financial_summary(v_yoy_from, v_yoy_to) f;
END;
$$;


--
-- Name: create_item_with_variants("uuid", "text", bigint, bigint, "uuid", "text", "text", "text", "jsonb"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."create_item_with_variants"("p_order_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint DEFAULT NULL::bigint, "p_category_id" "uuid" DEFAULT NULL::"uuid", "p_description" "text" DEFAULT NULL::"text", "p_photo_url" "text" DEFAULT NULL::"text", "p_photo_public_id" "text" DEFAULT NULL::"text", "p_variants" "jsonb" DEFAULT '[]'::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_item_id         uuid;
  v_item_code       text;
  v_order_status    text;
  v_received_date   date;
  v_var_elem        jsonb;
  v_var_id          uuid;
  v_var_label       text;
  v_var_rec         int;
  v_var_dam         int;
  v_var_ord         int;
  v_var_ovr         bigint;
  v_var_photo_url   text;
  v_var_photo_pid   text;
  v_created_var_ids uuid[] := '{}';
BEGIN
  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'Le nom de l''article est obligatoire.';
  END IF;

  IF p_list_price IS NULL OR p_list_price < 0 THEN
    RAISE EXCEPTION 'Le prix fixé doit être un entier positif ou nul.';
  END IF;

  IF p_unit_cost IS NOT NULL AND p_unit_cost < 0 THEN
    RAISE EXCEPTION 'Le coût unitaire ne peut pas être négatif.';
  END IF;

  -- Vérification de la commande d'origine et statut 'received' requis (Point 2)
  SELECT status, received_date
  INTO v_order_status, v_received_date
  FROM orders
  WHERE id = p_order_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Commande d''origine introuvable.';
  END IF;

  IF v_order_status <> 'received' OR v_received_date IS NULL THEN
    RAISE EXCEPTION 'Impossible de créer un article : la commande n''est pas encore reçue.';
  END IF;

  -- Au moins une variante avec sa quantité reçue est obligatoire (Point 3)
  IF p_variants IS NULL OR jsonb_array_length(p_variants) = 0 THEN
    RAISE EXCEPTION 'Au moins une variante avec sa quantité reçue est obligatoire.';
  END IF;

  -- Autorise l'enregistrement du prix initial dans price_changes pour cette transaction.
  PERFORM set_config('app.allow_price_change', 'on', true);

  -- Création de l'article (initial_price = list_price)
  v_item_id := gen_random_uuid();

  INSERT INTO items (
    id,
    order_id,
    category_id,
    name,
    description,
    photo_url,
    photo_public_id,
    list_price,
    initial_price,
    unit_cost,
    received_date,
    created_by
  ) VALUES (
    v_item_id,
    p_order_id,
    p_category_id,
    trim(p_name),
    p_description,
    p_photo_url,
    p_photo_public_id,
    p_list_price,
    p_list_price,
    p_unit_cost,
    v_received_date,
    auth.uid()
  )
  RETURNING code INTO v_item_code;

  -- Enregistrement du prix initial dans price_changes (§7.2)
  INSERT INTO price_changes (
    item_id,
    variant_id,
    old_price,
    new_price,
    change_type,
    note,
    changed_by
  ) VALUES (
    v_item_id,
    NULL,
    NULL,
    p_list_price,
    'initial',
    'Création de l''article',
    auth.uid()
  );

  -- Création des variantes fournies
  FOR v_var_elem IN SELECT * FROM jsonb_array_elements(p_variants)
  LOOP
    v_var_label     := coalesce(v_var_elem ->> 'label', 'Unique');
    v_var_rec       := coalesce((v_var_elem ->> 'quantity_received')::int, 0);
    v_var_dam       := coalesce((v_var_elem ->> 'quantity_damaged')::int, 0);
    v_var_ord       := (v_var_elem ->> 'quantity_ordered')::int;
    v_var_ovr       := (v_var_elem ->> 'price_override')::bigint;
    v_var_photo_url := v_var_elem ->> 'photo_url';
    v_var_photo_pid := v_var_elem ->> 'photo_public_id';

    IF v_var_rec < 0 THEN
      RAISE EXCEPTION 'La quantité reçue pour la variante "%" ne peut pas être négative.', v_var_label;
    END IF;

    IF v_var_dam < 0 THEN
      RAISE EXCEPTION 'La quantité abîmée pour la variante "%" ne peut pas être négative.', v_var_label;
    END IF;

    IF v_var_dam > v_var_rec THEN
      RAISE EXCEPTION 'La quantité abîmée (%) ne peut pas dépasser la quantité reçue (%) pour la variante "%".',
        v_var_dam, v_var_rec, v_var_label;
    END IF;

    INSERT INTO variants (
      item_id,
      label,
      photo_url,
      photo_public_id,
      price_override,
      quantity_ordered,
      quantity_received,
      quantity_damaged,
      created_by
    ) VALUES (
      v_item_id,
      v_var_label,
      v_var_photo_url,
      v_var_photo_pid,
      v_var_ovr,
      v_var_ord,
      v_var_rec,
      v_var_dam,
      auth.uid()
    )
    RETURNING id INTO v_var_id;

    v_created_var_ids := array_append(v_created_var_ids, v_var_id);

    IF v_var_ovr IS NOT NULL THEN
      INSERT INTO price_changes (
        item_id,
        variant_id,
        old_price,
        new_price,
        change_type,
        note,
        changed_by
      ) VALUES (
        v_item_id,
        v_var_id,
        NULL,
        v_var_ovr,
        'initial',
        'Prix spécifique initial de la variante',
        auth.uid()
      );
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'item_id', v_item_id,
    'code', v_item_code,
    'variant_ids', to_jsonb(v_created_var_ids)
  );
END;
$$;


--
-- Name: FUNCTION "create_item_with_variants"("p_order_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."create_item_with_variants"("p_order_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb") IS 'Crée un article et ses variantes en une seule transaction atomique. Contrat : exige au moins une variante avec sa quantité reçue.';


--
-- Name: create_loss("uuid", "uuid", integer, "text", "date", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."create_loss"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_reason" "text", "p_occurred_on" "date" DEFAULT CURRENT_DATE, "p_note" "text" DEFAULT NULL::"text") RETURNS "uuid"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_loss_id      uuid;
  v_qty_received int;
  v_qty_damaged  int;
  v_sold         bigint;
  v_lost         bigint;
  v_vendable     bigint;
  v_stock        bigint;
BEGIN
  IF p_quantity IS NULL OR p_quantity <= 0 THEN
    RAISE EXCEPTION 'La quantité sortie en perte doit être strictement positive.';
  END IF;

  IF p_reason IS NULL OR p_reason NOT IN ('damaged', 'unsellable', 'gift', 'lost', 'other') THEN
    RAISE EXCEPTION 'Motif de perte invalide : %.', p_reason;
  END IF;

  SELECT quantity_received, quantity_damaged
  INTO v_qty_received, v_qty_damaged
  FROM variants
  WHERE id = p_variant_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Variante introuvable.';
  END IF;

  v_vendable := v_qty_received - v_qty_damaged;

  SELECT coalesce(sum(quantity), 0)
  INTO v_sold
  FROM sales
  WHERE variant_id = p_variant_id AND status = 'active';

  SELECT coalesce(sum(quantity), 0)
  INTO v_lost
  FROM losses
  WHERE variant_id = p_variant_id AND status = 'active';

  v_stock := v_vendable - v_sold - v_lost;

  IF v_stock < p_quantity THEN
    RAISE EXCEPTION 'Stock insuffisant pour enregistrer cette perte : % disponible(s), % demandée(s).',
      v_stock, p_quantity;
  END IF;

  v_loss_id := coalesce(p_id, gen_random_uuid());

  INSERT INTO losses (
    id,
    variant_id,
    quantity,
    reason,
    occurred_on,
    note,
    status,
    created_by
  ) VALUES (
    v_loss_id,
    p_variant_id,
    p_quantity,
    p_reason,
    coalesce(p_occurred_on, CURRENT_DATE),
    p_note,
    'active',
    auth.uid()
  );

  RETURN v_loss_id;
END;
$$;


--
-- Name: FUNCTION "create_loss"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_reason" "text", "p_occurred_on" "date", "p_note" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."create_loss"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_reason" "text", "p_occurred_on" "date", "p_note" "text") IS 'Enregistre une sortie en perte après vérification du stock disponible.';


--
-- Name: create_sale("uuid", "uuid", integer, bigint, "text", timestamp with time zone, "text", "uuid"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."create_sale"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_sold_total" bigint, "p_channel" "text" DEFAULT NULL::"text", "p_sold_at" timestamp with time zone DEFAULT "now"(), "p_note" "text" DEFAULT NULL::"text", "p_treasury_account_id" "uuid" DEFAULT NULL::"uuid") RETURNS "uuid"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_sale_id         uuid;
  v_order_status    text;
  v_item_list_price bigint;
  v_var_price_ovr   bigint;
  v_qty_received    int;
  v_qty_damaged     int;
  v_sold            bigint;
  v_lost            bigint;
  v_vendable        bigint;
  v_stock           bigint;
  v_unit_list_price bigint;
  v_acc_id          uuid;
BEGIN
  -- Idempotence si l'UUID client existe déjà
  IF p_id IS NOT NULL AND EXISTS (SELECT 1 FROM sales WHERE id = p_id) THEN
    RETURN p_id;
  END IF;

  IF p_quantity IS NULL OR p_quantity <= 0 THEN
    RAISE EXCEPTION 'La quantité vendue doit être strictement positive.';
  END IF;

  IF p_sold_total IS NULL OR p_sold_total <= 0 THEN
    RAISE EXCEPTION 'Le montant encaissé doit être strictement positif.';
  END IF;

  IF p_channel IS NOT NULL AND p_channel NOT IN ('facebook', 'whatsapp', 'direct', 'other') THEN
    RAISE EXCEPTION 'Canal de vente invalide : %.', p_channel;
  END IF;

  SELECT
    o.status,
    i.list_price,
    v.price_override,
    v.quantity_received,
    v.quantity_damaged
  INTO
    v_order_status,
    v_item_list_price,
    v_var_price_ovr,
    v_qty_received,
    v_qty_damaged
  FROM variants v
  JOIN items i ON i.id = v.item_id
  JOIN orders o ON o.id = i.order_id
  WHERE v.id = p_variant_id
  FOR UPDATE OF v;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Variante introuvable.';
  END IF;

  IF v_order_status <> 'received' THEN
    RAISE EXCEPTION 'Vente impossible : la commande associée n''est pas encore reçue.';
  END IF;

  v_vendable := v_qty_received - v_qty_damaged;

  SELECT coalesce(sum(quantity), 0) INTO v_sold
  FROM sales WHERE variant_id = p_variant_id AND status = 'active';

  SELECT coalesce(sum(quantity), 0) INTO v_lost
  FROM losses WHERE variant_id = p_variant_id AND status = 'active';

  v_stock := v_vendable - v_sold - v_lost;

  IF v_stock < p_quantity THEN
    RAISE EXCEPTION 'Stock insuffisant : % pièce(s) disponible(s), % demandée(s).', v_stock, p_quantity;
  END IF;

  v_unit_list_price := coalesce(v_var_price_ovr, v_item_list_price);
  v_sale_id := coalesce(p_id, gen_random_uuid());
  v_acc_id := coalesce(
    p_treasury_account_id,
    (SELECT id FROM treasury_accounts WHERE archived_at IS NULL AND account_type = 'cash' ORDER BY created_at ASC LIMIT 1),
    fn_get_fallback_treasury_account_id()
  );

  INSERT INTO sales (
    id, variant_id, quantity, list_price_unit, sold_total,
    channel, sold_at, note, status, treasury_account_id, created_by
  ) VALUES (
    v_sale_id, p_variant_id, p_quantity, v_unit_list_price, p_sold_total,
    p_channel, coalesce(p_sold_at, now()), p_note, 'active', v_acc_id, auth.uid()
  );

  RETURN v_sale_id;
END;
$$;


--
-- Name: finance_stats_by_day("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."finance_stats_by_day"("p_from" "date", "p_to" "date") RETURNS TABLE("stat_date" "date", "collected_total" bigint, "realized_margin" bigint, "ad_spends_total" bigint, "expenses_total" bigint, "net_profit" bigint, "discounts_total" bigint, "lost_value" bigint, "sales_count" bigint, "sold_units" bigint, "lost_units" bigint)
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  RETURN QUERY
  WITH base AS (
    SELECT * FROM stats_by_day(p_from, p_to)
  ),
  daily_ads AS (
    SELECT spend_date AS d, coalesce(sum(amount), 0)::bigint AS total
    FROM ad_spends
    WHERE status = 'active' AND spend_date >= p_from AND spend_date <= p_to
    GROUP BY spend_date
  ),
  daily_exp AS (
    SELECT expense_date AS d, coalesce(sum(amount), 0)::bigint AS total
    FROM expenses
    WHERE status = 'active' AND expense_date >= p_from AND expense_date <= p_to
    GROUP BY expense_date
  )
  SELECT
    b.stat_date,
    b.collected_total,
    b.realized_margin,
    coalesce(da.total, 0)::bigint AS ad_spends_total,
    coalesce(de.total, 0)::bigint AS expenses_total,
    (b.realized_margin - coalesce(da.total, 0) - coalesce(de.total, 0))::bigint AS net_profit,
    b.discounts_total,
    b.lost_value,
    b.sales_count,
    b.sold_units,
    b.lost_units
  FROM base b
  LEFT JOIN daily_ads da ON da.d = b.stat_date
  LEFT JOIN daily_exp de ON de.d = b.stat_date
  ORDER BY b.stat_date ASC;
END;
$$;


--
-- Name: finance_stats_by_month("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."finance_stats_by_month"("p_from" "date", "p_to" "date") RETURNS TABLE("stat_month" "text", "month_start" "date", "collected_total" bigint, "realized_margin" bigint, "ad_spends_total" bigint, "expenses_total" bigint, "net_profit" bigint, "discounts_total" bigint, "lost_value" bigint, "sales_count" bigint, "sold_units" bigint, "lost_units" bigint)
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  RETURN QUERY
  WITH base AS (
    SELECT * FROM stats_by_month(p_from, p_to)
  ),
  monthly_ads AS (
    SELECT date_trunc('month', spend_date::timestamp)::date AS m, coalesce(sum(amount), 0)::bigint AS total
    FROM ad_spends
    WHERE status = 'active' AND spend_date >= p_from AND spend_date <= p_to
    GROUP BY date_trunc('month', spend_date::timestamp)::date
  ),
  monthly_exp AS (
    SELECT date_trunc('month', expense_date::timestamp)::date AS m, coalesce(sum(amount), 0)::bigint AS total
    FROM expenses
    WHERE status = 'active' AND expense_date >= p_from AND expense_date <= p_to
    GROUP BY date_trunc('month', expense_date::timestamp)::date
  )
  SELECT
    b.stat_month,
    b.month_start,
    b.collected_total,
    b.realized_margin,
    coalesce(ma.total, 0)::bigint AS ad_spends_total,
    coalesce(me.total, 0)::bigint AS expenses_total,
    (b.realized_margin - coalesce(ma.total, 0) - coalesce(me.total, 0))::bigint AS net_profit,
    b.discounts_total,
    b.lost_value,
    b.sales_count,
    b.sold_units,
    b.lost_units
  FROM base b
  LEFT JOIN monthly_ads ma ON ma.m = b.month_start
  LEFT JOIN monthly_exp me ON me.m = b.month_start
  ORDER BY b.month_start ASC;
END;
$$;


--
-- Name: fn_audit_trigger(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_audit_trigger"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'pg_temp'
    AS $$
DECLARE
  v_rec_id uuid;
  v_old_json jsonb;
  v_new_json jsonb;
  v_changed_fields text[] := '{}';
  v_key text;
  v_old_val jsonb;
  v_new_val jsonb;
  v_user_id uuid;
BEGIN
  v_user_id := auth.uid();

  IF TG_OP = 'INSERT' THEN
    IF TG_TABLE_NAME = 'app_settings' THEN
      v_rec_id := '00000000-0000-0000-0000-000000000001'::uuid;
    ELSE
      v_rec_id := NEW.id;
    END IF;

    v_new_json := to_jsonb(NEW);

    INSERT INTO audit_log (
      table_name,
      record_id,
      action,
      old_data,
      new_data,
      changed_fields,
      changed_by,
      changed_at
    ) VALUES (
      TG_TABLE_NAME,
      v_rec_id,
      'INSERT',
      NULL,
      v_new_json,
      NULL,
      v_user_id,
      now()
    );

    RETURN NEW;

  ELSIF TG_OP = 'UPDATE' THEN
    IF TG_TABLE_NAME = 'app_settings' THEN
      v_rec_id := '00000000-0000-0000-0000-000000000001'::uuid;
    ELSE
      v_rec_id := NEW.id;
    END IF;

    v_old_json := to_jsonb(OLD);
    v_new_json := to_jsonb(NEW);

    -- Identification des champs modifiés en excluant les colonnes techniques
    FOR v_key IN SELECT jsonb_object_keys(v_new_json)
    LOOP
      IF v_key NOT IN ('updated_at', 'created_at', 'created_by') THEN
        v_old_val := v_old_json -> v_key;
        v_new_val := v_new_json -> v_key;
        IF v_old_val IS DISTINCT FROM v_new_val THEN
          v_changed_fields := array_append(v_changed_fields, v_key);
        END IF;
      END IF;
    END LOOP;

    -- Si seuls des champs techniques ont changé, on ne génère pas de bruit dans l'audit
    IF cardinality(v_changed_fields) > 0 THEN
      INSERT INTO audit_log (
        table_name,
        record_id,
        action,
        old_data,
        new_data,
        changed_fields,
        changed_by,
        changed_at
      ) VALUES (
        TG_TABLE_NAME,
        v_rec_id,
        'UPDATE',
        v_old_json,
        v_new_json,
        v_changed_fields,
        v_user_id,
        now()
      );
    END IF;

    RETURN NEW;
  END IF;

  RETURN NULL;
END;
$$;


--
-- Name: FUNCTION "fn_audit_trigger"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."fn_audit_trigger"() IS 'Trigger générique d''audit (§7.5). Snapshot complet old/new en JSONB, exclusion des colonnes techniques de changed_fields (B5).';


--
-- Name: fn_generate_item_code(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_generate_item_code"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_num bigint;
BEGIN
  IF NEW.code IS NULL OR trim(NEW.code) = '' THEN
    v_num := nextval('item_code_seq');
    IF v_num < 10000 THEN
      NEW.code := 'ART-' || lpad(v_num::text, 4, '0');
    ELSE
      NEW.code := 'ART-' || v_num::text;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION "fn_generate_item_code"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."fn_generate_item_code"() IS 'Génère automatiquement le code article ART-0001 (LPAD adaptatif sans troncature).';


--
-- Name: fn_generate_order_reference(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_generate_order_reference"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_num bigint;
BEGIN
  IF NEW.reference IS NULL OR trim(NEW.reference) = '' THEN
    v_num := nextval('order_reference_seq');
    IF v_num < 1000 THEN
      NEW.reference := 'CH-' || lpad(v_num::text, 3, '0');
    ELSE
      NEW.reference := 'CH-' || v_num::text;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION "fn_generate_order_reference"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."fn_generate_order_reference"() IS 'Génère automatiquement la référence CH-001 (LPAD adaptatif sans troncature).';


--
-- Name: fn_get_fallback_treasury_account_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_get_fallback_treasury_account_id"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  SELECT id FROM treasury_accounts
  WHERE account_type = 'history'
  ORDER BY created_at ASC
  LIMIT 1;
$$;


--
-- Name: fn_items_before_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_items_before_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  -- Immuabilité absolue du prix initial fixé à la création (§7.2)
  IF OLD.initial_price IS DISTINCT FROM NEW.initial_price THEN
    RAISE EXCEPTION 'Le prix initial d''un article est immuable.';
  END IF;

  -- Protection contre modification directe de list_price (B7)
  IF OLD.list_price IS DISTINCT FROM NEW.list_price THEN
    IF coalesce(current_setting('app.allow_price_change', true), 'off') <> 'on' THEN
      RAISE EXCEPTION 'Modification directe du prix interdite. Utilisez la fonction change_price().';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: fn_price_changes_before_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_price_changes_before_insert"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF coalesce(current_setting('app.allow_price_change', true), 'off') <> 'on' THEN
    RAISE EXCEPTION 'Insertion directe dans price_changes interdite. Utilisez les fonctions métier autorisées.';
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: fn_sales_before_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_sales_before_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_qty_received int;
  v_qty_damaged  int;
  v_sold_others  bigint;
  v_lost         bigint;
  v_available    bigint;
BEGIN
  -- 1. Une vente annulée est immuable
  IF OLD.status = 'cancelled' THEN
    RAISE EXCEPTION 'Une vente annulée ne peut plus être modifiée.';
  END IF;

  -- 2. Empêcher la modification des références figées lors de la vente
  IF NEW.variant_id IS DISTINCT FROM OLD.variant_id THEN
    RAISE EXCEPTION 'La variante d''une vente enregistrée ne peut pas être modifiée.';
  END IF;

  IF NEW.list_price_unit IS DISTINCT FROM OLD.list_price_unit THEN
    RAISE EXCEPTION 'Le prix unitaire figé d''une vente ne peut pas être modifié.';
  END IF;

  -- 3. Si la quantité augmente sur une vente active, verrouiller la variante et vérifier le stock
  IF NEW.status = 'active' AND NEW.quantity > OLD.quantity THEN
    SELECT quantity_received, quantity_damaged
    INTO v_qty_received, v_qty_damaged
    FROM variants
    WHERE id = NEW.variant_id
    FOR UPDATE;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Variante introuvable.';
    END IF;

    SELECT coalesce(sum(quantity), 0)
    INTO v_sold_others
    FROM sales
    WHERE variant_id = NEW.variant_id
      AND status = 'active'
      AND id <> NEW.id;

    SELECT coalesce(sum(quantity), 0)
    INTO v_lost
    FROM losses
    WHERE variant_id = NEW.variant_id
      AND status = 'active';

    v_available := (v_qty_received - v_qty_damaged) - v_sold_others - v_lost;

    IF v_available < NEW.quantity THEN
      RAISE EXCEPTION 'Stock insuffisant : % pièce(s) disponible(s) au total pour cette vente, % demandée(s).',
        v_available, NEW.quantity;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: fn_set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_set_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION "fn_set_updated_at"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."fn_set_updated_at"() IS 'Trigger générique : positionne updated_at = now() avant chaque UPDATE.';


--
-- Name: fn_sync_ad_spend_to_treasury(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_sync_ad_spend_to_treasury"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  PERFORM fn_upsert_linked_treasury_movement(
    NEW.treasury_account_id,
    'out',
    NEW.amount,
    NEW.spend_date,
    'ad_spend',
    'ad_spend',
    NEW.id,
    'Publicité ' || initcap(coalesce(NEW.platform, 'facebook')) || coalesce(' · ' || nullif(trim(coalesce(NEW.note, '')), ''), ''),
    (NEW.status = 'active'),
    NEW.cancel_reason
  );
  RETURN NEW;
END;
$$;


--
-- Name: fn_sync_expense_to_treasury(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_sync_expense_to_treasury"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  PERFORM fn_upsert_linked_treasury_movement(
    NEW.treasury_account_id,
    'out',
    NEW.amount,
    NEW.expense_date,
    'expense',
    'expense',
    NEW.id,
    NEW.description,
    (NEW.status = 'active'),
    NEW.cancel_reason
  );
  RETURN NEW;
END;
$$;


--
-- Name: fn_sync_order_to_treasury(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_sync_order_to_treasury"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  PERFORM fn_upsert_linked_treasury_movement(
    NEW.treasury_account_id,
    'out',
    NEW.total_cost,
    NEW.order_date,
    'order',
    'order',
    NEW.id,
    'Commande ' || NEW.reference || ' (' || NEW.supplier || ')',
    (NEW.archived_at IS NULL AND NEW.total_cost > 0),
    CASE WHEN NEW.archived_at IS NOT NULL THEN 'Commande archivée' ELSE 'Coût total nul' END
  );
  RETURN NEW;
END;
$$;


--
-- Name: fn_sync_sale_to_treasury(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_sync_sale_to_treasury"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_tz text;
  v_date date;
BEGIN
  SELECT timezone INTO v_tz FROM app_settings LIMIT 1;
  v_tz := coalesce(v_tz, 'UTC');
  v_date := (NEW.sold_at AT TIME ZONE v_tz)::date;

  PERFORM fn_upsert_linked_treasury_movement(
    NEW.treasury_account_id,
    'in',
    NEW.sold_total,
    v_date,
    'sale',
    'sale',
    NEW.id,
    coalesce(nullif(trim(coalesce(NEW.note, '')), ''), 'Encaissement vente'),
    (NEW.status = 'active'),
    NEW.cancel_reason
  );
  RETURN NEW;
END;
$$;


--
-- Name: fn_sync_withdrawal_to_treasury(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_sync_withdrawal_to_treasury"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_partner_name text;
BEGIN
  SELECT name INTO v_partner_name FROM partners WHERE id = NEW.partner_id;

  PERFORM fn_upsert_linked_treasury_movement(
    NEW.treasury_account_id,
    CASE WHEN NEW.type = 'contribution' THEN 'in' ELSE 'out' END,
    NEW.amount,
    NEW.occurred_on,
    NEW.type,
    'withdrawal',
    NEW.id,
    coalesce(v_partner_name, 'Associé') || ' · ' || NEW.reason_note,
    (NEW.status = 'active'),
    NEW.cancel_reason
  );
  RETURN NEW;
END;
$$;


--
-- Name: fn_upsert_linked_treasury_movement("uuid", "text", bigint, "date", "text", "text", "uuid", "text", boolean, "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_upsert_linked_treasury_movement"("p_account_id" "uuid", "p_direction" "text", "p_amount" bigint, "p_movement_date" "date", "p_category" "text", "p_source_type" "text", "p_source_id" "uuid", "p_note" "text", "p_is_active" boolean, "p_cancel_reason" "text" DEFAULT NULL::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_acc_id uuid;
BEGIN
  v_acc_id := coalesce(p_account_id, fn_get_fallback_treasury_account_id());
  IF v_acc_id IS NULL THEN
    RETURN;
  END IF;

  IF NOT p_is_active OR coalesce(p_amount, 0) <= 0 THEN
    UPDATE treasury_movements
    SET
      status        = 'cancelled',
      cancelled_at  = coalesce(cancelled_at, now()),
      cancel_reason = coalesce(nullif(trim(coalesce(p_cancel_reason, '')), ''), 'Opération annulée ou montant nul'),
      updated_at    = now()
    WHERE source_type = p_source_type
      AND source_id = p_source_id
      AND status = 'active';
    RETURN;
  END IF;

  INSERT INTO treasury_movements (
    account_id, direction, amount, movement_date, category,
    source_type, source_id, note, status, created_by
  ) VALUES (
    v_acc_id, p_direction, p_amount, p_movement_date, p_category,
    p_source_type, p_source_id, p_note, 'active', auth.uid()
  )
  ON CONFLICT (source_type, source_id)
  WHERE source_type IS NOT NULL AND source_id IS NOT NULL
  DO UPDATE SET
    account_id    = EXCLUDED.account_id,
    direction     = EXCLUDED.direction,
    amount        = EXCLUDED.amount,
    movement_date = EXCLUDED.movement_date,
    category      = EXCLUDED.category,
    note          = EXCLUDED.note,
    status        = 'active',
    cancelled_at  = NULL,
    cancel_reason = NULL,
    updated_at    = now();
END;
$$;


--
-- Name: fn_variants_before_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_variants_before_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_sold bigint;
  v_lost bigint;
  v_new_vendable bigint;
BEGIN
  -- Protection contre modification directe de price_override (B7)
  IF OLD.price_override IS DISTINCT FROM NEW.price_override THEN
    IF coalesce(current_setting('app.allow_price_change', true), 'off') <> 'on' THEN
      RAISE EXCEPTION 'Modification directe du prix de variante interdite. Utilisez la fonction change_price().';
    END IF;
  END IF;

  -- Décision B8 : Empêcher toute baisse de stock rendant le solde disponible négatif
  -- Formule validée : quantity_received - quantity_damaged >= Σ(ventes actives) + Σ(pertes actives)
  IF (OLD.quantity_received IS DISTINCT FROM NEW.quantity_received)
     OR (OLD.quantity_damaged IS DISTINCT FROM NEW.quantity_damaged) THEN

    SELECT coalesce(sum(quantity), 0)
    INTO v_sold
    FROM sales
    WHERE variant_id = NEW.id AND status = 'active';

    SELECT coalesce(sum(quantity), 0)
    INTO v_lost
    FROM losses
    WHERE variant_id = NEW.id AND status = 'active';

    v_new_vendable := NEW.quantity_received - NEW.quantity_damaged;

    IF v_new_vendable < (v_sold + v_lost) THEN
      RAISE EXCEPTION 'Stock insuffisant : la quantité vendable (%) ne peut pas être inférieure aux unités déjà vendues (%) et perdues (%).',
        v_new_vendable, v_sold, v_lost;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: get_cashflow_journey(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."get_cashflow_journey"() RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_purchase_total bigint := 0;
  v_transport_total bigint := 0;
  v_invested_orders bigint := 0;
  v_stock_at_cost bigint := 0;
  v_stock_at_price bigint := 0;
  v_fin record;
  v_net_withdrawals bigint := 0;
  v_available_cash bigint := 0;
BEGIN
  SELECT
    coalesce(sum(purchase_amount), 0)::bigint,
    coalesce(sum(forwarder_fee), 0)::bigint,
    coalesce(sum(total_cost), 0)::bigint
  INTO v_purchase_total, v_transport_total, v_invested_orders
  FROM orders
  WHERE archived_at IS NULL;

  SELECT
    coalesce(sum(stock_value_at_cost), 0)::bigint,
    coalesce(sum(stock_value_at_price), 0)::bigint
  INTO v_stock_at_cost, v_stock_at_price
  FROM v_dormant_stock;

  SELECT * INTO v_fin
  FROM get_period_financial_summary('2000-01-01'::date, '2099-12-31'::date);

  SELECT
    coalesce(sum(CASE WHEN type = 'withdrawal' THEN amount ELSE -amount END), 0)::bigint
  INTO v_net_withdrawals
  FROM withdrawals
  WHERE status = 'active';

  SELECT coalesce(sum(current_balance), 0)::bigint
  INTO v_available_cash
  FROM v_treasury_accounts_summary;

  RETURN jsonb_build_object(
    'purchase_total', v_purchase_total,
    'transport_total', v_transport_total,
    'invested_orders', v_invested_orders,
    'stock_at_cost', v_stock_at_cost,
    'stock_at_price', v_stock_at_price,
    'collected_sales', coalesce(v_fin.collected_total, 0),
    'realized_margin', coalesce(v_fin.realized_margin, 0),
    'ads_total', coalesce(v_fin.ad_spends_total, 0),
    'expenses_total', coalesce(v_fin.expenses_total, 0),
    'net_profit', coalesce(v_fin.net_profit, 0),
    'net_withdrawals', v_net_withdrawals,
    'retained_profit', coalesce(v_fin.net_profit, 0) - v_net_withdrawals,
    'available_cash', v_available_cash
  );
END;
$$;


--
-- Name: get_partners_summary(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."get_partners_summary"() RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_cum_net_profit bigint := 0;
  v_total_withdrawn bigint := 0;
  v_total_contributed bigint := 0;
  v_net_withdrawals bigint := 0;
  v_partners jsonb;
BEGIN
  SELECT coalesce(f.net_profit, 0)::bigint
  INTO v_cum_net_profit
  FROM get_period_financial_summary('2000-01-01'::date, '2099-12-31'::date) f;

  SELECT
    coalesce(sum(CASE WHEN type = 'withdrawal' THEN amount ELSE 0 END), 0)::bigint,
    coalesce(sum(CASE WHEN type = 'contribution' THEN amount ELSE 0 END), 0)::bigint
  INTO v_total_withdrawn, v_total_contributed
  FROM withdrawals
  WHERE status = 'active';

  v_net_withdrawals := v_total_withdrawn - v_total_contributed;

  SELECT coalesce(jsonb_agg(row_to_json(t) ORDER BY t.slot ASC), '[]'::jsonb)
  INTO v_partners
  FROM (
    SELECT
      p.id,
      p.slot,
      p.name,
      p.share_pct,
      coalesce(sum(CASE WHEN w.status = 'active' AND w.type = 'withdrawal' THEN w.amount ELSE 0 END), 0)::bigint AS total_withdrawn,
      coalesce(sum(CASE WHEN w.status = 'active' AND w.type = 'contribution' THEN w.amount ELSE 0 END), 0)::bigint AS total_contributed,
      (
        coalesce(sum(CASE WHEN w.status = 'active' AND w.type = 'withdrawal' THEN w.amount ELSE 0 END), 0)
        - coalesce(sum(CASE WHEN w.status = 'active' AND w.type = 'contribution' THEN w.amount ELSE 0 END), 0)
      )::bigint AS net_withdrawn,
      round(v_cum_net_profit::numeric * (p.share_pct / 100.0))::bigint AS theoretical_share,
      (
        round(v_cum_net_profit::numeric * (p.share_pct / 100.0))
        - (
            coalesce(sum(CASE WHEN w.status = 'active' AND w.type = 'withdrawal' THEN w.amount ELSE 0 END), 0)
            - coalesce(sum(CASE WHEN w.status = 'active' AND w.type = 'contribution' THEN w.amount ELSE 0 END), 0)
          )
      )::bigint AS balance_with_business
    FROM partners p
    LEFT JOIN withdrawals w ON w.partner_id = p.id
    GROUP BY p.id, p.slot, p.name, p.share_pct
  ) t;

  RETURN jsonb_build_object(
    'cumulative_net_profit', v_cum_net_profit,
    'total_withdrawn', v_total_withdrawn,
    'total_contributed', v_total_contributed,
    'net_withdrawals', v_net_withdrawals,
    'retained_profit', (v_cum_net_profit - v_net_withdrawals),
    'partners', v_partners
  );
END;
$$;


--
-- Name: get_period_financial_summary("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."get_period_financial_summary"("p_from" "date", "p_to" "date") RETURNS TABLE("collected_total" bigint, "realized_margin" bigint, "ad_spends_total" bigint, "expenses_total" bigint, "net_profit" bigint, "discounts_total" bigint, "lost_value" bigint, "sales_count" bigint, "sold_units" bigint, "lost_units" bigint, "roas" numeric, "margin_per_1000_ads" numeric, "cost_per_sale" numeric)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_collected  bigint := 0;
  v_margin     bigint := 0;
  v_discounts  bigint := 0;
  v_lost_val   bigint := 0;
  v_sales_cnt  bigint := 0;
  v_sold_u     bigint := 0;
  v_lost_u     bigint := 0;
  v_ads        bigint := 0;
  v_expenses   bigint := 0;
BEGIN
  SELECT
    coalesce(sum(s.collected_total), 0)::bigint,
    coalesce(sum(s.realized_margin), 0)::bigint,
    coalesce(sum(s.discounts_total), 0)::bigint,
    coalesce(sum(s.lost_value), 0)::bigint,
    coalesce(sum(s.sales_count), 0)::bigint,
    coalesce(sum(s.sold_units), 0)::bigint,
    coalesce(sum(s.lost_units), 0)::bigint
  INTO
    v_collected, v_margin, v_discounts, v_lost_val, v_sales_cnt, v_sold_u, v_lost_u
  FROM stats_by_day(p_from, p_to) s;

  SELECT coalesce(sum(amount), 0)::bigint
  INTO v_ads
  FROM ad_spends
  WHERE status = 'active'
    AND spend_date >= p_from
    AND spend_date <= p_to;

  SELECT coalesce(sum(amount), 0)::bigint
  INTO v_expenses
  FROM expenses
  WHERE status = 'active'
    AND expense_date >= p_from
    AND expense_date <= p_to;

  RETURN QUERY
  SELECT
    v_collected,
    v_margin,
    v_ads,
    v_expenses,
    (v_margin - v_ads - v_expenses)::bigint AS net_profit,
    v_discounts,
    v_lost_val,
    v_sales_cnt,
    v_sold_u,
    v_lost_u,
    CASE WHEN v_ads > 0 THEN round(v_collected::numeric / v_ads, 2) ELSE NULL END AS roas,
    CASE WHEN v_ads > 0 THEN round((v_margin::numeric / v_ads) * 1000, 0) ELSE NULL END AS margin_per_1000_ads,
    CASE WHEN v_ads > 0 AND v_sales_cnt > 0 THEN round(v_ads::numeric / v_sales_cnt, 0) ELSE NULL END AS cost_per_sale;
END;
$$;


--
-- Name: is_authorized_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."is_authorized_user"() RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid());
$$;


--
-- Name: FUNCTION "is_authorized_user"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."is_authorized_user"() IS 'Vérifie si auth.uid() est présent dans la table profiles (liste blanche). Exécuté en SECURITY DEFINER pour contourner la RLS sur profiles.';


--
-- Name: reconcile_treasury_account("uuid", bigint, "date", "text", boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."reconcile_treasury_account"("p_account_id" "uuid", "p_real_balance" bigint, "p_reconciled_on" "date" DEFAULT CURRENT_DATE, "p_note" "text" DEFAULT NULL::"text", "p_adjust" boolean DEFAULT false) RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_calc bigint;
  v_diff bigint;
  v_rec_id uuid;
BEGIN
  SELECT current_balance INTO v_calc
  FROM v_treasury_accounts_summary
  WHERE account_id = p_account_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Compte de trésorerie introuvable.';
  END IF;

  v_diff := p_real_balance - v_calc;

  INSERT INTO treasury_reconciliations (
    account_id, reconciled_on, calculated_balance, real_balance, discrepancy, note, created_by
  ) VALUES (
    p_account_id, coalesce(p_reconciled_on, CURRENT_DATE), v_calc, p_real_balance, v_diff,
    nullif(trim(coalesce(p_note, '')), ''), auth.uid()
  )
  RETURNING id INTO v_rec_id;

  IF p_adjust AND v_diff <> 0 THEN
    INSERT INTO treasury_movements (
      account_id, direction, amount, movement_date, category, note, status, created_by
    ) VALUES (
      p_account_id,
      CASE WHEN v_diff > 0 THEN 'in' ELSE 'out' END,
      abs(v_diff),
      coalesce(p_reconciled_on, CURRENT_DATE),
      'adjustment',
      coalesce(nullif(trim(coalesce(p_note, '')), ''), 'Ajustement de rapprochement'),
      'active',
      auth.uid()
    );
  END IF;

  RETURN jsonb_build_object(
    'reconciliation_id', v_rec_id,
    'calculated_balance', v_calc,
    'real_balance', p_real_balance,
    'discrepancy', v_diff
  );
END;
$$;


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."rls_auto_enable"() RETURNS "event_trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


--
-- Name: save_partners("text", numeric, "text", numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."save_partners"("p_name_1" "text", "p_share_1" numeric, "p_name_2" "text", "p_share_2" numeric) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF p_name_1 IS NULL OR trim(p_name_1) = '' OR p_name_2 IS NULL OR trim(p_name_2) = '' THEN
    RAISE EXCEPTION 'Les noms des 2 associés sont obligatoires.';
  END IF;

  IF p_share_1 < 0 OR p_share_2 < 0 OR round(p_share_1 + p_share_2, 2) <> 100.00 THEN
    RAISE EXCEPTION 'La somme des parts des 2 associés doit être exactement égale à 100 %%.';
  END IF;

  UPDATE partners
  SET name = trim(p_name_1), share_pct = round(p_share_1, 2), updated_at = now()
  WHERE slot = 1;

  UPDATE partners
  SET name = trim(p_name_2), share_pct = round(p_share_2, 2), updated_at = now()
  WHERE slot = 2;
END;
$$;


--
-- Name: stats_by_category("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."stats_by_category"("p_from" "date", "p_to" "date") RETURNS TABLE("category_id" "uuid", "category_name" "text", "items_count" bigint, "sales_count" bigint, "sold_units" bigint, "collected_total" bigint, "realized_margin" bigint, "stock_units" bigint, "stock_value_at_cost" bigint, "stock_value_at_price" bigint)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_tz text;
BEGIN
  SELECT timezone INTO v_tz FROM app_settings LIMIT 1;
  v_tz := coalesce(v_tz, 'UTC');

  RETURN QUERY
  WITH cat_items AS (
    SELECT
      i.category_id,
      coalesce(c.name, 'Sans catégorie') AS cat_name,
      count(distinct i.id)::bigint AS items_cnt
    FROM items i
    LEFT JOIN categories c ON c.id = i.category_id
    WHERE i.archived_at IS NULL
    GROUP BY i.category_id, coalesce(c.name, 'Sans catégorie')
  ),
  cat_sales AS (
    SELECT
      i.category_id,
      coalesce(c.name, 'Sans catégorie') AS cat_name,
      count(distinct sd.sale_id)::bigint AS s_cnt,
      coalesce(sum(sd.quantity), 0)::bigint AS s_units,
      coalesce(sum(sd.sold_total), 0)::bigint AS s_collected,
      coalesce(sum(sd.margin), 0)::bigint AS s_margin
    FROM v_sales_detail sd
    JOIN items i ON i.id = sd.item_id
    LEFT JOIN categories c ON c.id = i.category_id
    WHERE (sd.sold_at AT TIME ZONE v_tz)::date >= p_from
      AND (sd.sold_at AT TIME ZONE v_tz)::date <= p_to
    GROUP BY i.category_id, coalesce(c.name, 'Sans catégorie')
  ),
  cat_stock AS (
    SELECT
      i.category_id,
      coalesce(c.name, 'Sans catégorie') AS cat_name,
      coalesce(sum(vs.stock), 0)::bigint AS st_units,
      coalesce(sum(vs.stock * vs.effective_unit_cost), 0)::bigint AS st_cost,
      coalesce(sum(vs.stock * vs.effective_price), 0)::bigint AS st_price
    FROM v_variant_stock vs
    JOIN items i ON i.id = vs.item_id
    LEFT JOIN categories c ON c.id = i.category_id
    WHERE vs.stock > 0
    GROUP BY i.category_id, coalesce(c.name, 'Sans catégorie')
  )
  SELECT
    ci.category_id,
    ci.cat_name AS category_name,
    ci.items_cnt AS items_count,
    coalesce(cs.s_cnt, 0)::bigint AS sales_count,
    coalesce(cs.s_units, 0)::bigint AS sold_units,
    coalesce(cs.s_collected, 0)::bigint AS collected_total,
    coalesce(cs.s_margin, 0)::bigint AS realized_margin,
    coalesce(cst.st_units, 0)::bigint AS stock_units,
    coalesce(cst.st_cost, 0)::bigint AS stock_value_at_cost,
    coalesce(cst.st_price, 0)::bigint AS stock_value_at_price
  FROM cat_items ci
  LEFT JOIN cat_sales cs ON cs.cat_name = ci.cat_name
  LEFT JOIN cat_stock cst ON cst.cat_name = ci.cat_name
  ORDER BY collected_total DESC, stock_value_at_cost DESC;
END;
$$;


--
-- Name: stats_by_channel("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."stats_by_channel"("p_from" "date", "p_to" "date") RETURNS TABLE("channel" "text", "sales_count" bigint, "sold_units" bigint, "collected_total" bigint, "discounts_total" bigint, "avg_discount" numeric, "realized_margin" bigint)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_tz text;
BEGIN
  SELECT timezone INTO v_tz FROM app_settings LIMIT 1;
  v_tz := coalesce(v_tz, 'UTC');

  RETURN QUERY
  SELECT
    coalesce(sd.channel, 'other') AS channel,
    count(distinct sd.sale_id)::bigint AS sales_count,
    coalesce(sum(sd.quantity), 0)::bigint AS sold_units,
    coalesce(sum(sd.sold_total), 0)::bigint AS collected_total,
    coalesce(sum(sd.discount), 0)::bigint AS discounts_total,
    CASE
      WHEN count(distinct sd.sale_id) > 0 THEN
        round(coalesce(sum(sd.discount), 0)::numeric / count(distinct sd.sale_id), 0)
      ELSE 0
    END AS avg_discount,
    coalesce(sum(sd.margin), 0)::bigint AS realized_margin
  FROM v_sales_detail sd
  WHERE (sd.sold_at AT TIME ZONE v_tz)::date >= p_from
    AND (sd.sold_at AT TIME ZONE v_tz)::date <= p_to
  GROUP BY coalesce(sd.channel, 'other')
  ORDER BY collected_total DESC;
END;
$$;


--
-- Name: stats_by_day("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."stats_by_day"("p_from" "date", "p_to" "date") RETURNS TABLE("stat_date" "date", "collected_total" bigint, "realized_margin" bigint, "discounts_total" bigint, "lost_value" bigint, "sales_count" bigint, "sold_units" bigint, "lost_units" bigint)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_tz text;
BEGIN
  SELECT timezone INTO v_tz FROM app_settings LIMIT 1;
  v_tz := coalesce(v_tz, 'UTC');

  RETURN QUERY
  WITH day_series AS (
    SELECT generate_series(p_from, p_to, '1 day'::interval)::date AS d
  ),
  daily_sales AS (
    SELECT
      (sd.sold_at AT TIME ZONE v_tz)::date AS sale_date,
      coalesce(sum(sd.sold_total), 0)::bigint AS collected,
      coalesce(sum(sd.margin), 0)::bigint AS margin,
      coalesce(sum(sd.discount), 0)::bigint AS discounts,
      count(distinct sd.sale_id)::bigint AS s_count,
      coalesce(sum(sd.quantity), 0)::bigint AS s_units
    FROM v_sales_detail sd
    WHERE (sd.sold_at AT TIME ZONE v_tz)::date >= p_from
      AND (sd.sold_at AT TIME ZONE v_tz)::date <= p_to
    GROUP BY (sd.sold_at AT TIME ZONE v_tz)::date
  ),
  daily_losses AS (
    SELECT
      l.occurred_on AS loss_date,
      coalesce(sum(l.quantity), 0)::bigint AS l_units,
      coalesce(sum(l.quantity * vs.effective_unit_cost), 0)::bigint AS l_value
    FROM losses l
    JOIN v_variant_stock vs ON vs.variant_id = l.variant_id
    WHERE l.status = 'active'
      AND l.occurred_on >= p_from
      AND l.occurred_on <= p_to
    GROUP BY l.occurred_on
  )
  SELECT
    ds.d AS stat_date,
    coalesce(dsales.collected, 0)::bigint AS collected_total,
    (coalesce(dsales.margin, 0) - coalesce(dlosses.l_value, 0))::bigint AS realized_margin,
    coalesce(dsales.discounts, 0)::bigint AS discounts_total,
    coalesce(dlosses.l_value, 0)::bigint AS lost_value,
    coalesce(dsales.s_count, 0)::bigint AS sales_count,
    coalesce(dsales.s_units, 0)::bigint AS sold_units,
    coalesce(dlosses.l_units, 0)::bigint AS lost_units
  FROM day_series ds
  LEFT JOIN daily_sales dsales ON dsales.sale_date = ds.d
  LEFT JOIN daily_losses dlosses ON dlosses.loss_date = ds.d
  ORDER BY ds.d ASC;
END;
$$;


--
-- Name: FUNCTION "stats_by_day"("p_from" "date", "p_to" "date"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."stats_by_day"("p_from" "date", "p_to" "date") IS 'Statistiques quotidiennes dans le fuseau configuré (encaissé, marge, remises, pertes).';


--
-- Name: stats_by_month("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."stats_by_month"("p_from" "date", "p_to" "date") RETURNS TABLE("stat_month" "text", "month_start" "date", "collected_total" bigint, "realized_margin" bigint, "discounts_total" bigint, "lost_value" bigint, "sales_count" bigint, "sold_units" bigint, "lost_units" bigint)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_tz text;
BEGIN
  SELECT timezone INTO v_tz FROM app_settings LIMIT 1;
  v_tz := coalesce(v_tz, 'UTC');

  RETURN QUERY
  WITH month_series AS (
    SELECT generate_series(
      date_trunc('month', p_from::timestamp),
      date_trunc('month', p_to::timestamp),
      '1 month'::interval
    )::date AS m_start
  ),
  monthly_sales AS (
    SELECT
      date_trunc('month', (sd.sold_at AT TIME ZONE v_tz))::date AS s_month,
      coalesce(sum(sd.sold_total), 0)::bigint AS collected,
      coalesce(sum(sd.margin), 0)::bigint AS margin,
      coalesce(sum(sd.discount), 0)::bigint AS discounts,
      count(distinct sd.sale_id)::bigint AS s_count,
      coalesce(sum(sd.quantity), 0)::bigint AS s_units
    FROM v_sales_detail sd
    WHERE (sd.sold_at AT TIME ZONE v_tz)::date >= p_from
      AND (sd.sold_at AT TIME ZONE v_tz)::date <= p_to
    GROUP BY date_trunc('month', (sd.sold_at AT TIME ZONE v_tz))::date
  ),
  monthly_losses AS (
    SELECT
      date_trunc('month', l.occurred_on::timestamp)::date AS l_month,
      coalesce(sum(l.quantity), 0)::bigint AS l_units,
      coalesce(sum(l.quantity * vs.effective_unit_cost), 0)::bigint AS l_value
    FROM losses l
    JOIN v_variant_stock vs ON vs.variant_id = l.variant_id
    WHERE l.status = 'active'
      AND l.occurred_on >= p_from
      AND l.occurred_on <= p_to
    GROUP BY date_trunc('month', l.occurred_on::timestamp)::date
  )
  SELECT
    to_char(ms.m_start, 'YYYY-MM') AS stat_month,
    ms.m_start AS month_start,
    coalesce(msales.collected, 0)::bigint AS collected_total,
    (coalesce(msales.margin, 0) - coalesce(mlosses.l_value, 0))::bigint AS realized_margin,
    coalesce(msales.discounts, 0)::bigint AS discounts_total,
    coalesce(mlosses.l_value, 0)::bigint AS lost_value,
    coalesce(msales.s_count, 0)::bigint AS sales_count,
    coalesce(msales.s_units, 0)::bigint AS sold_units,
    coalesce(mlosses.l_units, 0)::bigint AS lost_units
  FROM month_series ms
  LEFT JOIN monthly_sales msales ON msales.s_month = ms.m_start
  LEFT JOIN monthly_losses mlosses ON mlosses.l_month = ms.m_start
  ORDER BY ms.m_start ASC;
END;
$$;


--
-- Name: FUNCTION "stats_by_month"("p_from" "date", "p_to" "date"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."stats_by_month"("p_from" "date", "p_to" "date") IS 'Statistiques mensuelles dans le fuseau configuré (encaissé, marge, remises, pertes).';


--
-- Name: transfer_treasury("uuid", "uuid", bigint, "date", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."transfer_treasury"("p_from_account_id" "uuid", "p_to_account_id" "uuid", "p_amount" bigint, "p_date" "date" DEFAULT CURRENT_DATE, "p_note" "text" DEFAULT NULL::"text") RETURNS "uuid"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_group_id uuid := gen_random_uuid();
  v_from_name text;
  v_to_name text;
BEGIN
  IF p_from_account_id IS NULL OR p_to_account_id IS NULL THEN
    RAISE EXCEPTION 'Les comptes source et destination sont obligatoires.';
  END IF;
  IF p_from_account_id = p_to_account_id THEN
    RAISE EXCEPTION 'Les comptes source et destination doivent être différents.';
  END IF;
  IF p_amount IS NULL OR p_amount <= 0 THEN
    RAISE EXCEPTION 'Le montant du virement doit être strictement positif.';
  END IF;

  SELECT name INTO v_from_name FROM treasury_accounts WHERE id = p_from_account_id AND archived_at IS NULL;
  IF NOT FOUND THEN RAISE EXCEPTION 'Compte source introuvable.'; END IF;

  SELECT name INTO v_to_name FROM treasury_accounts WHERE id = p_to_account_id AND archived_at IS NULL;
  IF NOT FOUND THEN RAISE EXCEPTION 'Compte destination introuvable.'; END IF;

  INSERT INTO treasury_movements (
    account_id, direction, amount, movement_date, category,
    transfer_group_id, note, status, created_by
  ) VALUES (
    p_from_account_id, 'out', p_amount, coalesce(p_date, CURRENT_DATE), 'transfer_out',
    v_group_id, coalesce(nullif(trim(coalesce(p_note, '')), ''), 'Virement vers ' || v_to_name), 'active', auth.uid()
  );

  INSERT INTO treasury_movements (
    account_id, direction, amount, movement_date, category,
    transfer_group_id, note, status, created_by
  ) VALUES (
    p_to_account_id, 'in', p_amount, coalesce(p_date, CURRENT_DATE), 'transfer_in',
    v_group_id, coalesce(nullif(trim(coalesce(p_note, '')), ''), 'Virement depuis ' || v_from_name), 'active', auth.uid()
  );

  RETURN v_group_id;
END;
$$;


--
-- Name: update_item_with_variants("uuid", "text", bigint, bigint, "uuid", "text", "text", "text", "jsonb"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."update_item_with_variants"("p_item_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint DEFAULT NULL::bigint, "p_category_id" "uuid" DEFAULT NULL::"uuid", "p_description" "text" DEFAULT NULL::"text", "p_photo_url" "text" DEFAULT NULL::"text", "p_photo_public_id" "text" DEFAULT NULL::"text", "p_variants" "jsonb" DEFAULT '[]'::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_item            items%ROWTYPE;
  v_variant         variants%ROWTYPE;
  v_elem            jsonb;
  v_variant_id      uuid;
  v_label           text;
  v_quantity_ordered int;
  v_quantity_received int;
  v_quantity_damaged int;
  v_price_override  bigint;
  v_has_override    boolean;
  v_old_effective_price bigint;
  v_new_effective_price bigint;
  v_change_type     text;
  v_updated_ids     uuid[] := '{}';
BEGIN
  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'Le nom de l''article est obligatoire.';
  END IF;

  IF p_list_price IS NULL OR p_list_price < 0 THEN
    RAISE EXCEPTION 'Le prix fixé doit être un entier positif ou nul.';
  END IF;

  IF p_unit_cost IS NOT NULL AND p_unit_cost < 0 THEN
    RAISE EXCEPTION 'Le coût unitaire ne peut pas être négatif.';
  END IF;

  IF p_variants IS NULL OR jsonb_typeof(p_variants) <> 'array' OR jsonb_array_length(p_variants) = 0 THEN
    RAISE EXCEPTION 'Au moins une variante est obligatoire.';
  END IF;

  SELECT * INTO v_item
  FROM items
  WHERE id = p_item_id AND archived_at IS NULL
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Article introuvable ou archivé.';
  END IF;

  -- Autorise les changements de prix uniquement pendant cette transaction.
  PERFORM set_config('app.allow_price_change', 'on', true);

  UPDATE items
  SET
    name = trim(p_name),
    category_id = p_category_id,
    description = nullif(trim(coalesce(p_description, '')), ''),
    photo_url = p_photo_url,
    photo_public_id = p_photo_public_id,
    list_price = p_list_price,
    unit_cost = p_unit_cost,
    updated_at = now()
  WHERE id = p_item_id;

  IF v_item.list_price IS DISTINCT FROM p_list_price THEN
    INSERT INTO price_changes (
      item_id, variant_id, old_price, new_price, change_type, note, changed_by
    ) VALUES (
      p_item_id,
      NULL,
      v_item.list_price,
      p_list_price,
      CASE WHEN p_list_price < v_item.list_price THEN 'markdown' ELSE 'increase' END,
      'Modification de la fiche article',
      auth.uid()
    );
  END IF;

  FOR v_elem IN SELECT * FROM jsonb_array_elements(p_variants)
  LOOP
    v_label := coalesce(nullif(trim(v_elem ->> 'label'), ''), 'Unique');
    v_quantity_received := coalesce((v_elem ->> 'quantity_received')::int, 0);
    v_quantity_damaged := coalesce((v_elem ->> 'quantity_damaged')::int, 0);
    v_quantity_ordered := nullif(v_elem ->> 'quantity_ordered', '')::int;
    v_has_override := v_elem ? 'price_override' AND (v_elem ->> 'price_override') IS NOT NULL;
    v_price_override := CASE WHEN v_has_override THEN (v_elem ->> 'price_override')::bigint ELSE NULL END;

    IF v_quantity_received < 0 OR v_quantity_damaged < 0 THEN
      RAISE EXCEPTION 'Les quantités de la variante "%" ne peuvent pas être négatives.', v_label;
    END IF;

    IF v_quantity_damaged > v_quantity_received THEN
      RAISE EXCEPTION 'La quantité abîmée ne peut pas dépasser la quantité reçue pour la variante "%".', v_label;
    END IF;

    IF v_quantity_ordered IS NOT NULL AND v_quantity_ordered < 0 THEN
      RAISE EXCEPTION 'La quantité commandée de la variante "%" ne peut pas être négative.', v_label;
    END IF;

    IF v_price_override IS NOT NULL AND v_price_override < 0 THEN
      RAISE EXCEPTION 'Le prix spécifique de la variante "%" ne peut pas être négatif.', v_label;
    END IF;

    v_variant_id := nullif(v_elem ->> 'id', '')::uuid;

    IF v_variant_id IS NULL THEN
      INSERT INTO variants (
        item_id,
        label,
        photo_url,
        photo_public_id,
        price_override,
        quantity_ordered,
        quantity_received,
        quantity_damaged,
        created_by
      ) VALUES (
        p_item_id,
        v_label,
        nullif(v_elem ->> 'photo_url', ''),
        nullif(v_elem ->> 'photo_public_id', ''),
        v_price_override,
        v_quantity_ordered,
        v_quantity_received,
        v_quantity_damaged,
        auth.uid()
      ) RETURNING id INTO v_variant_id;

      IF v_price_override IS NOT NULL THEN
        INSERT INTO price_changes (
          item_id, variant_id, old_price, new_price, change_type, note, changed_by
        ) VALUES (
          p_item_id, v_variant_id, NULL, v_price_override, 'initial',
          'Prix spécifique initial de la variante', auth.uid()
        );
      END IF;
    ELSE
      SELECT * INTO v_variant
      FROM variants
      WHERE id = v_variant_id
        AND item_id = p_item_id
        AND archived_at IS NULL
      FOR UPDATE;

      IF NOT FOUND THEN
        RAISE EXCEPTION 'Une variante à modifier est introuvable pour cet article.';
      END IF;

      v_old_effective_price := coalesce(v_variant.price_override, v_item.list_price);
      v_new_effective_price := coalesce(v_price_override, p_list_price);

      UPDATE variants
      SET
        label = v_label,
        photo_url = nullif(v_elem ->> 'photo_url', ''),
        photo_public_id = nullif(v_elem ->> 'photo_public_id', ''),
        price_override = v_price_override,
        quantity_ordered = v_quantity_ordered,
        quantity_received = v_quantity_received,
        quantity_damaged = v_quantity_damaged,
        updated_at = now()
      WHERE id = v_variant_id;

      IF v_variant.price_override IS DISTINCT FROM v_price_override
         AND v_old_effective_price IS DISTINCT FROM v_new_effective_price THEN
        v_change_type := CASE
          WHEN v_new_effective_price < v_old_effective_price THEN 'markdown'
          ELSE 'increase'
        END;

        INSERT INTO price_changes (
          item_id, variant_id, old_price, new_price, change_type, note, changed_by
        ) VALUES (
          p_item_id, v_variant_id, v_old_effective_price, v_new_effective_price,
          v_change_type, 'Modification de la fiche article', auth.uid()
        );
      END IF;
    END IF;

    v_updated_ids := array_append(v_updated_ids, v_variant_id);
  END LOOP;

  RETURN jsonb_build_object(
    'item_id', p_item_id,
    'variant_ids', to_jsonb(v_updated_ids)
  );
END;
$$;


--
-- Name: FUNCTION "update_item_with_variants"("p_item_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."update_item_with_variants"("p_item_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb") IS 'Met à jour un article et ses variantes dans une transaction, avec contrôles de stock et historique des prix.';


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: ad_spends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."ad_spends" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "spend_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "amount" bigint NOT NULL,
    "platform" "text" DEFAULT 'facebook'::"text" NOT NULL,
    "item_id" "uuid",
    "order_id" "uuid",
    "note" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "cancelled_at" timestamp with time zone,
    "cancelled_by" "uuid",
    "cancel_reason" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "treasury_account_id" "uuid",
    CONSTRAINT "ad_spends_amount_check" CHECK (("amount" > 0)),
    CONSTRAINT "ad_spends_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'cancelled'::"text"]))),
    CONSTRAINT "chk_ad_spend_cancel_fields" CHECK ((("status" <> 'cancelled'::"text") OR (("cancelled_at" IS NOT NULL) AND ("cancelled_by" IS NOT NULL) AND ("cancel_reason" IS NOT NULL) AND (TRIM(BOTH FROM "cancel_reason") <> ''::"text"))))
);

ALTER TABLE ONLY "public"."ad_spends" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "ad_spends"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."ad_spends" IS 'Dépenses publicitaires avec liens facultatifs vers un article et/ou une commande (V2).';


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."app_settings" (
    "id" boolean DEFAULT true NOT NULL,
    "watch_after_days" integer DEFAULT 30 NOT NULL,
    "clearance_after_days" integer DEFAULT 90 NOT NULL,
    "timezone" "text" DEFAULT 'UTC'::"text" NOT NULL,
    "updated_at" timestamp with time zone,
    "updated_by" "uuid",
    CONSTRAINT "app_settings_fixed_defaults" CHECK ((("watch_after_days" = 30) AND ("clearance_after_days" = 90) AND ("timezone" = 'UTC'::"text"))),
    CONSTRAINT "app_settings_id_check" CHECK ("id"),
    CONSTRAINT "chk_clearance_gt_watch" CHECK (("clearance_after_days" > "watch_after_days"))
);

ALTER TABLE ONLY "public"."app_settings" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "app_settings"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."app_settings" IS 'Paramètres globaux. Contient exactement une ligne (PK = true). §7.2.';


--
-- Name: COLUMN "app_settings"."watch_after_days"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."app_settings"."watch_after_days" IS 'Jours avant passage au statut « À surveiller » (R18).';


--
-- Name: COLUMN "app_settings"."clearance_after_days"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."app_settings"."clearance_after_days" IS 'Jours avant passage au statut « À déstocker » (R18).';


--
-- Name: COLUMN "app_settings"."timezone"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."app_settings"."timezone" IS 'Fuseau IANA pour les regroupements jour/mois des statistiques. §7.1 / R17.';


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."audit_log" (
    "id" bigint NOT NULL,
    "table_name" "text" NOT NULL,
    "record_id" "uuid" NOT NULL,
    "action" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "changed_fields" "text"[],
    "changed_by" "uuid",
    "changed_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "audit_log_action_check" CHECK (("action" = ANY (ARRAY['INSERT'::"text", 'UPDATE'::"text"])))
);

ALTER TABLE ONLY "public"."audit_log" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "audit_log"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."audit_log" IS 'Journal d''audit inviolable. INSERT seul. §7.5.';


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."audit_log" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."audit_log_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."categories" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."categories" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "categories"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."categories" IS 'Catégories d''articles. Nom unique insensible à la casse (B4).';


--
-- Name: COLUMN "categories"."name"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."categories"."name" IS 'Nom affiché. Unicité garantie via index fonctionnel sur lower(name).';


--
-- Name: expense_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."expense_categories" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."expense_categories" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "expense_categories"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."expense_categories" IS 'Catégories pour les autres dépenses de fonctionnement (V2).';


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."expenses" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "expense_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "category_id" "uuid" NOT NULL,
    "amount" bigint NOT NULL,
    "description" "text" NOT NULL,
    "order_id" "uuid",
    "receipt_url" "text",
    "receipt_public_id" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "cancelled_at" timestamp with time zone,
    "cancelled_by" "uuid",
    "cancel_reason" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "treasury_account_id" "uuid",
    CONSTRAINT "chk_expense_cancel_fields" CHECK ((("status" <> 'cancelled'::"text") OR (("cancelled_at" IS NOT NULL) AND ("cancelled_by" IS NOT NULL) AND ("cancel_reason" IS NOT NULL) AND (TRIM(BOTH FROM "cancel_reason") <> ''::"text")))),
    CONSTRAINT "expenses_amount_check" CHECK (("amount" > 0)),
    CONSTRAINT "expenses_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'cancelled'::"text"])))
);

ALTER TABLE ONLY "public"."expenses" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "expenses"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."expenses" IS 'Autres dépenses hors achat/transitaire des commandes (V2). Annulation uniquement, jamais de DELETE.';


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "code" "text" NOT NULL,
    "order_id" "uuid" NOT NULL,
    "category_id" "uuid",
    "name" "text" NOT NULL,
    "description" "text",
    "photo_url" "text",
    "photo_public_id" "text",
    "list_price" bigint NOT NULL,
    "initial_price" bigint NOT NULL,
    "unit_cost" bigint,
    "received_date" "date" NOT NULL,
    "archived_at" timestamp with time zone,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "items_initial_price_check" CHECK (("initial_price" >= 0)),
    CONSTRAINT "items_list_price_check" CHECK (("list_price" >= 0)),
    CONSTRAINT "items_unit_cost_check" CHECK (("unit_cost" >= 0))
);

ALTER TABLE ONLY "public"."items" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "items"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."items" IS 'Articles vendus, rattachés à une commande Chine. §7.2 / §9.3.';


--
-- Name: COLUMN "items"."list_price"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."items"."list_price" IS 'Prix fixé actuel. R8.';


--
-- Name: COLUMN "items"."initial_price"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."items"."initial_price" IS 'Prix à la création, immuable.';


--
-- Name: COLUMN "items"."unit_cost"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."items"."unit_cost" IS 'Coût unitaire facultatif. Si NULL -> estimé par répartition (R11).';


--
-- Name: COLUMN "items"."received_date"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."items"."received_date" IS 'Date de réception copiée de la commande. Base pour R17.';


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."orders" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "reference" "text" NOT NULL,
    "order_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "supplier" "text" NOT NULL,
    "description" "text",
    "status" "text" DEFAULT 'ordered'::"text" NOT NULL,
    "purchase_amount" bigint NOT NULL,
    "forwarder_fee" bigint DEFAULT 0 NOT NULL,
    "weight_kg" numeric(10,2),
    "received_date" "date",
    "total_cost" bigint GENERATED ALWAYS AS (("purchase_amount" + "forwarder_fee")) STORED,
    "notes" "text",
    "archived_at" timestamp with time zone,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "origin" "text" DEFAULT 'china'::"text",
    "treasury_account_id" "uuid",
    CONSTRAINT "chk_received_needs_date" CHECK ((("status" <> 'received'::"text") OR ("received_date" IS NOT NULL))),
    CONSTRAINT "orders_forwarder_fee_check" CHECK (("forwarder_fee" >= 0)),
    CONSTRAINT "orders_purchase_amount_check" CHECK (("purchase_amount" >= 0)),
    CONSTRAINT "orders_status_check" CHECK (("status" = ANY (ARRAY['ordered'::"text", 'shipping'::"text", 'received'::"text"])))
);

ALTER TABLE ONLY "public"."orders" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "orders"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."orders" IS 'Commandes passées en Chine. Unité financière de base. §7.2 / §9.2.';


--
-- Name: COLUMN "orders"."reference"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."orders"."reference" IS 'Référence unique auto-générée (CH-001…).';


--
-- Name: COLUMN "orders"."received_date"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."orders"."received_date" IS 'Obligatoire si status = received. Point de départ de l''ancienneté des articles. R17.';


--
-- Name: COLUMN "orders"."total_cost"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."orders"."total_cost" IS 'GENERATED STORED : purchase_amount + forwarder_fee. R3.';


--
-- Name: COLUMN "orders"."origin"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."orders"."origin" IS 'Provenance de la commande : Chine, Local, Dubaï, Turquie, Autre...';


--
-- Name: export_ad_spends; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."export_ad_spends" WITH ("security_invoker"='true') AS
 SELECT "a"."id" AS "ad_spend_id",
    "a"."spend_date",
    "a"."amount",
    "a"."platform",
    COALESCE("i"."code", ''::"text") AS "item_code",
    COALESCE("i"."name", ''::"text") AS "item_name",
    COALESCE("o"."reference", ''::"text") AS "order_reference",
    COALESCE("a"."note", ''::"text") AS "note",
    "a"."status",
    COALESCE("a"."cancel_reason", ''::"text") AS "cancel_reason"
   FROM (("public"."ad_spends" "a"
     LEFT JOIN "public"."items" "i" ON (("i"."id" = "a"."item_id")))
     LEFT JOIN "public"."orders" "o" ON (("o"."id" = "a"."order_id")))
  ORDER BY "a"."spend_date" DESC, "a"."created_at" DESC;


--
-- Name: export_expenses; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."export_expenses" WITH ("security_invoker"='true') AS
 SELECT "e"."id" AS "expense_id",
    "e"."expense_date",
    "ec"."name" AS "category_name",
    "e"."amount",
    "e"."description",
    COALESCE("o"."reference", ''::"text") AS "order_reference",
    "e"."status",
    COALESCE("e"."cancel_reason", ''::"text") AS "cancel_reason"
   FROM (("public"."expenses" "e"
     JOIN "public"."expense_categories" "ec" ON (("ec"."id" = "e"."category_id")))
     LEFT JOIN "public"."orders" "o" ON (("o"."id" = "e"."order_id")))
  ORDER BY "e"."expense_date" DESC, "e"."created_at" DESC;


--
-- Name: losses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."losses" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "variant_id" "uuid" NOT NULL,
    "quantity" integer NOT NULL,
    "reason" "text" NOT NULL,
    "occurred_on" "date" DEFAULT CURRENT_DATE NOT NULL,
    "note" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "cancelled_at" timestamp with time zone,
    "cancelled_by" "uuid",
    "cancel_reason" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chk_loss_cancel_fields" CHECK ((("status" <> 'cancelled'::"text") OR (("cancelled_at" IS NOT NULL) AND ("cancelled_by" IS NOT NULL) AND ("cancel_reason" IS NOT NULL) AND (TRIM(BOTH FROM "cancel_reason") <> ''::"text")))),
    CONSTRAINT "losses_quantity_check" CHECK (("quantity" > 0)),
    CONSTRAINT "losses_reason_check" CHECK (("reason" = ANY (ARRAY['damaged'::"text", 'unsellable'::"text", 'gift'::"text", 'lost'::"text", 'other'::"text"]))),
    CONSTRAINT "losses_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'cancelled'::"text"])))
);

ALTER TABLE ONLY "public"."losses" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "losses"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."losses" IS 'Sorties en perte post-réception. §7.2 / §9.5.';


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."sales" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "variant_id" "uuid" NOT NULL,
    "quantity" integer NOT NULL,
    "list_price_unit" bigint NOT NULL,
    "sold_total" bigint NOT NULL,
    "channel" "text",
    "sold_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "note" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "cancelled_at" timestamp with time zone,
    "cancelled_by" "uuid",
    "cancel_reason" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "treasury_account_id" "uuid",
    CONSTRAINT "chk_sale_cancel_fields" CHECK ((("status" <> 'cancelled'::"text") OR (("cancelled_at" IS NOT NULL) AND ("cancelled_by" IS NOT NULL) AND ("cancel_reason" IS NOT NULL) AND (TRIM(BOTH FROM "cancel_reason") <> ''::"text")))),
    CONSTRAINT "sales_channel_check" CHECK (("channel" = ANY (ARRAY['facebook'::"text", 'whatsapp'::"text", 'direct'::"text", 'other'::"text"]))),
    CONSTRAINT "sales_list_price_unit_check" CHECK (("list_price_unit" >= 0)),
    CONSTRAINT "sales_quantity_check" CHECK (("quantity" > 0)),
    CONSTRAINT "sales_sold_total_check" CHECK (("sold_total" > 0)),
    CONSTRAINT "sales_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'cancelled'::"text"])))
);

ALTER TABLE ONLY "public"."sales" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "sales"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."sales" IS 'Ventes enregistrées. Jamais de DELETE ; annulation uniquement. §7.2 / §9.4.';


--
-- Name: COLUMN "sales"."list_price_unit"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."sales"."list_price_unit" IS 'Instantané du prix fixé unitaire au moment de la vente.';


--
-- Name: COLUMN "sales"."sold_total"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."sales"."sold_total" IS 'Montant total encaissé en FCFA.';


--
-- Name: variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."variants" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "item_id" "uuid" NOT NULL,
    "label" "text" DEFAULT 'Unique'::"text" NOT NULL,
    "photo_url" "text",
    "photo_public_id" "text",
    "price_override" bigint,
    "quantity_ordered" integer,
    "quantity_received" integer NOT NULL,
    "quantity_damaged" integer DEFAULT 0 NOT NULL,
    "archived_at" timestamp with time zone,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chk_damaged_lte_received" CHECK (("quantity_damaged" <= "quantity_received")),
    CONSTRAINT "variants_price_override_check" CHECK (("price_override" >= 0)),
    CONSTRAINT "variants_quantity_damaged_check" CHECK (("quantity_damaged" >= 0)),
    CONSTRAINT "variants_quantity_ordered_check" CHECK ((("quantity_ordered" IS NULL) OR ("quantity_ordered" >= 0))),
    CONSTRAINT "variants_quantity_received_check" CHECK (("quantity_received" >= 0))
);

ALTER TABLE ONLY "public"."variants" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "variants"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."variants" IS 'Déclinaisons d''articles. Stock calculé par variante. §6 / §7.2.';


--
-- Name: COLUMN "variants"."label"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."variants"."label" IS 'Libellé libre. Unicité par article insensible à la casse (B3).';


--
-- Name: COLUMN "variants"."price_override"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."variants"."price_override" IS 'Prix spécifique à la variante. Si NULL -> hérite de items.list_price.';


--
-- Name: COLUMN "variants"."quantity_damaged"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."variants"."quantity_damaged" IS 'Quantité abîmée constatée à la réception.';


--
-- Name: v_variant_stock; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_variant_stock" WITH ("security_invoker"='true') AS
 WITH "settings" AS (
         SELECT "app_settings"."watch_after_days",
            "app_settings"."clearance_after_days",
            "app_settings"."timezone"
           FROM "public"."app_settings"
         LIMIT 1
        ), "order_cost_calc" AS (
         SELECT "i_1"."order_id",
            "o_1"."total_cost",
            COALESCE("sum"(
                CASE
                    WHEN ("i_1"."unit_cost" IS NOT NULL) THEN ("i_1"."unit_cost" * ("v_1"."quantity_received" - "v_1"."quantity_damaged"))
                    ELSE (0)::bigint
                END), (0)::numeric) AS "known_cost",
            COALESCE("sum"(
                CASE
                    WHEN ("i_1"."unit_cost" IS NULL) THEN ("v_1"."quantity_received" - "v_1"."quantity_damaged")
                    ELSE 0
                END), (0)::bigint) AS "uncosted_vendable"
           FROM (("public"."items" "i_1"
             JOIN "public"."variants" "v_1" ON (("v_1"."item_id" = "i_1"."id")))
             JOIN "public"."orders" "o_1" ON (("o_1"."id" = "i_1"."order_id")))
          WHERE (("i_1"."archived_at" IS NULL) AND ("v_1"."archived_at" IS NULL) AND ("o_1"."archived_at" IS NULL))
          GROUP BY "i_1"."order_id", "o_1"."total_cost"
        ), "sales_agg" AS (
         SELECT "sales"."variant_id",
            COALESCE("sum"("sales"."quantity"), (0)::bigint) AS "sold_units"
           FROM "public"."sales"
          WHERE ("sales"."status" = 'active'::"text")
          GROUP BY "sales"."variant_id"
        ), "losses_agg" AS (
         SELECT "losses"."variant_id",
            COALESCE("sum"("losses"."quantity"), (0)::bigint) AS "lost_units"
           FROM "public"."losses"
          WHERE ("losses"."status" = 'active'::"text")
          GROUP BY "losses"."variant_id"
        )
 SELECT "v"."id" AS "variant_id",
    "i"."id" AS "item_id",
    "o"."id" AS "order_id",
    "o"."reference" AS "order_reference",
    "i"."code" AS "item_code",
    "i"."name" AS "item_name",
    "v"."label" AS "variant_label",
    "v"."photo_url",
    "v"."photo_public_id",
    "v"."quantity_ordered",
    "v"."quantity_received",
    "v"."quantity_damaged",
    ("v"."quantity_received" - "v"."quantity_damaged") AS "vendable",
    COALESCE("sa"."sold_units", (0)::bigint) AS "sold_units",
    COALESCE("la"."lost_units", (0)::bigint) AS "lost_units",
    ((("v"."quantity_received" - "v"."quantity_damaged") - COALESCE("sa"."sold_units", (0)::bigint)) - COALESCE("la"."lost_units", (0)::bigint)) AS "stock",
    COALESCE("v"."price_override", "i"."list_price") AS "effective_price",
        CASE
            WHEN ("i"."unit_cost" IS NOT NULL) THEN "i"."unit_cost"
            WHEN ("occ"."uncosted_vendable" > 0) THEN ("round"((GREATEST((0)::numeric, (("occ"."total_cost")::numeric - "occ"."known_cost")) / ("occ"."uncosted_vendable")::numeric)))::bigint
            ELSE (0)::bigint
        END AS "effective_unit_cost",
    ("i"."unit_cost" IS NULL) AS "cost_is_estimated",
    "i"."received_date",
    ((("now"() AT TIME ZONE "st"."timezone"))::"date" - "i"."received_date") AS "days_in_stock",
        CASE
            WHEN (((("v"."quantity_received" - "v"."quantity_damaged") - COALESCE("sa"."sold_units", (0)::bigint)) - COALESCE("la"."lost_units", (0)::bigint)) <= 0) THEN 'out_of_stock'::"text"
            WHEN (((("now"() AT TIME ZONE "st"."timezone"))::"date" - "i"."received_date") >= "st"."clearance_after_days") THEN 'clearance'::"text"
            WHEN (((("now"() AT TIME ZONE "st"."timezone"))::"date" - "i"."received_date") >= "st"."watch_after_days") THEN 'watch'::"text"
            ELSE 'normal'::"text"
        END AS "dormant_status"
   FROM (((((("public"."variants" "v"
     JOIN "public"."items" "i" ON (("i"."id" = "v"."item_id")))
     JOIN "public"."orders" "o" ON (("o"."id" = "i"."order_id")))
     CROSS JOIN "settings" "st")
     LEFT JOIN "order_cost_calc" "occ" ON (("occ"."order_id" = "o"."id")))
     LEFT JOIN "sales_agg" "sa" ON (("sa"."variant_id" = "v"."id")))
     LEFT JOIN "losses_agg" "la" ON (("la"."variant_id" = "v"."id")))
  WHERE (("v"."archived_at" IS NULL) AND ("i"."archived_at" IS NULL) AND ("o"."archived_at" IS NULL));


--
-- Name: VIEW "v_variant_stock"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_variant_stock" IS 'Stock par variante, coût effectif (R11), ancienneté (R17) et statut d''invendu (R18). Security invoker.';


--
-- Name: export_losses; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."export_losses" WITH ("security_invoker"='true') AS
 SELECT "l"."id" AS "loss_id",
    "l"."occurred_on" AS "loss_date",
    "vs"."order_reference",
    "vs"."item_code",
    "vs"."item_name",
    "vs"."variant_label",
    "l"."quantity",
    "l"."reason",
    "vs"."effective_unit_cost" AS "unit_cost",
    ("l"."quantity" * "vs"."effective_unit_cost") AS "loss_value",
    "l"."status",
    COALESCE("l"."cancel_reason", ''::"text") AS "cancel_reason"
   FROM ("public"."losses" "l"
     JOIN "public"."v_variant_stock" "vs" ON (("vs"."variant_id" = "l"."variant_id")))
  ORDER BY "l"."occurred_on" DESC;


--
-- Name: v_sales_detail; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_sales_detail" WITH ("security_invoker"='true') AS
 SELECT "s"."id" AS "sale_id",
    "s"."variant_id",
    "vs"."item_id",
    "vs"."order_id",
    "vs"."order_reference",
    "vs"."item_code",
    "vs"."item_name",
    "vs"."variant_label",
    "s"."quantity",
    "s"."list_price_unit",
    "s"."sold_total",
    (("s"."list_price_unit" * "s"."quantity") - "s"."sold_total") AS "discount",
    "vs"."effective_unit_cost",
    ("s"."sold_total" - ("vs"."effective_unit_cost" * "s"."quantity")) AS "margin",
    "vs"."cost_is_estimated",
    "s"."channel",
    "s"."sold_at",
    "s"."note",
    "s"."created_by",
    "s"."created_at"
   FROM ("public"."sales" "s"
     JOIN "public"."v_variant_stock" "vs" ON (("vs"."variant_id" = "s"."variant_id")))
  WHERE ("s"."status" = 'active'::"text");


--
-- Name: VIEW "v_sales_detail"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_sales_detail" IS 'Détail des ventes actives avec remise (R10), coût effectif (R11) et marge (R12). Security invoker.';


--
-- Name: v_order_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_order_summary" WITH ("security_invoker"='true') AS
 WITH "var_stats" AS (
         SELECT "vs_1"."order_id",
            COALESCE("sum"("vs_1"."vendable"), (0)::bigint) AS "total_vendable",
            (COALESCE("sum"("vs_1"."sold_units"), (0)::numeric))::bigint AS "total_sold_units",
            (COALESCE("sum"("vs_1"."lost_units"), (0)::numeric))::bigint AS "total_lost_units",
            (COALESCE("sum"("vs_1"."stock"), (0)::numeric))::bigint AS "total_stock",
            (COALESCE("sum"(("vs_1"."stock" * "vs_1"."effective_price")), (0)::numeric))::bigint AS "stock_value_at_price",
            (COALESCE("sum"(("vs_1"."stock" * "vs_1"."effective_unit_cost")), (0)::numeric))::bigint AS "stock_value_at_cost"
           FROM "public"."v_variant_stock" "vs_1"
          GROUP BY "vs_1"."order_id"
        ), "sales_stats" AS (
         SELECT "sd"."order_id",
            (COALESCE("sum"("sd"."sold_total"), (0)::numeric))::bigint AS "total_collected",
            (COALESCE("sum"("sd"."discount"), (0)::numeric))::bigint AS "total_discounts",
            (COALESCE("sum"("sd"."margin"), (0)::numeric))::bigint AS "total_sales_margin",
            "count"(DISTINCT "sd"."sale_id") AS "total_sales_count"
           FROM "public"."v_sales_detail" "sd"
          GROUP BY "sd"."order_id"
        ), "losses_stats" AS (
         SELECT "vs_1"."order_id",
            (COALESCE("sum"(("l"."quantity" * "vs_1"."effective_unit_cost")), (0)::numeric))::bigint AS "total_lost_value"
           FROM ("public"."losses" "l"
             JOIN "public"."v_variant_stock" "vs_1" ON (("vs_1"."variant_id" = "l"."variant_id")))
          WHERE ("l"."status" = 'active'::"text")
          GROUP BY "vs_1"."order_id"
        )
 SELECT "o"."id" AS "order_id",
    "o"."reference",
    "o"."order_date",
    "o"."supplier",
    "o"."status",
    "o"."received_date",
    "o"."weight_kg",
    "o"."total_cost",
    COALESCE("ss"."total_collected", (0)::bigint) AS "collected_total",
    (COALESCE("ss"."total_collected", (0)::bigint) - "o"."total_cost") AS "balance",
    GREATEST((0)::bigint, ("o"."total_cost" - COALESCE("ss"."total_collected", (0)::bigint))) AS "remaining_to_recover",
        CASE
            WHEN ("o"."total_cost" > 0) THEN LEAST(100.0, "round"((((COALESCE("ss"."total_collected", (0)::bigint))::numeric / ("o"."total_cost")::numeric) * (100)::numeric), 2))
            ELSE 100.0
        END AS "recovery_rate",
    ((COALESCE("ss"."total_collected", (0)::bigint) + COALESCE("vs"."stock_value_at_price", (0)::bigint)) - "o"."total_cost") AS "expected_profit",
    (COALESCE("ss"."total_sales_margin", (0)::bigint) - COALESCE("ls"."total_lost_value", (0)::bigint)) AS "realized_margin",
        CASE
            WHEN (COALESCE("vs"."total_vendable", (0)::bigint) > 0) THEN "round"((((COALESCE("vs"."total_sold_units", (0)::bigint))::numeric / ("vs"."total_vendable")::numeric) * (100)::numeric), 2)
            ELSE 0.0
        END AS "sell_through_rate",
    COALESCE("vs"."total_vendable", (0)::bigint) AS "vendable_units",
    COALESCE("vs"."total_sold_units", (0)::bigint) AS "sold_units",
    COALESCE("vs"."total_stock", (0)::bigint) AS "stock_units",
    COALESCE("vs"."total_lost_units", (0)::bigint) AS "lost_units",
    COALESCE("ls"."total_lost_value", (0)::bigint) AS "lost_value",
    COALESCE("vs"."stock_value_at_price", (0)::bigint) AS "stock_value_at_price",
    COALESCE("vs"."stock_value_at_cost", (0)::bigint) AS "stock_value_at_cost",
    COALESCE("ss"."total_discounts", (0)::bigint) AS "total_discounts",
    COALESCE("ss"."total_sales_count", (0)::bigint) AS "sales_count",
    (COALESCE("ss"."total_collected", (0)::bigint) >= "o"."total_cost") AS "is_recovered"
   FROM ((("public"."orders" "o"
     LEFT JOIN "var_stats" "vs" ON (("vs"."order_id" = "o"."id")))
     LEFT JOIN "sales_stats" "ss" ON (("ss"."order_id" = "o"."id")))
     LEFT JOIN "losses_stats" "ls" ON (("ls"."order_id" = "o"."id")))
  WHERE ("o"."archived_at" IS NULL);


--
-- Name: VIEW "v_order_summary"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_order_summary" IS 'Synthèse financière et d''écoulement par commande (R3 à R9, R13 à R15). Security invoker.';


--
-- Name: v_order_net_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_order_net_summary" WITH ("security_invoker"='true') AS
 WITH "linked_ads" AS (
         SELECT "ad_spends"."order_id",
            (COALESCE("sum"("ad_spends"."amount"), (0)::numeric))::bigint AS "linked_ads_total"
           FROM "public"."ad_spends"
          WHERE (("ad_spends"."status" = 'active'::"text") AND ("ad_spends"."order_id" IS NOT NULL))
          GROUP BY "ad_spends"."order_id"
        ), "linked_exp" AS (
         SELECT "expenses"."order_id",
            (COALESCE("sum"("expenses"."amount"), (0)::numeric))::bigint AS "linked_expenses_total"
           FROM "public"."expenses"
          WHERE (("expenses"."status" = 'active'::"text") AND ("expenses"."order_id" IS NOT NULL))
          GROUP BY "expenses"."order_id"
        )
 SELECT "os"."order_id",
    "os"."reference",
    "os"."order_date",
    "os"."supplier",
    "os"."status",
    "os"."received_date",
    "os"."weight_kg",
    "os"."total_cost",
    "os"."collected_total",
    "os"."balance",
    "os"."remaining_to_recover",
    "os"."recovery_rate",
    "os"."expected_profit",
    "os"."realized_margin",
    "os"."sell_through_rate",
    "os"."vendable_units",
    "os"."sold_units",
    "os"."stock_units",
    "os"."lost_units",
    "os"."lost_value",
    "os"."stock_value_at_price",
    "os"."stock_value_at_cost",
    "os"."total_discounts",
    "os"."sales_count",
    "os"."is_recovered",
    COALESCE("la"."linked_ads_total", (0)::bigint) AS "linked_ads",
    COALESCE("le"."linked_expenses_total", (0)::bigint) AS "linked_expenses",
    ((("os"."collected_total" - "os"."total_cost") - COALESCE("la"."linked_ads_total", (0)::bigint)) - COALESCE("le"."linked_expenses_total", (0)::bigint)) AS "net_balance",
    GREATEST((0)::bigint, ((("os"."total_cost" + COALESCE("la"."linked_ads_total", (0)::bigint)) + COALESCE("le"."linked_expenses_total", (0)::bigint)) - "os"."collected_total")) AS "net_remaining_to_recover",
    (("os"."realized_margin" - COALESCE("la"."linked_ads_total", (0)::bigint)) - COALESCE("le"."linked_expenses_total", (0)::bigint)) AS "net_margin",
        CASE
            WHEN (COALESCE("la"."linked_ads_total", (0)::bigint) > 0) THEN "round"((("os"."collected_total")::numeric / ("la"."linked_ads_total")::numeric), 2)
            ELSE NULL::numeric
        END AS "ad_roas"
   FROM (("public"."v_order_summary" "os"
     LEFT JOIN "linked_ads" "la" ON (("la"."order_id" = "os"."order_id")))
     LEFT JOIN "linked_exp" "le" ON (("le"."order_id" = "os"."order_id")));


--
-- Name: v_order_comparison; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_order_comparison" WITH ("security_invoker"='true') AS
 WITH "settings" AS (
         SELECT COALESCE("app_settings"."timezone", 'UTC'::"text") AS "tz"
           FROM "public"."app_settings"
         LIMIT 1
        ), "running_sales" AS (
         SELECT "sd"."order_id",
            (("sd"."sold_at" AT TIME ZONE "st"."tz"))::"date" AS "sale_date",
            "sum"("sd"."sold_total") OVER (PARTITION BY "sd"."order_id" ORDER BY "sd"."sold_at", "sd"."sale_id" ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS "running_collected"
           FROM ("public"."v_sales_detail" "sd"
             CROSS JOIN "settings" "st")
        ), "recovery_dates" AS (
         SELECT "rs"."order_id",
            "min"("rs"."sale_date") AS "recovery_date"
           FROM ("running_sales" "rs"
             JOIN "public"."orders" "o" ON (("o"."id" = "rs"."order_id")))
          WHERE ("rs"."running_collected" >= ("o"."total_cost")::numeric)
          GROUP BY "rs"."order_id"
        )
 SELECT "ons"."order_id",
    "ons"."reference",
    "ons"."order_date",
    "ons"."supplier",
    "ons"."status",
    "ons"."received_date",
    "ons"."weight_kg",
    "ons"."total_cost",
    "ons"."collected_total",
    "ons"."balance",
    "ons"."remaining_to_recover",
    "ons"."recovery_rate",
    "ons"."expected_profit",
    "ons"."realized_margin",
    "ons"."sell_through_rate",
    "ons"."vendable_units",
    "ons"."sold_units",
    "ons"."stock_units",
    "ons"."lost_units",
    "ons"."lost_value",
    "ons"."stock_value_at_price",
    "ons"."stock_value_at_cost",
    "ons"."total_discounts",
    "ons"."sales_count",
    "ons"."is_recovered",
    "ons"."linked_ads",
    "ons"."linked_expenses",
    "ons"."net_balance",
    "ons"."net_remaining_to_recover",
    "ons"."net_margin",
    "ons"."ad_roas",
    "rd"."recovery_date",
        CASE
            WHEN (("ons"."received_date" IS NOT NULL) AND ("rd"."recovery_date" IS NOT NULL)) THEN GREATEST(0, ("rd"."recovery_date" - "ons"."received_date"))
            ELSE NULL::integer
        END AS "recovery_days",
        CASE
            WHEN ("ons"."total_cost" > 0) THEN "round"(((("ons"."realized_margin")::numeric / ("ons"."total_cost")::numeric) * (100)::numeric), 1)
            ELSE NULL::numeric
        END AS "profitability_pct",
        CASE
            WHEN ((("ons"."total_cost" + "ons"."linked_ads") + "ons"."linked_expenses") > 0) THEN "round"(((("ons"."net_margin")::numeric / ((("ons"."total_cost" + "ons"."linked_ads") + "ons"."linked_expenses"))::numeric) * (100)::numeric), 1)
            ELSE NULL::numeric
        END AS "net_profitability_pct"
   FROM ("public"."v_order_net_summary" "ons"
     LEFT JOIN "recovery_dates" "rd" ON (("rd"."order_id" = "ons"."order_id")));


--
-- Name: export_orders; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."export_orders" WITH ("security_invoker"='true') AS
 SELECT "oc"."order_id",
    "oc"."reference",
    "oc"."order_date",
    "oc"."received_date",
    "oc"."supplier",
    COALESCE("o"."origin", 'Chine'::"text") AS "origin",
    "oc"."status",
    "o"."purchase_amount",
    "o"."forwarder_fee",
    "oc"."total_cost",
    "oc"."vendable_units",
    COALESCE(( SELECT "sum"("v"."quantity_damaged") AS "sum"
           FROM ("public"."variants" "v"
             JOIN "public"."items" "it" ON (("it"."id" = "v"."item_id")))
          WHERE (("it"."order_id" = "oc"."order_id") AND ("v"."archived_at" IS NULL) AND ("it"."archived_at" IS NULL))), (0)::bigint) AS "damaged_units",
    "oc"."sold_units",
    "oc"."lost_units",
    "oc"."stock_units",
    "oc"."collected_total",
    "oc"."balance",
    "oc"."remaining_to_recover",
    "oc"."recovery_rate",
    "oc"."expected_profit",
    "oc"."realized_margin",
    "oc"."linked_ads",
    "oc"."linked_expenses",
    "oc"."net_balance",
    "oc"."sell_through_rate",
    "oc"."recovery_days"
   FROM ("public"."v_order_comparison" "oc"
     JOIN "public"."orders" "o" ON (("o"."id" = "oc"."order_id")))
  ORDER BY "oc"."order_date" DESC;


--
-- Name: price_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."price_changes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "item_id" "uuid" NOT NULL,
    "variant_id" "uuid",
    "old_price" bigint,
    "new_price" bigint NOT NULL,
    "change_type" "text" NOT NULL,
    "changed_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "changed_by" "uuid" DEFAULT "auth"."uid"(),
    "note" "text",
    CONSTRAINT "price_changes_change_type_check" CHECK (("change_type" = ANY (ARRAY['initial'::"text", 'markdown'::"text", 'increase'::"text"]))),
    CONSTRAINT "price_changes_new_price_check" CHECK (("new_price" >= 0))
);

ALTER TABLE ONLY "public"."price_changes" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "price_changes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."price_changes" IS 'Historique des changements de prix. §7.2.';


--
-- Name: export_price_changes; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."export_price_changes" WITH ("security_invoker"='true') AS
 WITH "settings" AS (
         SELECT COALESCE("app_settings"."timezone", 'UTC'::"text") AS "tz"
           FROM "public"."app_settings"
         LIMIT 1
        )
 SELECT "pc"."id" AS "change_id",
    (("pc"."changed_at" AT TIME ZONE "st"."tz"))::"date" AS "change_date",
    "pc"."changed_at",
    "i"."code" AS "item_code",
    "i"."name" AS "item_name",
    COALESCE("v"."label", 'Article complet'::"text") AS "variant_label",
    "pc"."old_price",
    "pc"."new_price",
    "pc"."change_type",
    COALESCE("pc"."note", ''::"text") AS "note"
   FROM ((("public"."price_changes" "pc"
     JOIN "public"."items" "i" ON (("i"."id" = "pc"."item_id")))
     LEFT JOIN "public"."variants" "v" ON (("v"."id" = "pc"."variant_id")))
     CROSS JOIN "settings" "st")
  ORDER BY "pc"."changed_at" DESC;


--
-- Name: export_sales; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."export_sales" WITH ("security_invoker"='true') AS
 WITH "settings" AS (
         SELECT COALESCE("app_settings"."timezone", 'UTC'::"text") AS "tz"
           FROM "public"."app_settings"
         LIMIT 1
        ), "order_cost_calc" AS (
         SELECT "i_1"."order_id",
            "o_1"."total_cost",
            COALESCE("sum"(
                CASE
                    WHEN ("i_1"."unit_cost" IS NOT NULL) THEN ("i_1"."unit_cost" * ("v_1"."quantity_received" - "v_1"."quantity_damaged"))
                    ELSE (0)::bigint
                END), (0)::numeric) AS "known_cost",
            COALESCE("sum"(
                CASE
                    WHEN ("i_1"."unit_cost" IS NULL) THEN ("v_1"."quantity_received" - "v_1"."quantity_damaged")
                    ELSE 0
                END), (0)::bigint) AS "uncosted_vendable"
           FROM (("public"."items" "i_1"
             JOIN "public"."variants" "v_1" ON (("v_1"."item_id" = "i_1"."id")))
             JOIN "public"."orders" "o_1" ON (("o_1"."id" = "i_1"."order_id")))
          WHERE (("i_1"."archived_at" IS NULL) AND ("v_1"."archived_at" IS NULL) AND ("o_1"."archived_at" IS NULL))
          GROUP BY "i_1"."order_id", "o_1"."total_cost"
        )
 SELECT "s"."id" AS "sale_id",
    (("s"."sold_at" AT TIME ZONE "st"."tz"))::"date" AS "sale_date",
    "s"."sold_at",
    "o"."reference" AS "order_reference",
    "i"."code" AS "item_code",
    "i"."name" AS "item_name",
    COALESCE("c"."name", ''::"text") AS "category_name",
    "v"."label" AS "variant_label",
    "s"."quantity",
    "s"."list_price_unit",
    "s"."sold_total",
    (("s"."list_price_unit" * "s"."quantity") - "s"."sold_total") AS "discount",
    COALESCE("s"."channel", 'other'::"text") AS "channel",
        CASE
            WHEN ("i"."unit_cost" IS NOT NULL) THEN "i"."unit_cost"
            WHEN ("occ"."uncosted_vendable" > 0) THEN ("round"((GREATEST((0)::numeric, (("occ"."total_cost")::numeric - "occ"."known_cost")) / ("occ"."uncosted_vendable")::numeric)))::bigint
            ELSE (0)::bigint
        END AS "effective_unit_cost",
        CASE
            WHEN ("s"."status" = 'active'::"text") THEN ("s"."sold_total" - (
            CASE
                WHEN ("i"."unit_cost" IS NOT NULL) THEN "i"."unit_cost"
                WHEN ("occ"."uncosted_vendable" > 0) THEN ("round"((GREATEST((0)::numeric, (("occ"."total_cost")::numeric - "occ"."known_cost")) / ("occ"."uncosted_vendable")::numeric)))::bigint
                ELSE (0)::bigint
            END * "s"."quantity"))
            ELSE (0)::bigint
        END AS "margin",
    ("i"."unit_cost" IS NULL) AS "cost_is_estimated",
    "s"."status",
    COALESCE("s"."cancel_reason", ''::"text") AS "cancel_reason"
   FROM (((((("public"."sales" "s"
     JOIN "public"."variants" "v" ON (("v"."id" = "s"."variant_id")))
     JOIN "public"."items" "i" ON (("i"."id" = "v"."item_id")))
     JOIN "public"."orders" "o" ON (("o"."id" = "i"."order_id")))
     LEFT JOIN "public"."categories" "c" ON (("c"."id" = "i"."category_id")))
     LEFT JOIN "order_cost_calc" "occ" ON (("occ"."order_id" = "o"."id")))
     CROSS JOIN "settings" "st")
  ORDER BY "s"."sold_at" DESC;


--
-- Name: export_stock; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."export_stock" WITH ("security_invoker"='true') AS
 SELECT "vs"."item_code",
    "vs"."item_name",
    COALESCE("c"."name", ''::"text") AS "category_name",
    "vs"."variant_label",
    "vs"."order_reference",
    "vs"."received_date",
    "vs"."stock",
    "vs"."days_in_stock",
    "vs"."dormant_status",
    "vs"."effective_unit_cost",
    "vs"."cost_is_estimated",
    "i"."initial_price",
    "vs"."effective_price" AS "current_price",
    ("vs"."stock" * "vs"."effective_unit_cost") AS "stock_value_at_cost",
    ("vs"."stock" * "vs"."effective_price") AS "stock_value_at_price"
   FROM (("public"."v_variant_stock" "vs"
     JOIN "public"."items" "i" ON (("i"."id" = "vs"."item_id")))
     LEFT JOIN "public"."categories" "c" ON (("c"."id" = "i"."category_id")))
  WHERE ("vs"."stock" > 0)
  ORDER BY "vs"."days_in_stock" DESC, "vs"."item_name";


--
-- Name: item_code_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."item_code_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_reference_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."order_reference_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: partners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."partners" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "slot" integer NOT NULL,
    "name" "text" NOT NULL,
    "share_pct" numeric(5,2) NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "partners_share_pct_check" CHECK ((("share_pct" >= (0)::numeric) AND ("share_pct" <= (100)::numeric))),
    CONSTRAINT "partners_slot_check" CHECK (("slot" = ANY (ARRAY[1, 2])))
);

ALTER TABLE ONLY "public"."partners" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "partners"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."partners" IS 'Les 2 associés de ZADRI Luxe et leur clé de répartition (total = 100%).';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."profiles" (
    "id" "uuid" NOT NULL,
    "full_name" "text" NOT NULL,
    "role" "text" DEFAULT 'admin'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."profiles" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "profiles"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."profiles" IS 'Liste blanche des utilisateurs autorisés. §5.';


--
-- Name: COLUMN "profiles"."role"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."profiles"."role" IS 'Rôle utilisateur. Valeur unique V1 : admin. Prépare la V3.';


--
-- Name: treasury_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."treasury_accounts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "account_type" "text" NOT NULL,
    "opening_balance" bigint DEFAULT 0 NOT NULL,
    "is_system" boolean DEFAULT false NOT NULL,
    "archived_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "treasury_accounts_account_type_check" CHECK (("account_type" = ANY (ARRAY['cash'::"text", 'mobile_money'::"text", 'bank'::"text", 'history'::"text"])))
);

ALTER TABLE ONLY "public"."treasury_accounts" FORCE ROW LEVEL SECURITY;


--
-- Name: treasury_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."treasury_movements" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "account_id" "uuid" NOT NULL,
    "direction" "text" NOT NULL,
    "amount" bigint NOT NULL,
    "movement_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "category" "text" NOT NULL,
    "source_type" "text",
    "source_id" "uuid",
    "transfer_group_id" "uuid",
    "note" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "cancelled_at" timestamp with time zone,
    "cancel_reason" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "treasury_movements_amount_check" CHECK (("amount" > 0)),
    CONSTRAINT "treasury_movements_category_check" CHECK (("category" = ANY (ARRAY['sale'::"text", 'order'::"text", 'expense'::"text", 'ad_spend'::"text", 'withdrawal'::"text", 'contribution'::"text", 'transfer_in'::"text", 'transfer_out'::"text", 'opening'::"text", 'adjustment'::"text"]))),
    CONSTRAINT "treasury_movements_direction_check" CHECK (("direction" = ANY (ARRAY['in'::"text", 'out'::"text"]))),
    CONSTRAINT "treasury_movements_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'cancelled'::"text"])))
);

ALTER TABLE ONLY "public"."treasury_movements" FORCE ROW LEVEL SECURITY;


--
-- Name: treasury_reconciliations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."treasury_reconciliations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "account_id" "uuid" NOT NULL,
    "reconciled_on" "date" DEFAULT CURRENT_DATE NOT NULL,
    "calculated_balance" bigint NOT NULL,
    "real_balance" bigint NOT NULL,
    "discrepancy" bigint NOT NULL,
    "note" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."treasury_reconciliations" FORCE ROW LEVEL SECURITY;


--
-- Name: v_dormant_stock; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_dormant_stock" WITH ("security_invoker"='true') AS
 SELECT "variant_id",
    "item_id",
    "order_id",
    "order_reference",
    "item_code",
    "item_name",
    "variant_label",
    "photo_url",
    "photo_public_id",
    "received_date",
    "days_in_stock",
    "dormant_status",
    "stock",
    "effective_price",
    "effective_unit_cost",
    "cost_is_estimated",
    ("stock" * "effective_unit_cost") AS "stock_value_at_cost",
    ("stock" * "effective_price") AS "stock_value_at_price"
   FROM "public"."v_variant_stock" "vs"
  WHERE ("stock" > 0)
  ORDER BY "days_in_stock" DESC, "received_date";


--
-- Name: VIEW "v_dormant_stock"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_dormant_stock" IS 'Stock dormant (> 0) trié par ancienneté avec statuts et valeurs immobilisées (R19). Security invoker.';


--
-- Name: v_item_catalog; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_item_catalog" WITH ("security_invoker"='true') AS
 WITH "variant_totals" AS (
         SELECT "vs"."item_id",
            "count"(*) AS "variants_count",
            COALESCE("sum"("vs"."vendable"), (0)::bigint) AS "vendable_units",
            (COALESCE("sum"("vs"."sold_units"), (0)::numeric))::bigint AS "sold_units",
            (COALESCE("sum"("vs"."stock"), (0)::numeric))::bigint AS "stock_units",
                CASE "max"(
                    CASE "vs"."dormant_status"
                        WHEN 'clearance'::"text" THEN 3
                        WHEN 'watch'::"text" THEN 2
                        WHEN 'normal'::"text" THEN 1
                        ELSE 0
                    END)
                    WHEN 3 THEN 'clearance'::"text"
                    WHEN 2 THEN 'watch'::"text"
                    WHEN 1 THEN 'normal'::"text"
                    ELSE 'out_of_stock'::"text"
                END AS "dormant_status"
           FROM "public"."v_variant_stock" "vs"
          GROUP BY "vs"."item_id"
        )
 SELECT "i"."id" AS "item_id",
    "i"."code" AS "item_code",
    "i"."order_id",
    "o"."reference" AS "order_reference",
    "o"."supplier",
    "i"."category_id",
    "c"."name" AS "category_name",
    "i"."name" AS "item_name",
    "i"."description",
    "i"."photo_url",
    "i"."photo_public_id",
    "i"."list_price",
    "i"."initial_price",
    "i"."unit_cost",
        CASE
            WHEN ("i"."unit_cost" IS NOT NULL) THEN ("i"."list_price" - "i"."unit_cost")
            ELSE NULL::bigint
        END AS "unit_margin",
    "i"."received_date",
    "i"."archived_at",
    "i"."created_at",
    "i"."updated_at",
    COALESCE("vt"."variants_count", (0)::bigint) AS "variants_count",
    COALESCE("vt"."vendable_units", (0)::bigint) AS "vendable_units",
    COALESCE("vt"."sold_units", (0)::bigint) AS "sold_units",
    COALESCE("vt"."stock_units", (0)::bigint) AS "stock_units",
    COALESCE("vt"."dormant_status", 'out_of_stock'::"text") AS "dormant_status"
   FROM ((("public"."items" "i"
     JOIN "public"."orders" "o" ON (("o"."id" = "i"."order_id")))
     LEFT JOIN "public"."categories" "c" ON (("c"."id" = "i"."category_id")))
     LEFT JOIN "variant_totals" "vt" ON (("vt"."item_id" = "i"."id")))
  WHERE ("o"."archived_at" IS NULL);


--
-- Name: VIEW "v_item_catalog"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_item_catalog" IS 'Catalogue des articles avec stock, ventes, marge unitaire connue et statut d''ancienneté calculés en base.';


--
-- Name: v_item_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_item_summary" WITH ("security_invoker"='true') AS
 WITH "item_vars" AS (
         SELECT "vs"."item_id",
            COALESCE("sum"("vs"."vendable"), (0)::bigint) AS "vendable_units",
            (COALESCE("sum"("vs"."stock"), (0)::numeric))::bigint AS "stock_units"
           FROM "public"."v_variant_stock" "vs"
          GROUP BY "vs"."item_id"
        ), "item_sales" AS (
         SELECT "sd"."item_id",
            "count"(DISTINCT "sd"."sale_id") AS "sales_count",
            COALESCE("sum"("sd"."quantity"), (0)::bigint) AS "sold_units",
            (COALESCE("sum"("sd"."sold_total"), (0)::numeric))::bigint AS "sales_revenue",
                CASE
                    WHEN ("sum"("sd"."quantity") > 0) THEN "round"((("sum"(("sd"."quantity" * (("sd"."sold_at")::"date" - "i_1"."received_date"))))::numeric / ("sum"("sd"."quantity"))::numeric), 1)
                    ELSE NULL::numeric
                END AS "avg_days_to_sell"
           FROM ("public"."v_sales_detail" "sd"
             JOIN "public"."items" "i_1" ON (("i_1"."id" = "sd"."item_id")))
          GROUP BY "sd"."item_id", "i_1"."received_date"
        )
 SELECT "i"."id" AS "item_id",
    "i"."order_id",
    "o"."reference" AS "order_reference",
    "i"."category_id",
    "c"."name" AS "category_name",
    "i"."code" AS "item_code",
    "i"."name" AS "item_name",
    "i"."photo_url",
    "i"."list_price",
    "i"."initial_price",
    "i"."unit_cost",
    "i"."received_date",
    COALESCE("iv"."vendable_units", (0)::bigint) AS "vendable_units",
    COALESCE("isales"."sold_units", (0)::bigint) AS "sold_units",
    COALESCE("iv"."stock_units", (0)::bigint) AS "stock_units",
    COALESCE("isales"."sales_count", (0)::bigint) AS "sales_count",
    COALESCE("isales"."sales_revenue", (0)::bigint) AS "sales_revenue",
        CASE
            WHEN ("i"."unit_cost" IS NOT NULL) THEN (COALESCE("isales"."sales_revenue", (0)::bigint) - ("i"."unit_cost" * COALESCE("isales"."sold_units", (0)::bigint)))
            ELSE NULL::bigint
        END AS "known_margin",
    ("i"."unit_cost" IS NOT NULL) AS "has_known_cost",
        CASE
            WHEN (COALESCE("iv"."vendable_units", (0)::bigint) > 0) THEN "round"((((COALESCE("isales"."sold_units", (0)::bigint))::numeric / ("iv"."vendable_units")::numeric) * (100)::numeric), 2)
            ELSE 0.0
        END AS "sell_through_rate",
    "isales"."avg_days_to_sell"
   FROM (((("public"."items" "i"
     JOIN "public"."orders" "o" ON (("o"."id" = "i"."order_id")))
     LEFT JOIN "public"."categories" "c" ON (("c"."id" = "i"."category_id")))
     LEFT JOIN "item_vars" "iv" ON (("iv"."item_id" = "i"."id")))
     LEFT JOIN "item_sales" "isales" ON (("isales"."item_id" = "i"."id")))
  WHERE (("i"."archived_at" IS NULL) AND ("o"."archived_at" IS NULL));


--
-- Name: VIEW "v_item_summary"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_item_summary" IS 'Synthèse par article : ventes, CA, marge connue (R20), vitesse d''écoulement (R15, R16). Security invoker.';


--
-- Name: v_item_net_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_item_net_summary" WITH ("security_invoker"='true') AS
 WITH "item_ads" AS (
         SELECT "ad_spends"."item_id",
            (COALESCE("sum"("ad_spends"."amount"), (0)::numeric))::bigint AS "linked_ads_total"
           FROM "public"."ad_spends"
          WHERE (("ad_spends"."status" = 'active'::"text") AND ("ad_spends"."item_id" IS NOT NULL))
          GROUP BY "ad_spends"."item_id"
        )
 SELECT "its"."item_id",
    "its"."order_id",
    "its"."order_reference",
    "its"."category_id",
    "its"."category_name",
    "its"."item_code",
    "its"."item_name",
    "its"."photo_url",
    "its"."list_price",
    "its"."initial_price",
    "its"."unit_cost",
    "its"."received_date",
    "its"."vendable_units",
    "its"."sold_units",
    "its"."stock_units",
    "its"."sales_count",
    "its"."sales_revenue",
    "its"."known_margin",
    "its"."has_known_cost",
    "its"."sell_through_rate",
    "its"."avg_days_to_sell",
    COALESCE("ia"."linked_ads_total", (0)::bigint) AS "linked_ads",
        CASE
            WHEN ("its"."known_margin" IS NOT NULL) THEN ("its"."known_margin" - COALESCE("ia"."linked_ads_total", (0)::bigint))
            ELSE NULL::bigint
        END AS "known_net_profit",
        CASE
            WHEN (COALESCE("ia"."linked_ads_total", (0)::bigint) > 0) THEN "round"((("its"."sales_revenue")::numeric / ("ia"."linked_ads_total")::numeric), 2)
            ELSE NULL::numeric
        END AS "ad_roas"
   FROM ("public"."v_item_summary" "its"
     LEFT JOIN "item_ads" "ia" ON (("ia"."item_id" = "its"."item_id")));


--
-- Name: v_treasury_accounts_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_treasury_accounts_summary" WITH ("security_invoker"='true') AS
 WITH "mov_agg" AS (
         SELECT "treasury_movements"."account_id",
            (COALESCE("sum"(
                CASE
                    WHEN ("treasury_movements"."direction" = 'in'::"text") THEN "treasury_movements"."amount"
                    ELSE (0)::bigint
                END), (0)::numeric))::bigint AS "total_in",
            (COALESCE("sum"(
                CASE
                    WHEN ("treasury_movements"."direction" = 'out'::"text") THEN "treasury_movements"."amount"
                    ELSE (0)::bigint
                END), (0)::numeric))::bigint AS "total_out",
            "count"(*) AS "movements_count"
           FROM "public"."treasury_movements"
          WHERE ("treasury_movements"."status" = 'active'::"text")
          GROUP BY "treasury_movements"."account_id"
        ), "last_rec" AS (
         SELECT DISTINCT ON ("treasury_reconciliations"."account_id") "treasury_reconciliations"."account_id",
            "treasury_reconciliations"."reconciled_on",
            "treasury_reconciliations"."real_balance",
            "treasury_reconciliations"."discrepancy"
           FROM "public"."treasury_reconciliations"
          ORDER BY "treasury_reconciliations"."account_id", "treasury_reconciliations"."reconciled_on" DESC, "treasury_reconciliations"."created_at" DESC
        )
 SELECT "a"."id" AS "account_id",
    "a"."name",
    "a"."account_type",
    "a"."opening_balance",
    "a"."is_system",
    "a"."archived_at",
    COALESCE("ma"."total_in", (0)::bigint) AS "total_in",
    COALESCE("ma"."total_out", (0)::bigint) AS "total_out",
    (("a"."opening_balance" + COALESCE("ma"."total_in", (0)::bigint)) - COALESCE("ma"."total_out", (0)::bigint)) AS "current_balance",
    COALESCE("ma"."movements_count", (0)::bigint) AS "movements_count",
    "lr"."reconciled_on" AS "last_reconciled_on",
    "lr"."real_balance" AS "last_real_balance",
    "lr"."discrepancy" AS "last_discrepancy"
   FROM (("public"."treasury_accounts" "a"
     LEFT JOIN "mov_agg" "ma" ON (("ma"."account_id" = "a"."id")))
     LEFT JOIN "last_rec" "lr" ON (("lr"."account_id" = "a"."id")))
  WHERE ("a"."archived_at" IS NULL)
  ORDER BY "a"."is_system", "a"."created_at";


--
-- Name: withdrawals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."withdrawals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "partner_id" "uuid" NOT NULL,
    "occurred_on" "date" DEFAULT CURRENT_DATE NOT NULL,
    "amount" bigint NOT NULL,
    "type" "text" NOT NULL,
    "reason_note" "text" NOT NULL,
    "treasury_account_id" "uuid",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "cancelled_at" timestamp with time zone,
    "cancelled_by" "uuid",
    "cancel_reason" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chk_withdrawal_cancel_fields" CHECK ((("status" <> 'cancelled'::"text") OR (("cancelled_at" IS NOT NULL) AND ("cancelled_by" IS NOT NULL) AND ("cancel_reason" IS NOT NULL) AND (TRIM(BOTH FROM "cancel_reason") <> ''::"text")))),
    CONSTRAINT "withdrawals_amount_check" CHECK (("amount" > 0)),
    CONSTRAINT "withdrawals_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'cancelled'::"text"]))),
    CONSTRAINT "withdrawals_type_check" CHECK (("type" = ANY (ARRAY['withdrawal'::"text", 'contribution'::"text"])))
);

ALTER TABLE ONLY "public"."withdrawals" FORCE ROW LEVEL SECURITY;


--
-- Data for Name: ad_spends; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."ad_spends" ("id", "spend_date", "amount", "platform", "item_id", "order_id", "note", "status", "cancelled_at", "cancelled_by", "cancel_reason", "created_by", "created_at", "updated_at", "treasury_account_id") FROM stdin;
d2c139b2-75f3-41d3-80a2-e85fd847276a	2026-11-27	10000	facebook	\N	\N	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 22:13:57.080979+00	2026-11-27 22:13:57.080979+00	93e90911-142f-4759-ba13-bcb2ae9108e1
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."app_settings" ("id", "watch_after_days", "clearance_after_days", "timezone", "updated_at", "updated_by") FROM stdin;
t	30	90	UTC	2026-11-27 21:48:11.062017+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."audit_log" ("id", "table_name", "record_id", "action", "old_data", "new_data", "changed_fields", "changed_by", "changed_at") FROM stdin;
41	orders	f4908e1d-76c5-458f-a1cd-a0642a2c5db6	INSERT	\N	{"id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "notes": "[Origine: Chine]", "origin": "Chine", "status": "received", "supplier": "Usine", "reference": "CH-001", "weight_kg": null, "created_at": "2026-11-12T15:25:19.705752+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "order_date": "2026-11-12", "total_cost": 482000, "updated_at": "2026-11-12T15:25:19.705752+00:00", "archived_at": null, "description": null, "forwarder_fee": 82000, "received_date": "2026-11-12", "purchase_amount": 400000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:25:19.705752+00
42	items	9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	INSERT	\N	{"id": "9cdd5bbe-d6e8-46ac-a473-8a9210e859ea", "code": "ART-0001", "name": "Mstianq", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1794497214/zadri-luxe/vrqwy7jpmk0crusjrczw.jpg", "unit_cost": 18000, "created_at": "2026-11-12T15:38:45.146303+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 30000, "updated_at": "2026-11-12T15:38:45.146303+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 30000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/vrqwy7jpmk0crusjrczw"}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00
43	variants	82a79b04-ec43-4dde-aae3-d72dd0843218	INSERT	\N	{"id": "82a79b04-ec43-4dde-aae3-d72dd0843218", "label": "Noir", "item_id": "9cdd5bbe-d6e8-46ac-a473-8a9210e859ea", "photo_url": null, "created_at": "2026-11-12T15:38:45.146303+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-12T15:38:45.146303+00:00", "archived_at": null, "price_override": null, "photo_public_id": null, "quantity_damaged": 1, "quantity_ordered": 12, "quantity_received": 12}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00
44	variants	a68ed09b-197a-4678-a4f1-05933c9f88d4	INSERT	\N	{"id": "a68ed09b-197a-4678-a4f1-05933c9f88d4", "label": "Or", "item_id": "9cdd5bbe-d6e8-46ac-a473-8a9210e859ea", "photo_url": null, "created_at": "2026-11-12T15:38:45.146303+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-12T15:38:45.146303+00:00", "archived_at": null, "price_override": null, "photo_public_id": null, "quantity_damaged": 0, "quantity_ordered": 8, "quantity_received": 8}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00
45	items	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	INSERT	\N	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": null, "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-12T15:40:43.859994+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": null}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:40:43.859994+00
46	variants	c21395b4-9858-45e9-8e28-12e14ffd86d0	INSERT	\N	{"id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "label": "Unique", "item_id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "photo_url": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-12T15:40:43.859994+00:00", "archived_at": null, "price_override": null, "photo_public_id": null, "quantity_damaged": 2, "quantity_ordered": null, "quantity_received": 30}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:40:43.859994+00
47	sales	1d13f325-47d8-44a3-9933-cd23ccf91b10	INSERT	\N	{"id": "1d13f325-47d8-44a3-9933-cd23ccf91b10", "note": null, "status": "active", "channel": "direct", "sold_at": "2026-11-12T15:52:42.816+00:00", "quantity": 2, "created_at": "2026-11-12T15:52:44.050634+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 58000, "updated_at": "2026-11-12T15:52:44.050634+00:00", "variant_id": "82a79b04-ec43-4dde-aae3-d72dd0843218", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 30000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:52:44.050634+00
48	sales	d5b9a4d9-11e5-445d-92c6-08406245e0a6	INSERT	\N	{"id": "d5b9a4d9-11e5-445d-92c6-08406245e0a6", "note": null, "status": "active", "channel": "facebook", "sold_at": "2026-11-12T15:54:16.948+00:00", "quantity": 1, "created_at": "2026-11-12T15:54:17.43698+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 30000, "updated_at": "2026-11-12T15:54:17.43698+00:00", "variant_id": "a68ed09b-197a-4678-a4f1-05933c9f88d4", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 30000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:54:17.43698+00
49	sales	c9fe4b44-1eae-4672-8878-1c7dc8663779	INSERT	\N	{"id": "c9fe4b44-1eae-4672-8878-1c7dc8663779", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-12T15:54:45.193+00:00", "quantity": 5, "created_at": "2026-11-12T15:54:45.684463+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 50000, "updated_at": "2026-11-12T15:54:45.684463+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:54:45.684463+00
50	sales	c0fd9046-99bb-42d1-afde-3a610c82eb62	INSERT	\N	{"id": "c0fd9046-99bb-42d1-afde-3a610c82eb62", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-12T15:55:31.945+00:00", "quantity": 1, "created_at": "2026-11-12T15:55:32.429885+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 9000, "updated_at": "2026-11-12T15:55:32.429885+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:55:32.429885+00
51	sales	c0fd9046-99bb-42d1-afde-3a610c82eb62	UPDATE	{"id": "c0fd9046-99bb-42d1-afde-3a610c82eb62", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-12T15:55:31.945+00:00", "quantity": 1, "created_at": "2026-11-12T15:55:32.429885+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 9000, "updated_at": "2026-11-12T15:55:32.429885+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	{"id": "c0fd9046-99bb-42d1-afde-3a610c82eb62", "note": null, "status": "cancelled", "channel": "whatsapp", "sold_at": "2026-11-12T15:55:31.945+00:00", "quantity": 1, "created_at": "2026-11-12T15:55:32.429885+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 9000, "updated_at": "2026-11-12T15:55:59.793771+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": "2026-11-12T15:55:59.793771+00:00", "cancelled_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "cancel_reason": "retrour client", "list_price_unit": 10000}	{status,cancelled_at,cancelled_by,cancel_reason}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:55:59.793771+00
52	losses	69395a84-174c-44f7-8114-67ef05cbc7b4	INSERT	\N	{"id": "69395a84-174c-44f7-8114-67ef05cbc7b4", "note": null, "reason": "damaged", "status": "active", "quantity": 1, "created_at": "2026-11-12T16:02:14.065495+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-12T16:02:14.065495+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "occurred_on": "2026-11-12", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 16:02:14.065495+00
53	orders	84cc8db8-541f-4cc2-9ff6-579f2636e9fc	INSERT	\N	{"id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "notes": "[Origine: Local]", "origin": "Local", "status": "ordered", "supplier": "5 motres", "reference": "LOC-001", "weight_kg": null, "created_at": "2026-11-12T17:20:51.39427+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "order_date": "2026-10-13", "total_cost": 180000, "updated_at": "2026-11-12T17:20:51.39427+00:00", "archived_at": null, "description": "5 motres", "forwarder_fee": 30000, "received_date": null, "purchase_amount": 150000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 17:20:51.39427+00
54	orders	84cc8db8-541f-4cc2-9ff6-579f2636e9fc	UPDATE	{"id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "notes": "[Origine: Local]", "origin": "Local", "status": "ordered", "supplier": "5 motres", "reference": "LOC-001", "weight_kg": null, "created_at": "2026-11-12T17:20:51.39427+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "order_date": "2026-10-13", "total_cost": 180000, "updated_at": "2026-11-12T17:20:51.39427+00:00", "archived_at": null, "description": "5 motres", "forwarder_fee": 30000, "received_date": null, "purchase_amount": 150000}	{"id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "notes": "[Origine: Local]", "origin": "Local", "status": "received", "supplier": "5 motres", "reference": "LOC-001", "weight_kg": null, "created_at": "2026-11-12T17:20:51.39427+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "order_date": "2026-10-13", "total_cost": 180000, "updated_at": "2026-11-12T17:21:27.49025+00:00", "archived_at": null, "description": "5 motres", "forwarder_fee": 30000, "received_date": "2026-11-12", "purchase_amount": 150000}	{status,received_date}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 17:21:27.49025+00
55	sales	8718559b-ccc5-41b5-ab0d-79533830364e	INSERT	\N	{"id": "8718559b-ccc5-41b5-ab0d-79533830364e", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-18T14:54:41.113+00:00", "quantity": 1, "created_at": "2026-11-18T14:54:41.935955+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 10000, "updated_at": "2026-11-18T14:54:41.935955+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-18 14:54:41.935955+00
56	categories	6a8f2305-e65c-4f6e-87b0-c52a87724cf6	INSERT	\N	{"id": "6a8f2305-e65c-4f6e-87b0-c52a87724cf6", "name": "Bijoux", "created_at": "2026-11-23T09:18:43.054314+00:00"}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:18:43.054314+00
57	items	c2d3dec9-f8fe-4e9f-a544-64664b33aa63	INSERT	\N	{"id": "c2d3dec9-f8fe-4e9f-a544-64664b33aa63", "code": "ART-0003", "name": "chaine", "order_id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "photo_url": null, "unit_cost": 200, "created_at": "2026-11-23T09:24:18.535724+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 5000, "updated_at": "2026-11-23T09:24:18.535724+00:00", "archived_at": null, "category_id": "6a8f2305-e65c-4f6e-87b0-c52a87724cf6", "description": null, "initial_price": 5000, "received_date": "2026-11-12", "photo_public_id": null}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:24:18.535724+00
58	variants	245ca2d7-91fa-4159-af76-0f24ad25c4e3	INSERT	\N	{"id": "245ca2d7-91fa-4159-af76-0f24ad25c4e3", "label": "Argenté", "item_id": "c2d3dec9-f8fe-4e9f-a544-64664b33aa63", "photo_url": null, "created_at": "2026-11-23T09:24:18.535724+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-23T09:24:18.535724+00:00", "archived_at": null, "price_override": null, "photo_public_id": null, "quantity_damaged": 5, "quantity_ordered": 50, "quantity_received": 50}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:24:18.535724+00
59	items	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	UPDATE	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": null, "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-12T15:40:43.859994+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": null}	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795426241/zadri-luxe/snylisddz5hgk5z41epq.jpg", "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-23T09:30:54.769947+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/snylisddz5hgk5z41epq"}	{photo_url,photo_public_id}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:30:54.769947+00
60	items	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	UPDATE	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795426241/zadri-luxe/snylisddz5hgk5z41epq.jpg", "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-23T09:30:54.769947+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/snylisddz5hgk5z41epq"}	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet OR", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795426241/zadri-luxe/snylisddz5hgk5z41epq.jpg", "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-23T09:31:42.910718+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/snylisddz5hgk5z41epq"}	{name}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:31:42.910718+00
61	items	c2d3dec9-f8fe-4e9f-a544-64664b33aa63	UPDATE	{"id": "c2d3dec9-f8fe-4e9f-a544-64664b33aa63", "code": "ART-0003", "name": "chaine", "order_id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "photo_url": null, "unit_cost": 200, "created_at": "2026-11-23T09:24:18.535724+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 5000, "updated_at": "2026-11-23T09:24:18.535724+00:00", "archived_at": null, "category_id": "6a8f2305-e65c-4f6e-87b0-c52a87724cf6", "description": null, "initial_price": 5000, "received_date": "2026-11-12", "photo_public_id": null}	{"id": "c2d3dec9-f8fe-4e9f-a544-64664b33aa63", "code": "ART-0003", "name": "chaine", "order_id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795778277/zadri-luxe/m94kcdc0z6juk32uhrve.jpg", "unit_cost": 200, "created_at": "2026-11-23T09:24:18.535724+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 5000, "updated_at": "2026-11-27T11:18:05.819099+00:00", "archived_at": null, "category_id": "6a8f2305-e65c-4f6e-87b0-c52a87724cf6", "description": null, "initial_price": 5000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/m94kcdc0z6juk32uhrve"}	{photo_url,photo_public_id}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 11:18:05.819099+00
62	items	c2d3dec9-f8fe-4e9f-a544-64664b33aa63	UPDATE	{"id": "c2d3dec9-f8fe-4e9f-a544-64664b33aa63", "code": "ART-0003", "name": "chaine", "order_id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795778277/zadri-luxe/m94kcdc0z6juk32uhrve.jpg", "unit_cost": 200, "created_at": "2026-11-23T09:24:18.535724+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 5000, "updated_at": "2026-11-27T11:18:05.819099+00:00", "archived_at": null, "category_id": "6a8f2305-e65c-4f6e-87b0-c52a87724cf6", "description": null, "initial_price": 5000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/m94kcdc0z6juk32uhrve"}	{"id": "c2d3dec9-f8fe-4e9f-a544-64664b33aa63", "code": "ART-0003", "name": "chaine", "order_id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795778277/zadri-luxe/m94kcdc0z6juk32uhrve.jpg", "unit_cost": 200, "created_at": "2026-11-23T09:24:18.535724+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 5000, "updated_at": "2026-11-27T11:18:14.941699+00:00", "archived_at": "2026-11-27T11:18:13.584+00:00", "category_id": "6a8f2305-e65c-4f6e-87b0-c52a87724cf6", "description": null, "initial_price": 5000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/m94kcdc0z6juk32uhrve"}	{archived_at}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 11:18:14.941699+00
63	sales	ab3a3630-85f4-4544-83dc-31765378fcd2	INSERT	\N	{"id": "ab3a3630-85f4-4544-83dc-31765378fcd2", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-27T11:18:46.471+00:00", "quantity": 2, "created_at": "2026-11-27T11:18:47.83963+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 20000, "updated_at": "2026-11-27T11:18:47.83963+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 11:18:47.83963+00
64	app_settings	00000000-0000-0000-0000-000000000001	UPDATE	{"id": true, "timezone": "UTC", "updated_at": null, "updated_by": null, "watch_after_days": 30, "clearance_after_days": 60}	{"id": true, "timezone": "UTC", "updated_at": "2026-11-27T21:48:11.062017+00:00", "updated_by": null, "watch_after_days": 30, "clearance_after_days": 90}	{clearance_after_days}	\N	2026-11-27 21:48:11.062017+00
65	treasury_movements	54b58017-13c0-4fdf-b4ae-f6c1976bd53a	INSERT	\N	{"id": "54b58017-13c0-4fdf-b4ae-f6c1976bd53a", "note": "Commande CH-001 (Usine)", "amount": 482000, "status": "active", "category": "order", "direction": "out", "source_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "account_id": "e69419a5-ff9e-42f6-b07e-095190c86040", "created_at": "2026-11-27T21:48:12.324652+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-27T21:48:12.324652+00:00", "source_type": "order", "cancelled_at": null, "cancel_reason": null, "movement_date": "2026-11-12", "transfer_group_id": null}	\N	\N	2026-11-27 21:48:12.324652+00
66	treasury_movements	f1dfa792-e9d2-47b7-abde-9d566aeaccc5	INSERT	\N	{"id": "f1dfa792-e9d2-47b7-abde-9d566aeaccc5", "note": "Commande LOC-001 (5 motres)", "amount": 180000, "status": "active", "category": "order", "direction": "out", "source_id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "account_id": "e69419a5-ff9e-42f6-b07e-095190c86040", "created_at": "2026-11-27T21:48:12.324652+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-27T21:48:12.324652+00:00", "source_type": "order", "cancelled_at": null, "cancel_reason": null, "movement_date": "2026-10-13", "transfer_group_id": null}	\N	\N	2026-11-27 21:48:12.324652+00
67	treasury_movements	116b3f8d-1e77-4e93-aff7-8ba91e82ecad	INSERT	\N	{"id": "116b3f8d-1e77-4e93-aff7-8ba91e82ecad", "note": "Encaissement vente", "amount": 58000, "status": "active", "category": "sale", "direction": "in", "source_id": "1d13f325-47d8-44a3-9933-cd23ccf91b10", "account_id": "e69419a5-ff9e-42f6-b07e-095190c86040", "created_at": "2026-11-27T21:48:12.324652+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-27T21:48:12.324652+00:00", "source_type": "sale", "cancelled_at": null, "cancel_reason": null, "movement_date": "2026-11-12", "transfer_group_id": null}	\N	\N	2026-11-27 21:48:12.324652+00
68	treasury_movements	847d32d6-9025-439a-9b20-07429e996296	INSERT	\N	{"id": "847d32d6-9025-439a-9b20-07429e996296", "note": "Encaissement vente", "amount": 30000, "status": "active", "category": "sale", "direction": "in", "source_id": "d5b9a4d9-11e5-445d-92c6-08406245e0a6", "account_id": "e69419a5-ff9e-42f6-b07e-095190c86040", "created_at": "2026-11-27T21:48:12.324652+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-27T21:48:12.324652+00:00", "source_type": "sale", "cancelled_at": null, "cancel_reason": null, "movement_date": "2026-11-12", "transfer_group_id": null}	\N	\N	2026-11-27 21:48:12.324652+00
69	treasury_movements	b7b270d8-b631-4bcb-967d-f7827ecd3f5f	INSERT	\N	{"id": "b7b270d8-b631-4bcb-967d-f7827ecd3f5f", "note": "Encaissement vente", "amount": 50000, "status": "active", "category": "sale", "direction": "in", "source_id": "c9fe4b44-1eae-4672-8878-1c7dc8663779", "account_id": "e69419a5-ff9e-42f6-b07e-095190c86040", "created_at": "2026-11-27T21:48:12.324652+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-27T21:48:12.324652+00:00", "source_type": "sale", "cancelled_at": null, "cancel_reason": null, "movement_date": "2026-11-12", "transfer_group_id": null}	\N	\N	2026-11-27 21:48:12.324652+00
70	treasury_movements	79282993-f966-4297-82da-df138b8187bf	INSERT	\N	{"id": "79282993-f966-4297-82da-df138b8187bf", "note": "Encaissement vente", "amount": 10000, "status": "active", "category": "sale", "direction": "in", "source_id": "8718559b-ccc5-41b5-ab0d-79533830364e", "account_id": "e69419a5-ff9e-42f6-b07e-095190c86040", "created_at": "2026-11-27T21:48:12.324652+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-27T21:48:12.324652+00:00", "source_type": "sale", "cancelled_at": null, "cancel_reason": null, "movement_date": "2026-11-18", "transfer_group_id": null}	\N	\N	2026-11-27 21:48:12.324652+00
71	treasury_movements	0c598057-b90f-48ce-9828-4da391bb74e0	INSERT	\N	{"id": "0c598057-b90f-48ce-9828-4da391bb74e0", "note": "Encaissement vente", "amount": 20000, "status": "active", "category": "sale", "direction": "in", "source_id": "ab3a3630-85f4-4544-83dc-31765378fcd2", "account_id": "e69419a5-ff9e-42f6-b07e-095190c86040", "created_at": "2026-11-27T21:48:12.324652+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-27T21:48:12.324652+00:00", "source_type": "sale", "cancelled_at": null, "cancel_reason": null, "movement_date": "2026-11-27", "transfer_group_id": null}	\N	\N	2026-11-27 21:48:12.324652+00
72	treasury_movements	197f4bee-3e6d-4158-9b7d-58654c50c9aa	INSERT	\N	{"id": "197f4bee-3e6d-4158-9b7d-58654c50c9aa", "note": "Publicité Facebook", "amount": 10000, "status": "active", "category": "ad_spend", "direction": "out", "source_id": "d2c139b2-75f3-41d3-80a2-e85fd847276a", "account_id": "93e90911-142f-4759-ba13-bcb2ae9108e1", "created_at": "2026-11-27T22:13:57.080979+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-27T22:13:57.080979+00:00", "source_type": "ad_spend", "cancelled_at": null, "cancel_reason": null, "movement_date": "2026-11-27", "transfer_group_id": null}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 22:13:57.080979+00
73	ad_spends	d2c139b2-75f3-41d3-80a2-e85fd847276a	INSERT	\N	{"id": "d2c139b2-75f3-41d3-80a2-e85fd847276a", "note": null, "amount": 10000, "status": "active", "item_id": null, "order_id": null, "platform": "facebook", "created_at": "2026-11-27T22:13:57.080979+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "spend_date": "2026-11-27", "updated_at": "2026-11-27T22:13:57.080979+00:00", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "treasury_account_id": "93e90911-142f-4759-ba13-bcb2ae9108e1"}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 22:13:57.080979+00
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."categories" ("id", "name", "created_at") FROM stdin;
a15d3628-fa48-4507-bbf8-54c5ec5ed948	Montre cuire	2026-10-29 17:30:22.781609+00
6a8f2305-e65c-4f6e-87b0-c52a87724cf6	Bijoux	2026-11-23 09:18:43.054314+00
\.


--
-- Data for Name: expense_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."expense_categories" ("id", "name", "created_at") FROM stdin;
7d9554db-9cf3-4af9-acbc-3b8bbf440d78	Emballage	2026-11-27 21:48:11.43562+00
c7d01ef9-47e2-4d0a-a11c-1373b8da5815	Livraison	2026-11-27 21:48:11.43562+00
acdff7e0-c552-4153-bd75-d39afa6762fa	Déplacement	2026-11-27 21:48:11.43562+00
95c9711a-e7f3-4435-8b88-422f19fe1fc1	Abonnement	2026-11-27 21:48:11.43562+00
e3883423-d78f-4962-b761-1f184234c959	Téléphone / Internet	2026-11-27 21:48:11.43562+00
eb0a1319-5120-4b61-99f7-0cad4ce07e2a	Matériel	2026-11-27 21:48:11.43562+00
95ee58aa-d101-4de0-9920-2a3f2a28bb9d	Commission	2026-11-27 21:48:11.43562+00
9accf157-85ea-49cf-8d24-c6763a3c804b	Autre	2026-11-27 21:48:11.43562+00
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."expenses" ("id", "expense_date", "category_id", "amount", "description", "order_id", "receipt_url", "receipt_public_id", "status", "cancelled_at", "cancelled_by", "cancel_reason", "created_by", "created_at", "updated_at", "treasury_account_id") FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."items" ("id", "code", "order_id", "category_id", "name", "description", "photo_url", "photo_public_id", "list_price", "initial_price", "unit_cost", "received_date", "archived_at", "created_by", "created_at", "updated_at") FROM stdin;
9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	ART-0001	f4908e1d-76c5-458f-a1cd-a0642a2c5db6	\N	Mstianq	\N	https://res.cloudinary.com/dycdqyspf/image/upload/v1794497214/zadri-luxe/vrqwy7jpmk0crusjrczw.jpg	zadri-luxe/vrqwy7jpmk0crusjrczw	30000	30000	18000	2026-11-12	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00	2026-11-12 15:38:45.146303+00
f79fef6f-4c9b-4388-a3c6-2b300aa19d97	ART-0002	f4908e1d-76c5-458f-a1cd-a0642a2c5db6	\N	Bracelet OR	\N	https://res.cloudinary.com/dycdqyspf/image/upload/v1795426241/zadri-luxe/snylisddz5hgk5z41epq.jpg	zadri-luxe/snylisddz5hgk5z41epq	10000	10000	\N	2026-11-12	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:40:43.859994+00	2026-11-23 09:31:42.910718+00
c2d3dec9-f8fe-4e9f-a544-64664b33aa63	ART-0003	84cc8db8-541f-4cc2-9ff6-579f2636e9fc	6a8f2305-e65c-4f6e-87b0-c52a87724cf6	chaine	\N	https://res.cloudinary.com/dycdqyspf/image/upload/v1795778277/zadri-luxe/m94kcdc0z6juk32uhrve.jpg	zadri-luxe/m94kcdc0z6juk32uhrve	5000	5000	200	2026-11-12	2026-11-27 11:18:13.584+00	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:24:18.535724+00	2026-11-27 11:18:14.941699+00
\.


--
-- Data for Name: losses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."losses" ("id", "variant_id", "quantity", "reason", "occurred_on", "note", "status", "cancelled_at", "cancelled_by", "cancel_reason", "created_by", "created_at", "updated_at") FROM stdin;
69395a84-174c-44f7-8114-67ef05cbc7b4	c21395b4-9858-45e9-8e28-12e14ffd86d0	1	damaged	2026-11-12	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 16:02:14.065495+00	2026-11-12 16:02:14.065495+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."orders" ("id", "reference", "order_date", "supplier", "description", "status", "purchase_amount", "forwarder_fee", "weight_kg", "received_date", "notes", "archived_at", "created_by", "created_at", "updated_at", "origin", "treasury_account_id") FROM stdin;
f4908e1d-76c5-458f-a1cd-a0642a2c5db6	CH-001	2026-11-12	Usine	\N	received	400000	82000	\N	2026-11-12	[Origine: Chine]	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:25:19.705752+00	2026-11-12 15:25:19.705752+00	Chine	\N
84cc8db8-541f-4cc2-9ff6-579f2636e9fc	LOC-001	2026-10-13	5 motres	5 motres	received	150000	30000	\N	2026-11-12	[Origine: Local]	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 17:20:51.39427+00	2026-11-12 17:21:27.49025+00	Local	\N
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."partners" ("id", "slot", "name", "share_pct", "created_at", "updated_at") FROM stdin;
a54ce4a5-3be6-43ba-ada2-f9bbad3d7668	1	Associé 1	50.00	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
de641d52-796b-4b21-9b20-37dd89caf1f6	2	Associé 2	50.00	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
\.


--
-- Data for Name: price_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."price_changes" ("id", "item_id", "variant_id", "old_price", "new_price", "change_type", "changed_at", "changed_by", "note") FROM stdin;
51b52138-ab90-4ce9-bac7-e5bfeb1a5de3	9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	\N	\N	30000	initial	2026-11-12 15:38:45.146303+00	f0dae27b-e462-4930-969c-5e63e9c81347	Création de l'article
6575f1ac-11d2-431e-a03b-aab765489bf1	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	\N	\N	10000	initial	2026-11-12 15:40:43.859994+00	f0dae27b-e462-4930-969c-5e63e9c81347	Création de l'article
0892c6ff-4078-446d-a177-2d19dbb39c78	c2d3dec9-f8fe-4e9f-a544-64664b33aa63	\N	\N	5000	initial	2026-11-23 09:24:18.535724+00	f0dae27b-e462-4930-969c-5e63e9c81347	Création de l'article
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."profiles" ("id", "full_name", "role", "created_at") FROM stdin;
f0dae27b-e462-4930-969c-5e63e9c81347	POODA Dérick	admin	2026-09-30 15:42:45.38755+00
6bf8f80d-7498-4dd5-89c4-8998aa9cae25	OUEDRAOGO Aziz	admin	2026-09-30 15:42:45.989793+00
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."sales" ("id", "variant_id", "quantity", "list_price_unit", "sold_total", "channel", "sold_at", "note", "status", "cancelled_at", "cancelled_by", "cancel_reason", "created_by", "created_at", "updated_at", "treasury_account_id") FROM stdin;
1d13f325-47d8-44a3-9933-cd23ccf91b10	82a79b04-ec43-4dde-aae3-d72dd0843218	2	30000	58000	direct	2026-11-12 15:52:42.816+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:52:44.050634+00	2026-11-12 15:52:44.050634+00	\N
d5b9a4d9-11e5-445d-92c6-08406245e0a6	a68ed09b-197a-4678-a4f1-05933c9f88d4	1	30000	30000	facebook	2026-11-12 15:54:16.948+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:54:17.43698+00	2026-11-12 15:54:17.43698+00	\N
c9fe4b44-1eae-4672-8878-1c7dc8663779	c21395b4-9858-45e9-8e28-12e14ffd86d0	5	10000	50000	whatsapp	2026-11-12 15:54:45.193+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:54:45.684463+00	2026-11-12 15:54:45.684463+00	\N
c0fd9046-99bb-42d1-afde-3a610c82eb62	c21395b4-9858-45e9-8e28-12e14ffd86d0	1	10000	9000	whatsapp	2026-11-12 15:55:31.945+00	\N	cancelled	2026-11-12 15:55:59.793771+00	f0dae27b-e462-4930-969c-5e63e9c81347	retrour client	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:55:32.429885+00	2026-11-12 15:55:59.793771+00	\N
8718559b-ccc5-41b5-ab0d-79533830364e	c21395b4-9858-45e9-8e28-12e14ffd86d0	1	10000	10000	whatsapp	2026-11-18 14:54:41.113+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-18 14:54:41.935955+00	2026-11-18 14:54:41.935955+00	\N
ab3a3630-85f4-4544-83dc-31765378fcd2	c21395b4-9858-45e9-8e28-12e14ffd86d0	2	10000	20000	whatsapp	2026-11-27 11:18:46.471+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 11:18:47.83963+00	2026-11-27 11:18:47.83963+00	\N
\.


--
-- Data for Name: treasury_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."treasury_accounts" ("id", "name", "account_type", "opening_balance", "is_system", "archived_at", "created_at", "updated_at") FROM stdin;
e69419a5-ff9e-42f6-b07e-095190c86040	Historique	history	0	t	\N	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
93e90911-142f-4759-ba13-bcb2ae9108e1	Caisse	cash	0	f	\N	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
b61e865a-8084-449d-8ec7-70b22016865a	Mobile Money	mobile_money	0	f	\N	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
\.


--
-- Data for Name: treasury_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."treasury_movements" ("id", "account_id", "direction", "amount", "movement_date", "category", "source_type", "source_id", "transfer_group_id", "note", "status", "cancelled_at", "cancel_reason", "created_by", "created_at", "updated_at") FROM stdin;
54b58017-13c0-4fdf-b4ae-f6c1976bd53a	e69419a5-ff9e-42f6-b07e-095190c86040	out	482000	2026-11-12	order	order	f4908e1d-76c5-458f-a1cd-a0642a2c5db6	\N	Commande CH-001 (Usine)	active	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
f1dfa792-e9d2-47b7-abde-9d566aeaccc5	e69419a5-ff9e-42f6-b07e-095190c86040	out	180000	2026-10-13	order	order	84cc8db8-541f-4cc2-9ff6-579f2636e9fc	\N	Commande LOC-001 (5 motres)	active	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
116b3f8d-1e77-4e93-aff7-8ba91e82ecad	e69419a5-ff9e-42f6-b07e-095190c86040	in	58000	2026-11-12	sale	sale	1d13f325-47d8-44a3-9933-cd23ccf91b10	\N	Encaissement vente	active	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
847d32d6-9025-439a-9b20-07429e996296	e69419a5-ff9e-42f6-b07e-095190c86040	in	30000	2026-11-12	sale	sale	d5b9a4d9-11e5-445d-92c6-08406245e0a6	\N	Encaissement vente	active	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
b7b270d8-b631-4bcb-967d-f7827ecd3f5f	e69419a5-ff9e-42f6-b07e-095190c86040	in	50000	2026-11-12	sale	sale	c9fe4b44-1eae-4672-8878-1c7dc8663779	\N	Encaissement vente	active	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
79282993-f966-4297-82da-df138b8187bf	e69419a5-ff9e-42f6-b07e-095190c86040	in	10000	2026-11-18	sale	sale	8718559b-ccc5-41b5-ab0d-79533830364e	\N	Encaissement vente	active	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
0c598057-b90f-48ce-9828-4da391bb74e0	e69419a5-ff9e-42f6-b07e-095190c86040	in	20000	2026-11-27	sale	sale	ab3a3630-85f4-4544-83dc-31765378fcd2	\N	Encaissement vente	active	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 21:48:12.324652+00	2026-11-27 21:48:12.324652+00
197f4bee-3e6d-4158-9b7d-58654c50c9aa	93e90911-142f-4759-ba13-bcb2ae9108e1	out	10000	2026-11-27	ad_spend	ad_spend	d2c139b2-75f3-41d3-80a2-e85fd847276a	\N	Publicité Facebook	active	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-27 22:13:57.080979+00	2026-11-27 22:13:57.080979+00
\.


--
-- Data for Name: treasury_reconciliations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."treasury_reconciliations" ("id", "account_id", "reconciled_on", "calculated_balance", "real_balance", "discrepancy", "note", "created_by", "created_at") FROM stdin;
\.


--
-- Data for Name: variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."variants" ("id", "item_id", "label", "photo_url", "photo_public_id", "price_override", "quantity_ordered", "quantity_received", "quantity_damaged", "archived_at", "created_by", "created_at", "updated_at") FROM stdin;
82a79b04-ec43-4dde-aae3-d72dd0843218	9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	Noir	\N	\N	\N	12	12	1	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00	2026-11-12 15:38:45.146303+00
a68ed09b-197a-4678-a4f1-05933c9f88d4	9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	Or	\N	\N	\N	8	8	0	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00	2026-11-12 15:38:45.146303+00
c21395b4-9858-45e9-8e28-12e14ffd86d0	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	Unique	\N	\N	\N	\N	30	2	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:40:43.859994+00	2026-11-23 09:31:43.143843+00
245ca2d7-91fa-4159-af76-0f24ad25c4e3	c2d3dec9-f8fe-4e9f-a544-64664b33aa63	Argenté	\N	\N	\N	50	50	5	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:24:18.535724+00	2026-11-27 11:18:06.126575+00
\.


--
-- Data for Name: withdrawals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."withdrawals" ("id", "partner_id", "occurred_on", "amount", "type", "reason_note", "treasury_account_id", "status", "cancelled_at", "cancelled_by", "cancel_reason", "created_by", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."audit_log_id_seq"', 73, true);


--
-- Name: item_code_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."item_code_seq"', 3, true);


--
-- Name: order_reference_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."order_reference_seq"', 1, false);


--
-- Name: ad_spends ad_spends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."ad_spends"
    ADD CONSTRAINT "ad_spends_pkey" PRIMARY KEY ("id");


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."app_settings"
    ADD CONSTRAINT "app_settings_pkey" PRIMARY KEY ("id");


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."audit_log"
    ADD CONSTRAINT "audit_log_pkey" PRIMARY KEY ("id");


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."categories"
    ADD CONSTRAINT "categories_pkey" PRIMARY KEY ("id");


--
-- Name: expense_categories expense_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."expense_categories"
    ADD CONSTRAINT "expense_categories_pkey" PRIMARY KEY ("id");


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."expenses"
    ADD CONSTRAINT "expenses_pkey" PRIMARY KEY ("id");


--
-- Name: items items_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_code_key" UNIQUE ("code");


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_pkey" PRIMARY KEY ("id");


--
-- Name: losses losses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."losses"
    ADD CONSTRAINT "losses_pkey" PRIMARY KEY ("id");


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("id");


--
-- Name: orders orders_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_reference_key" UNIQUE ("reference");


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."partners"
    ADD CONSTRAINT "partners_pkey" PRIMARY KEY ("id");


--
-- Name: partners partners_slot_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."partners"
    ADD CONSTRAINT "partners_slot_key" UNIQUE ("slot");


--
-- Name: price_changes price_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_changes"
    ADD CONSTRAINT "price_changes_pkey" PRIMARY KEY ("id");


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."sales"
    ADD CONSTRAINT "sales_pkey" PRIMARY KEY ("id");


--
-- Name: treasury_accounts treasury_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."treasury_accounts"
    ADD CONSTRAINT "treasury_accounts_pkey" PRIMARY KEY ("id");


--
-- Name: treasury_movements treasury_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."treasury_movements"
    ADD CONSTRAINT "treasury_movements_pkey" PRIMARY KEY ("id");


--
-- Name: treasury_reconciliations treasury_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."treasury_reconciliations"
    ADD CONSTRAINT "treasury_reconciliations_pkey" PRIMARY KEY ("id");


--
-- Name: variants variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."variants"
    ADD CONSTRAINT "variants_pkey" PRIMARY KEY ("id");


--
-- Name: withdrawals withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."withdrawals"
    ADD CONSTRAINT "withdrawals_pkey" PRIMARY KEY ("id");


--
-- Name: idx_ad_spends_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_ad_spends_date" ON "public"."ad_spends" USING "btree" ("spend_date" DESC);


--
-- Name: idx_ad_spends_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_ad_spends_item_id" ON "public"."ad_spends" USING "btree" ("item_id");


--
-- Name: idx_ad_spends_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_ad_spends_order_id" ON "public"."ad_spends" USING "btree" ("order_id");


--
-- Name: idx_ad_spends_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_ad_spends_status" ON "public"."ad_spends" USING "btree" ("status");


--
-- Name: idx_audit_log_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_audit_log_changed_at" ON "public"."audit_log" USING "btree" ("changed_at" DESC);


--
-- Name: idx_audit_log_changed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_audit_log_changed_by" ON "public"."audit_log" USING "btree" ("changed_by");


--
-- Name: idx_audit_log_table_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_audit_log_table_record" ON "public"."audit_log" USING "btree" ("table_name", "record_id");


--
-- Name: idx_expenses_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_expenses_category_id" ON "public"."expenses" USING "btree" ("category_id");


--
-- Name: idx_expenses_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_expenses_date" ON "public"."expenses" USING "btree" ("expense_date" DESC);


--
-- Name: idx_expenses_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_expenses_order_id" ON "public"."expenses" USING "btree" ("order_id");


--
-- Name: idx_expenses_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_expenses_status" ON "public"."expenses" USING "btree" ("status");


--
-- Name: idx_items_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_items_category_id" ON "public"."items" USING "btree" ("category_id");


--
-- Name: idx_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_items_order_id" ON "public"."items" USING "btree" ("order_id");


--
-- Name: idx_losses_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_losses_status" ON "public"."losses" USING "btree" ("status");


--
-- Name: idx_losses_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_losses_variant_id" ON "public"."losses" USING "btree" ("variant_id");


--
-- Name: idx_price_changes_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_price_changes_changed_at" ON "public"."price_changes" USING "btree" ("changed_at");


--
-- Name: idx_price_changes_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_price_changes_item_id" ON "public"."price_changes" USING "btree" ("item_id");


--
-- Name: idx_price_changes_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_price_changes_variant_id" ON "public"."price_changes" USING "btree" ("variant_id");


--
-- Name: idx_sales_sold_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_sales_sold_at" ON "public"."sales" USING "btree" ("sold_at");


--
-- Name: idx_sales_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_sales_status" ON "public"."sales" USING "btree" ("status");


--
-- Name: idx_sales_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_sales_variant_id" ON "public"."sales" USING "btree" ("variant_id");


--
-- Name: idx_treasury_movements_account_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_treasury_movements_account_date" ON "public"."treasury_movements" USING "btree" ("account_id", "movement_date" DESC);


--
-- Name: idx_treasury_movements_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_treasury_movements_status" ON "public"."treasury_movements" USING "btree" ("status");


--
-- Name: idx_treasury_reconciliations_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_treasury_reconciliations_account" ON "public"."treasury_reconciliations" USING "btree" ("account_id", "reconciled_on" DESC);


--
-- Name: idx_variants_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_variants_item_id" ON "public"."variants" USING "btree" ("item_id");


--
-- Name: idx_withdrawals_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_withdrawals_date" ON "public"."withdrawals" USING "btree" ("occurred_on" DESC);


--
-- Name: idx_withdrawals_partner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_withdrawals_partner_id" ON "public"."withdrawals" USING "btree" ("partner_id");


--
-- Name: idx_withdrawals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_withdrawals_status" ON "public"."withdrawals" USING "btree" ("status");


--
-- Name: uq_categories_name_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "uq_categories_name_ci" ON "public"."categories" USING "btree" ("lower"("name"));


--
-- Name: uq_expense_categories_name_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "uq_expense_categories_name_ci" ON "public"."expense_categories" USING "btree" ("lower"("name"));


--
-- Name: uq_treasury_accounts_name_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "uq_treasury_accounts_name_ci" ON "public"."treasury_accounts" USING "btree" ("lower"("name"));


--
-- Name: uq_treasury_movements_source; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "uq_treasury_movements_source" ON "public"."treasury_movements" USING "btree" ("source_type", "source_id") WHERE (("source_type" IS NOT NULL) AND ("source_id" IS NOT NULL));


--
-- Name: uq_variants_item_label_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "uq_variants_item_label_ci" ON "public"."variants" USING "btree" ("item_id", "lower"("label"));


--
-- Name: ad_spends trg_ad_spends_treasury; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_ad_spends_treasury" AFTER INSERT OR UPDATE ON "public"."ad_spends" FOR EACH ROW EXECUTE FUNCTION "public"."fn_sync_ad_spend_to_treasury"();


--
-- Name: ad_spends trg_ad_spends_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_ad_spends_updated_at" BEFORE UPDATE ON "public"."ad_spends" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: ad_spends trg_audit_ad_spends; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_ad_spends" AFTER INSERT OR UPDATE ON "public"."ad_spends" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: app_settings trg_audit_app_settings; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_app_settings" AFTER INSERT OR UPDATE ON "public"."app_settings" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: categories trg_audit_categories; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_categories" AFTER INSERT OR UPDATE ON "public"."categories" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: expense_categories trg_audit_expense_categories; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_expense_categories" AFTER INSERT OR UPDATE ON "public"."expense_categories" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: expenses trg_audit_expenses; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_expenses" AFTER INSERT OR UPDATE ON "public"."expenses" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: items trg_audit_items; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_items" AFTER INSERT OR UPDATE ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: losses trg_audit_losses; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_losses" AFTER INSERT OR UPDATE ON "public"."losses" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: orders trg_audit_orders; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_orders" AFTER INSERT OR UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: partners trg_audit_partners; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_partners" AFTER INSERT OR UPDATE ON "public"."partners" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: sales trg_audit_sales; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_sales" AFTER INSERT OR UPDATE ON "public"."sales" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: treasury_accounts trg_audit_treasury_accounts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_treasury_accounts" AFTER INSERT OR UPDATE ON "public"."treasury_accounts" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: treasury_movements trg_audit_treasury_movements; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_treasury_movements" AFTER INSERT OR UPDATE ON "public"."treasury_movements" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: treasury_reconciliations trg_audit_treasury_reconciliations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_treasury_reconciliations" AFTER INSERT OR UPDATE ON "public"."treasury_reconciliations" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: variants trg_audit_variants; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_variants" AFTER INSERT OR UPDATE ON "public"."variants" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: withdrawals trg_audit_withdrawals; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_withdrawals" AFTER INSERT OR UPDATE ON "public"."withdrawals" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: expenses trg_expenses_treasury; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_expenses_treasury" AFTER INSERT OR UPDATE ON "public"."expenses" FOR EACH ROW EXECUTE FUNCTION "public"."fn_sync_expense_to_treasury"();


--
-- Name: expenses trg_expenses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_expenses_updated_at" BEFORE UPDATE ON "public"."expenses" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: items trg_items_before_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_items_before_update" BEFORE UPDATE ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."fn_items_before_update"();


--
-- Name: items trg_items_code; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_items_code" BEFORE INSERT ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."fn_generate_item_code"();


--
-- Name: items trg_items_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_items_updated_at" BEFORE UPDATE ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: losses trg_losses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_losses_updated_at" BEFORE UPDATE ON "public"."losses" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: orders trg_orders_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_orders_reference" BEFORE INSERT ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."fn_generate_order_reference"();


--
-- Name: orders trg_orders_treasury; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_orders_treasury" AFTER INSERT OR UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."fn_sync_order_to_treasury"();


--
-- Name: orders trg_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_orders_updated_at" BEFORE UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: partners trg_partners_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_partners_updated_at" BEFORE UPDATE ON "public"."partners" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: price_changes trg_price_changes_before_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_price_changes_before_insert" BEFORE INSERT ON "public"."price_changes" FOR EACH ROW EXECUTE FUNCTION "public"."fn_price_changes_before_insert"();


--
-- Name: sales trg_sales_before_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_sales_before_update" BEFORE UPDATE ON "public"."sales" FOR EACH ROW EXECUTE FUNCTION "public"."fn_sales_before_update"();


--
-- Name: sales trg_sales_treasury; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_sales_treasury" AFTER INSERT OR UPDATE ON "public"."sales" FOR EACH ROW EXECUTE FUNCTION "public"."fn_sync_sale_to_treasury"();


--
-- Name: sales trg_sales_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_sales_updated_at" BEFORE UPDATE ON "public"."sales" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: treasury_accounts trg_treasury_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_treasury_accounts_updated_at" BEFORE UPDATE ON "public"."treasury_accounts" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: treasury_movements trg_treasury_movements_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_treasury_movements_updated_at" BEFORE UPDATE ON "public"."treasury_movements" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: variants trg_variants_before_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_variants_before_update" BEFORE UPDATE ON "public"."variants" FOR EACH ROW EXECUTE FUNCTION "public"."fn_variants_before_update"();


--
-- Name: variants trg_variants_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_variants_updated_at" BEFORE UPDATE ON "public"."variants" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: withdrawals trg_withdrawals_treasury; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_withdrawals_treasury" AFTER INSERT OR UPDATE ON "public"."withdrawals" FOR EACH ROW EXECUTE FUNCTION "public"."fn_sync_withdrawal_to_treasury"();


--
-- Name: withdrawals trg_withdrawals_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_withdrawals_updated_at" BEFORE UPDATE ON "public"."withdrawals" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: ad_spends ad_spends_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."ad_spends"
    ADD CONSTRAINT "ad_spends_item_id_fkey" FOREIGN KEY ("item_id") REFERENCES "public"."items"("id");


--
-- Name: ad_spends ad_spends_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."ad_spends"
    ADD CONSTRAINT "ad_spends_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id");


--
-- Name: ad_spends ad_spends_treasury_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."ad_spends"
    ADD CONSTRAINT "ad_spends_treasury_account_id_fkey" FOREIGN KEY ("treasury_account_id") REFERENCES "public"."treasury_accounts"("id");


--
-- Name: app_settings app_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."app_settings"
    ADD CONSTRAINT "app_settings_updated_by_fkey" FOREIGN KEY ("updated_by") REFERENCES "auth"."users"("id");


--
-- Name: expenses expenses_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."expenses"
    ADD CONSTRAINT "expenses_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."expense_categories"("id");


--
-- Name: expenses expenses_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."expenses"
    ADD CONSTRAINT "expenses_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id");


--
-- Name: expenses expenses_treasury_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."expenses"
    ADD CONSTRAINT "expenses_treasury_account_id_fkey" FOREIGN KEY ("treasury_account_id") REFERENCES "public"."treasury_accounts"("id");


--
-- Name: items items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id");


--
-- Name: items items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE RESTRICT;


--
-- Name: losses losses_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."losses"
    ADD CONSTRAINT "losses_variant_id_fkey" FOREIGN KEY ("variant_id") REFERENCES "public"."variants"("id");


--
-- Name: orders orders_treasury_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_treasury_account_id_fkey" FOREIGN KEY ("treasury_account_id") REFERENCES "public"."treasury_accounts"("id");


--
-- Name: price_changes price_changes_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_changes"
    ADD CONSTRAINT "price_changes_item_id_fkey" FOREIGN KEY ("item_id") REFERENCES "public"."items"("id");


--
-- Name: price_changes price_changes_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_changes"
    ADD CONSTRAINT "price_changes_variant_id_fkey" FOREIGN KEY ("variant_id") REFERENCES "public"."variants"("id");


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sales sales_treasury_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."sales"
    ADD CONSTRAINT "sales_treasury_account_id_fkey" FOREIGN KEY ("treasury_account_id") REFERENCES "public"."treasury_accounts"("id");


--
-- Name: sales sales_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."sales"
    ADD CONSTRAINT "sales_variant_id_fkey" FOREIGN KEY ("variant_id") REFERENCES "public"."variants"("id");


--
-- Name: treasury_movements treasury_movements_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."treasury_movements"
    ADD CONSTRAINT "treasury_movements_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."treasury_accounts"("id");


--
-- Name: treasury_reconciliations treasury_reconciliations_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."treasury_reconciliations"
    ADD CONSTRAINT "treasury_reconciliations_account_id_fkey" FOREIGN KEY ("account_id") REFERENCES "public"."treasury_accounts"("id");


--
-- Name: variants variants_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."variants"
    ADD CONSTRAINT "variants_item_id_fkey" FOREIGN KEY ("item_id") REFERENCES "public"."items"("id") ON DELETE RESTRICT;


--
-- Name: withdrawals withdrawals_partner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."withdrawals"
    ADD CONSTRAINT "withdrawals_partner_id_fkey" FOREIGN KEY ("partner_id") REFERENCES "public"."partners"("id");


--
-- Name: withdrawals withdrawals_treasury_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."withdrawals"
    ADD CONSTRAINT "withdrawals_treasury_account_id_fkey" FOREIGN KEY ("treasury_account_id") REFERENCES "public"."treasury_accounts"("id");


--
-- Name: ad_spends; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."ad_spends" ENABLE ROW LEVEL SECURITY;

--
-- Name: ad_spends ad_spends_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ad_spends_insert_authorized" ON "public"."ad_spends" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: ad_spends ad_spends_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ad_spends_select_authorized" ON "public"."ad_spends" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: ad_spends ad_spends_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ad_spends_update_authorized" ON "public"."ad_spends" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: app_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."app_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: app_settings app_settings_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "app_settings_select_authorized" ON "public"."app_settings" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."audit_log" ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log audit_log_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "audit_log_select_authorized" ON "public"."audit_log" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."categories" ENABLE ROW LEVEL SECURITY;

--
-- Name: categories categories_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "categories_insert_authorized" ON "public"."categories" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: categories categories_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "categories_select_authorized" ON "public"."categories" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: categories categories_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "categories_update_authorized" ON "public"."categories" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: expense_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."expense_categories" ENABLE ROW LEVEL SECURITY;

--
-- Name: expense_categories expense_categories_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "expense_categories_insert_authorized" ON "public"."expense_categories" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: expense_categories expense_categories_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "expense_categories_select_authorized" ON "public"."expense_categories" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: expense_categories expense_categories_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "expense_categories_update_authorized" ON "public"."expense_categories" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: expenses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."expenses" ENABLE ROW LEVEL SECURITY;

--
-- Name: expenses expenses_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "expenses_insert_authorized" ON "public"."expenses" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: expenses expenses_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "expenses_select_authorized" ON "public"."expenses" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: expenses expenses_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "expenses_update_authorized" ON "public"."expenses" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."items" ENABLE ROW LEVEL SECURITY;

--
-- Name: items items_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "items_insert_authorized" ON "public"."items" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: items items_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "items_select_authorized" ON "public"."items" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: items items_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "items_update_authorized" ON "public"."items" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: losses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."losses" ENABLE ROW LEVEL SECURITY;

--
-- Name: losses losses_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "losses_insert_authorized" ON "public"."losses" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: losses losses_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "losses_select_authorized" ON "public"."losses" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: losses losses_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "losses_update_authorized" ON "public"."losses" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."orders" ENABLE ROW LEVEL SECURITY;

--
-- Name: orders orders_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "orders_insert_authorized" ON "public"."orders" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: orders orders_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "orders_select_authorized" ON "public"."orders" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: orders orders_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "orders_update_authorized" ON "public"."orders" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: partners; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."partners" ENABLE ROW LEVEL SECURITY;

--
-- Name: partners partners_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "partners_select_authorized" ON "public"."partners" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: partners partners_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "partners_update_authorized" ON "public"."partners" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: price_changes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."price_changes" ENABLE ROW LEVEL SECURITY;

--
-- Name: price_changes price_changes_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "price_changes_insert_authorized" ON "public"."price_changes" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: price_changes price_changes_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "price_changes_select_authorized" ON "public"."price_changes" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "profiles_select_authorized" ON "public"."profiles" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: sales; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."sales" ENABLE ROW LEVEL SECURITY;

--
-- Name: sales sales_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "sales_insert_authorized" ON "public"."sales" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: sales sales_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "sales_select_authorized" ON "public"."sales" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: sales sales_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "sales_update_authorized" ON "public"."sales" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: treasury_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."treasury_accounts" ENABLE ROW LEVEL SECURITY;

--
-- Name: treasury_accounts treasury_accounts_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "treasury_accounts_insert_authorized" ON "public"."treasury_accounts" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: treasury_accounts treasury_accounts_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "treasury_accounts_select_authorized" ON "public"."treasury_accounts" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: treasury_accounts treasury_accounts_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "treasury_accounts_update_authorized" ON "public"."treasury_accounts" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: treasury_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."treasury_movements" ENABLE ROW LEVEL SECURITY;

--
-- Name: treasury_movements treasury_movements_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "treasury_movements_insert_authorized" ON "public"."treasury_movements" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: treasury_movements treasury_movements_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "treasury_movements_select_authorized" ON "public"."treasury_movements" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: treasury_movements treasury_movements_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "treasury_movements_update_authorized" ON "public"."treasury_movements" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: treasury_reconciliations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."treasury_reconciliations" ENABLE ROW LEVEL SECURITY;

--
-- Name: treasury_reconciliations treasury_reconciliations_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "treasury_reconciliations_insert_authorized" ON "public"."treasury_reconciliations" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: treasury_reconciliations treasury_reconciliations_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "treasury_reconciliations_select_authorized" ON "public"."treasury_reconciliations" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: variants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."variants" ENABLE ROW LEVEL SECURITY;

--
-- Name: variants variants_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "variants_insert_authorized" ON "public"."variants" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: variants variants_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "variants_select_authorized" ON "public"."variants" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: variants variants_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "variants_update_authorized" ON "public"."variants" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: withdrawals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."withdrawals" ENABLE ROW LEVEL SECURITY;

--
-- Name: withdrawals withdrawals_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "withdrawals_insert_authorized" ON "public"."withdrawals" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: withdrawals withdrawals_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "withdrawals_select_authorized" ON "public"."withdrawals" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: withdrawals withdrawals_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "withdrawals_update_authorized" ON "public"."withdrawals" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- PostgreSQL database dump complete
--

\unrestrict fPRxRki7NaUFuf8HGNrbQbnVm7SZArPXRn3k1R837Yb89MABXaEGftiKAPORbw6

