--
-- PostgreSQL database dump
--

\restrict fRI5mo1DtDiOtdZYhMjmRgkywSUeKkcdbliEQNvsvLI7K8AaUAgLNGk8Ecs8hoX

-- Dumped from database version 17.11
-- Dumped by pg_dump version 18.7 (Ubuntu 18.7-1.pgdg26.04+5)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS "variants_update_authorized" ON "public"."variants";
DROP POLICY IF EXISTS "variants_select_authorized" ON "public"."variants";
DROP POLICY IF EXISTS "variants_insert_authorized" ON "public"."variants";
DROP POLICY IF EXISTS "sales_update_authorized" ON "public"."sales";
DROP POLICY IF EXISTS "sales_select_authorized" ON "public"."sales";
DROP POLICY IF EXISTS "sales_insert_authorized" ON "public"."sales";
DROP POLICY IF EXISTS "profiles_select_authorized" ON "public"."profiles";
DROP POLICY IF EXISTS "price_changes_select_authorized" ON "public"."price_changes";
DROP POLICY IF EXISTS "price_changes_insert_authorized" ON "public"."price_changes";
DROP POLICY IF EXISTS "orders_update_authorized" ON "public"."orders";
DROP POLICY IF EXISTS "orders_select_authorized" ON "public"."orders";
DROP POLICY IF EXISTS "orders_insert_authorized" ON "public"."orders";
DROP POLICY IF EXISTS "losses_update_authorized" ON "public"."losses";
DROP POLICY IF EXISTS "losses_select_authorized" ON "public"."losses";
DROP POLICY IF EXISTS "losses_insert_authorized" ON "public"."losses";
DROP POLICY IF EXISTS "items_update_authorized" ON "public"."items";
DROP POLICY IF EXISTS "items_select_authorized" ON "public"."items";
DROP POLICY IF EXISTS "items_insert_authorized" ON "public"."items";
DROP POLICY IF EXISTS "categories_update_authorized" ON "public"."categories";
DROP POLICY IF EXISTS "categories_select_authorized" ON "public"."categories";
DROP POLICY IF EXISTS "categories_insert_authorized" ON "public"."categories";
DROP POLICY IF EXISTS "audit_log_select_authorized" ON "public"."audit_log";
DROP POLICY IF EXISTS "app_settings_update_authorized" ON "public"."app_settings";
DROP POLICY IF EXISTS "app_settings_select_authorized" ON "public"."app_settings";
ALTER TABLE IF EXISTS ONLY "public"."variants" DROP CONSTRAINT IF EXISTS "variants_item_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."sales" DROP CONSTRAINT IF EXISTS "sales_variant_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."profiles" DROP CONSTRAINT IF EXISTS "profiles_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."price_changes" DROP CONSTRAINT IF EXISTS "price_changes_variant_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."price_changes" DROP CONSTRAINT IF EXISTS "price_changes_item_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."losses" DROP CONSTRAINT IF EXISTS "losses_variant_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."items" DROP CONSTRAINT IF EXISTS "items_order_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."items" DROP CONSTRAINT IF EXISTS "items_category_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."app_settings" DROP CONSTRAINT IF EXISTS "app_settings_updated_by_fkey";
DROP TRIGGER IF EXISTS "trg_variants_updated_at" ON "public"."variants";
DROP TRIGGER IF EXISTS "trg_variants_before_update" ON "public"."variants";
DROP TRIGGER IF EXISTS "trg_sales_updated_at" ON "public"."sales";
DROP TRIGGER IF EXISTS "trg_orders_updated_at" ON "public"."orders";
DROP TRIGGER IF EXISTS "trg_orders_reference" ON "public"."orders";
DROP TRIGGER IF EXISTS "trg_losses_updated_at" ON "public"."losses";
DROP TRIGGER IF EXISTS "trg_items_updated_at" ON "public"."items";
DROP TRIGGER IF EXISTS "trg_items_code" ON "public"."items";
DROP TRIGGER IF EXISTS "trg_items_before_update" ON "public"."items";
DROP TRIGGER IF EXISTS "trg_audit_variants" ON "public"."variants";
DROP TRIGGER IF EXISTS "trg_audit_sales" ON "public"."sales";
DROP TRIGGER IF EXISTS "trg_audit_orders" ON "public"."orders";
DROP TRIGGER IF EXISTS "trg_audit_losses" ON "public"."losses";
DROP TRIGGER IF EXISTS "trg_audit_items" ON "public"."items";
DROP TRIGGER IF EXISTS "trg_audit_categories" ON "public"."categories";
DROP TRIGGER IF EXISTS "trg_audit_app_settings" ON "public"."app_settings";
DROP INDEX IF EXISTS "public"."uq_variants_item_label_ci";
DROP INDEX IF EXISTS "public"."uq_categories_name_ci";
DROP INDEX IF EXISTS "public"."idx_variants_item_id";
DROP INDEX IF EXISTS "public"."idx_sales_variant_id";
DROP INDEX IF EXISTS "public"."idx_sales_status";
DROP INDEX IF EXISTS "public"."idx_sales_sold_at";
DROP INDEX IF EXISTS "public"."idx_price_changes_variant_id";
DROP INDEX IF EXISTS "public"."idx_price_changes_item_id";
DROP INDEX IF EXISTS "public"."idx_price_changes_changed_at";
DROP INDEX IF EXISTS "public"."idx_losses_variant_id";
DROP INDEX IF EXISTS "public"."idx_losses_status";
DROP INDEX IF EXISTS "public"."idx_items_order_id";
DROP INDEX IF EXISTS "public"."idx_items_category_id";
DROP INDEX IF EXISTS "public"."idx_audit_log_table_record";
DROP INDEX IF EXISTS "public"."idx_audit_log_changed_by";
DROP INDEX IF EXISTS "public"."idx_audit_log_changed_at";
ALTER TABLE IF EXISTS ONLY "public"."variants" DROP CONSTRAINT IF EXISTS "variants_pkey";
ALTER TABLE IF EXISTS ONLY "public"."sales" DROP CONSTRAINT IF EXISTS "sales_pkey";
ALTER TABLE IF EXISTS ONLY "public"."profiles" DROP CONSTRAINT IF EXISTS "profiles_pkey";
ALTER TABLE IF EXISTS ONLY "public"."price_changes" DROP CONSTRAINT IF EXISTS "price_changes_pkey";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_reference_key";
ALTER TABLE IF EXISTS ONLY "public"."orders" DROP CONSTRAINT IF EXISTS "orders_pkey";
ALTER TABLE IF EXISTS ONLY "public"."losses" DROP CONSTRAINT IF EXISTS "losses_pkey";
ALTER TABLE IF EXISTS ONLY "public"."items" DROP CONSTRAINT IF EXISTS "items_pkey";
ALTER TABLE IF EXISTS ONLY "public"."items" DROP CONSTRAINT IF EXISTS "items_code_key";
ALTER TABLE IF EXISTS ONLY "public"."categories" DROP CONSTRAINT IF EXISTS "categories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."audit_log" DROP CONSTRAINT IF EXISTS "audit_log_pkey";
ALTER TABLE IF EXISTS ONLY "public"."app_settings" DROP CONSTRAINT IF EXISTS "app_settings_pkey";
DROP VIEW IF EXISTS "public"."v_order_summary";
DROP VIEW IF EXISTS "public"."v_item_summary";
DROP VIEW IF EXISTS "public"."v_sales_detail";
DROP VIEW IF EXISTS "public"."v_item_catalog";
DROP VIEW IF EXISTS "public"."v_dormant_stock";
DROP VIEW IF EXISTS "public"."v_variant_stock";
DROP TABLE IF EXISTS "public"."variants";
DROP TABLE IF EXISTS "public"."sales";
DROP TABLE IF EXISTS "public"."profiles";
DROP TABLE IF EXISTS "public"."price_changes";
DROP TABLE IF EXISTS "public"."orders";
DROP SEQUENCE IF EXISTS "public"."order_reference_seq";
DROP TABLE IF EXISTS "public"."losses";
DROP TABLE IF EXISTS "public"."items";
DROP SEQUENCE IF EXISTS "public"."item_code_seq";
DROP TABLE IF EXISTS "public"."categories";
DROP TABLE IF EXISTS "public"."audit_log";
DROP TABLE IF EXISTS "public"."app_settings";
DROP FUNCTION IF EXISTS "public"."stats_by_month"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."stats_by_day"("p_from" "date", "p_to" "date");
DROP FUNCTION IF EXISTS "public"."rls_auto_enable"();
DROP FUNCTION IF EXISTS "public"."is_authorized_user"();
DROP FUNCTION IF EXISTS "public"."fn_variants_before_update"();
DROP FUNCTION IF EXISTS "public"."fn_set_updated_at"();
DROP FUNCTION IF EXISTS "public"."fn_items_before_update"();
DROP FUNCTION IF EXISTS "public"."fn_generate_order_reference"();
DROP FUNCTION IF EXISTS "public"."fn_generate_item_code"();
DROP FUNCTION IF EXISTS "public"."fn_audit_trigger"();
DROP FUNCTION IF EXISTS "public"."create_sale"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_sold_total" bigint, "p_channel" "text", "p_sold_at" timestamp with time zone, "p_note" "text");
DROP FUNCTION IF EXISTS "public"."create_loss"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_reason" "text", "p_occurred_on" "date", "p_note" "text");
DROP FUNCTION IF EXISTS "public"."create_item_with_variants"("p_order_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb");
DROP FUNCTION IF EXISTS "public"."change_price"("p_item_id" "uuid", "p_variant_id" "uuid", "p_new_price" bigint, "p_note" "text");
DROP FUNCTION IF EXISTS "public"."cancel_sale"("p_id" "uuid", "p_reason" "text");
DROP FUNCTION IF EXISTS "public"."cancel_loss"("p_id" "uuid", "p_reason" "text");
DROP SCHEMA IF EXISTS "public";
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "public";


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: cancel_loss("uuid", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."cancel_loss"("p_id" "uuid", "p_reason" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_status text;
BEGIN
  IF p_reason IS NULL OR trim(p_reason) = '' THEN
    RAISE EXCEPTION 'Le motif d''annulation de la perte est obligatoire.';
  END IF;

  SELECT status INTO v_status
  FROM losses
  WHERE id = p_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Perte introuvable.';
  END IF;

  IF v_status = 'cancelled' THEN
    RAISE EXCEPTION 'Cette sortie en perte est déjà annulée.';
  END IF;

  UPDATE losses
  SET
    status        = 'cancelled',
    cancelled_at  = now(),
    cancelled_by  = auth.uid(),
    cancel_reason = trim(p_reason),
    updated_at    = now()
  WHERE id = p_id;
END;
$$;


--
-- Name: FUNCTION "cancel_loss"("p_id" "uuid", "p_reason" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."cancel_loss"("p_id" "uuid", "p_reason" "text") IS 'Annule une sortie en perte avec motif obligatoire. Restitue le stock.';


--
-- Name: cancel_sale("uuid", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."cancel_sale"("p_id" "uuid", "p_reason" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_status text;
BEGIN
  IF p_reason IS NULL OR trim(p_reason) = '' THEN
    RAISE EXCEPTION 'Le motif d''annulation est obligatoire.';
  END IF;

  SELECT status INTO v_status
  FROM sales
  WHERE id = p_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Vente introuvable.';
  END IF;

  IF v_status = 'cancelled' THEN
    RAISE EXCEPTION 'Cette vente est déjà annulée.';
  END IF;

  UPDATE sales
  SET
    status        = 'cancelled',
    cancelled_at  = now(),
    cancelled_by  = auth.uid(),
    cancel_reason = trim(p_reason),
    updated_at    = now()
  WHERE id = p_id;
END;
$$;


--
-- Name: FUNCTION "cancel_sale"("p_id" "uuid", "p_reason" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."cancel_sale"("p_id" "uuid", "p_reason" "text") IS 'Annule une vente de manière irréversible avec motif obligatoire. Le stock est restitué automatiquement.';


--
-- Name: change_price("uuid", "uuid", bigint, "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."change_price"("p_item_id" "uuid", "p_variant_id" "uuid" DEFAULT NULL::"uuid", "p_new_price" bigint DEFAULT NULL::bigint, "p_note" "text" DEFAULT NULL::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_old_price   bigint;
  v_change_type text;
BEGIN
  IF p_new_price IS NULL OR p_new_price < 0 THEN
    RAISE EXCEPTION 'Le nouveau prix doit être un entier positif ou nul.';
  END IF;

  -- Déverrouillage éphémère de la modification de prix pour la transaction courante (B7)
  PERFORM set_config('app.allow_price_change', 'on', true);

  IF p_variant_id IS NOT NULL THEN
    -- Cas d'une variante spécifique : vérification d'existence, appartenance et verrouillage (Point 1)
    SELECT coalesce(v.price_override, i.list_price)
    INTO v_old_price
    FROM variants v
    JOIN items i ON i.id = v.item_id
    WHERE v.id = p_variant_id AND v.item_id = p_item_id
    FOR UPDATE OF v;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Variante introuvable pour cet article.';
    END IF;

    -- Contrôle du prix identique (Point mineur)
    IF p_new_price = v_old_price THEN
      RAISE EXCEPTION 'Le nouveau prix (%) est identique au prix actuel.', p_new_price;
    ELSIF p_new_price < v_old_price THEN
      v_change_type := 'markdown';
    ELSE
      v_change_type := 'increase';
    END IF;

    UPDATE variants
    SET price_override = p_new_price,
        updated_at     = now()
    WHERE id = p_variant_id;

    INSERT INTO price_changes (
      item_id,
      variant_id,
      old_price,
      new_price,
      change_type,
      note,
      changed_by
    ) VALUES (
      p_item_id,
      p_variant_id,
      v_old_price,
      p_new_price,
      v_change_type,
      p_note,
      auth.uid()
    );

  ELSE
    -- Cas de l'article global
    SELECT list_price
    INTO v_old_price
    FROM items
    WHERE id = p_item_id
    FOR UPDATE;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Article introuvable.';
    END IF;

    -- Contrôle du prix identique (Point mineur)
    IF p_new_price = v_old_price THEN
      RAISE EXCEPTION 'Le nouveau prix (%) est identique au prix actuel.', p_new_price;
    ELSIF p_new_price < v_old_price THEN
      v_change_type := 'markdown';
    ELSE
      v_change_type := 'increase';
    END IF;

    UPDATE items
    SET list_price = p_new_price,
        updated_at = now()
    WHERE id = p_item_id;

    INSERT INTO price_changes (
      item_id,
      variant_id,
      old_price,
      new_price,
      change_type,
      note,
      changed_by
    ) VALUES (
      p_item_id,
      NULL,
      v_old_price,
      p_new_price,
      v_change_type,
      p_note,
      auth.uid()
    );
  END IF;
END;
$$;


--
-- Name: FUNCTION "change_price"("p_item_id" "uuid", "p_variant_id" "uuid", "p_new_price" bigint, "p_note" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."change_price"("p_item_id" "uuid", "p_variant_id" "uuid", "p_new_price" bigint, "p_note" "text") IS 'Modifie le prix d''un article ou d''une variante et consigne la modification dans price_changes.';


--
-- Name: create_item_with_variants("uuid", "text", bigint, bigint, "uuid", "text", "text", "text", "jsonb"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."create_item_with_variants"("p_order_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint DEFAULT NULL::bigint, "p_category_id" "uuid" DEFAULT NULL::"uuid", "p_description" "text" DEFAULT NULL::"text", "p_photo_url" "text" DEFAULT NULL::"text", "p_photo_public_id" "text" DEFAULT NULL::"text", "p_variants" "jsonb" DEFAULT '[]'::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_item_id         uuid;
  v_item_code       text;
  v_order_status    text;
  v_received_date   date;
  v_var_elem        jsonb;
  v_var_id          uuid;
  v_var_label       text;
  v_var_rec         int;
  v_var_dam         int;
  v_var_ord         int;
  v_var_ovr         bigint;
  v_var_photo_url   text;
  v_var_photo_pid   text;
  v_created_var_ids uuid[] := '{}';
BEGIN
  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'Le nom de l''article est obligatoire.';
  END IF;

  IF p_list_price IS NULL OR p_list_price < 0 THEN
    RAISE EXCEPTION 'Le prix fixé doit être un entier positif ou nul.';
  END IF;

  IF p_unit_cost IS NOT NULL AND p_unit_cost < 0 THEN
    RAISE EXCEPTION 'Le coût unitaire ne peut pas être négatif.';
  END IF;

  -- Vérification de la commande d'origine et statut 'received' requis (Point 2)
  SELECT status, received_date
  INTO v_order_status, v_received_date
  FROM orders
  WHERE id = p_order_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Commande d''origine introuvable.';
  END IF;

  IF v_order_status <> 'received' OR v_received_date IS NULL THEN
    RAISE EXCEPTION 'Impossible de créer un article : la commande n''est pas encore reçue.';
  END IF;

  -- Au moins une variante avec sa quantité reçue est obligatoire (Point 3)
  IF p_variants IS NULL OR jsonb_array_length(p_variants) = 0 THEN
    RAISE EXCEPTION 'Au moins une variante avec sa quantité reçue est obligatoire.';
  END IF;

  -- Création de l'article (initial_price = list_price)
  v_item_id := gen_random_uuid();

  INSERT INTO items (
    id,
    order_id,
    category_id,
    name,
    description,
    photo_url,
    photo_public_id,
    list_price,
    initial_price,
    unit_cost,
    received_date,
    created_by
  ) VALUES (
    v_item_id,
    p_order_id,
    p_category_id,
    trim(p_name),
    p_description,
    p_photo_url,
    p_photo_public_id,
    p_list_price,
    p_list_price,
    p_unit_cost,
    v_received_date,
    auth.uid()
  )
  RETURNING code INTO v_item_code;

  -- Enregistrement du prix initial dans price_changes (§7.2)
  INSERT INTO price_changes (
    item_id,
    variant_id,
    old_price,
    new_price,
    change_type,
    note,
    changed_by
  ) VALUES (
    v_item_id,
    NULL,
    NULL,
    p_list_price,
    'initial',
    'Création de l''article',
    auth.uid()
  );

  -- Création des variantes fournies
  FOR v_var_elem IN SELECT * FROM jsonb_array_elements(p_variants)
  LOOP
    v_var_label     := coalesce(v_var_elem ->> 'label', 'Unique');
    v_var_rec       := coalesce((v_var_elem ->> 'quantity_received')::int, 0);
    v_var_dam       := coalesce((v_var_elem ->> 'quantity_damaged')::int, 0);
    v_var_ord       := (v_var_elem ->> 'quantity_ordered')::int;
    v_var_ovr       := (v_var_elem ->> 'price_override')::bigint;
    v_var_photo_url := v_var_elem ->> 'photo_url';
    v_var_photo_pid := v_var_elem ->> 'photo_public_id';

    IF v_var_rec < 0 THEN
      RAISE EXCEPTION 'La quantité reçue pour la variante "%" ne peut pas être négative.', v_var_label;
    END IF;

    IF v_var_dam < 0 THEN
      RAISE EXCEPTION 'La quantité abîmée pour la variante "%" ne peut pas être négative.', v_var_label;
    END IF;

    IF v_var_dam > v_var_rec THEN
      RAISE EXCEPTION 'La quantité abîmée (%) ne peut pas dépasser la quantité reçue (%) pour la variante "%".',
        v_var_dam, v_var_rec, v_var_label;
    END IF;

    INSERT INTO variants (
      item_id,
      label,
      photo_url,
      photo_public_id,
      price_override,
      quantity_ordered,
      quantity_received,
      quantity_damaged,
      created_by
    ) VALUES (
      v_item_id,
      v_var_label,
      v_var_photo_url,
      v_var_photo_pid,
      v_var_ovr,
      v_var_ord,
      v_var_rec,
      v_var_dam,
      auth.uid()
    )
    RETURNING id INTO v_var_id;

    v_created_var_ids := array_append(v_created_var_ids, v_var_id);

    IF v_var_ovr IS NOT NULL THEN
      INSERT INTO price_changes (
        item_id,
        variant_id,
        old_price,
        new_price,
        change_type,
        note,
        changed_by
      ) VALUES (
        v_item_id,
        v_var_id,
        NULL,
        v_var_ovr,
        'initial',
        'Prix spécifique initial de la variante',
        auth.uid()
      );
    END IF;
  END LOOP;

  RETURN jsonb_build_object(
    'item_id', v_item_id,
    'code', v_item_code,
    'variant_ids', to_jsonb(v_created_var_ids)
  );
END;
$$;


--
-- Name: FUNCTION "create_item_with_variants"("p_order_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."create_item_with_variants"("p_order_id" "uuid", "p_name" "text", "p_list_price" bigint, "p_unit_cost" bigint, "p_category_id" "uuid", "p_description" "text", "p_photo_url" "text", "p_photo_public_id" "text", "p_variants" "jsonb") IS 'Crée un article et ses variantes en une seule transaction atomique. Contrat : exige au moins une variante avec sa quantité reçue.';


--
-- Name: create_loss("uuid", "uuid", integer, "text", "date", "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."create_loss"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_reason" "text", "p_occurred_on" "date" DEFAULT CURRENT_DATE, "p_note" "text" DEFAULT NULL::"text") RETURNS "uuid"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_loss_id      uuid;
  v_qty_received int;
  v_qty_damaged  int;
  v_sold         bigint;
  v_lost         bigint;
  v_vendable     bigint;
  v_stock        bigint;
BEGIN
  IF p_quantity IS NULL OR p_quantity <= 0 THEN
    RAISE EXCEPTION 'La quantité sortie en perte doit être strictement positive.';
  END IF;

  IF p_reason IS NULL OR p_reason NOT IN ('damaged', 'unsellable', 'gift', 'lost', 'other') THEN
    RAISE EXCEPTION 'Motif de perte invalide : %.', p_reason;
  END IF;

  SELECT quantity_received, quantity_damaged
  INTO v_qty_received, v_qty_damaged
  FROM variants
  WHERE id = p_variant_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Variante introuvable.';
  END IF;

  v_vendable := v_qty_received - v_qty_damaged;

  SELECT coalesce(sum(quantity), 0)
  INTO v_sold
  FROM sales
  WHERE variant_id = p_variant_id AND status = 'active';

  SELECT coalesce(sum(quantity), 0)
  INTO v_lost
  FROM losses
  WHERE variant_id = p_variant_id AND status = 'active';

  v_stock := v_vendable - v_sold - v_lost;

  IF v_stock < p_quantity THEN
    RAISE EXCEPTION 'Stock insuffisant pour enregistrer cette perte : % disponible(s), % demandée(s).',
      v_stock, p_quantity;
  END IF;

  v_loss_id := coalesce(p_id, gen_random_uuid());

  INSERT INTO losses (
    id,
    variant_id,
    quantity,
    reason,
    occurred_on,
    note,
    status,
    created_by
  ) VALUES (
    v_loss_id,
    p_variant_id,
    p_quantity,
    p_reason,
    coalesce(p_occurred_on, CURRENT_DATE),
    p_note,
    'active',
    auth.uid()
  );

  RETURN v_loss_id;
END;
$$;


--
-- Name: FUNCTION "create_loss"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_reason" "text", "p_occurred_on" "date", "p_note" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."create_loss"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_reason" "text", "p_occurred_on" "date", "p_note" "text") IS 'Enregistre une sortie en perte après vérification du stock disponible.';


--
-- Name: create_sale("uuid", "uuid", integer, bigint, "text", timestamp with time zone, "text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."create_sale"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_sold_total" bigint, "p_channel" "text" DEFAULT NULL::"text", "p_sold_at" timestamp with time zone DEFAULT "now"(), "p_note" "text" DEFAULT NULL::"text") RETURNS "uuid"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_sale_id         uuid;
  v_order_status    text;
  v_item_list_price bigint;
  v_var_price_ovr   bigint;
  v_qty_received    int;
  v_qty_damaged     int;
  v_sold            bigint;
  v_lost            bigint;
  v_vendable        bigint;
  v_stock           bigint;
  v_unit_list_price bigint;
BEGIN
  IF p_quantity IS NULL OR p_quantity <= 0 THEN
    RAISE EXCEPTION 'La quantité vendue doit être strictement positive.';
  END IF;

  IF p_sold_total IS NULL OR p_sold_total <= 0 THEN
    RAISE EXCEPTION 'Le montant encaissé doit être strictement positif.';
  END IF;

  IF p_channel IS NOT NULL AND p_channel NOT IN ('facebook', 'whatsapp', 'direct', 'other') THEN
    RAISE EXCEPTION 'Canal de vente invalide : %.', p_channel;
  END IF;

  -- Verrouillage FOR UPDATE de la variante pour éviter toute vente concurrente du même stock
  SELECT
    o.status,
    i.list_price,
    v.price_override,
    v.quantity_received,
    v.quantity_damaged
  INTO
    v_order_status,
    v_item_list_price,
    v_var_price_ovr,
    v_qty_received,
    v_qty_damaged
  FROM variants v
  JOIN items i ON i.id = v.item_id
  JOIN orders o ON o.id = i.order_id
  WHERE v.id = p_variant_id
  FOR UPDATE OF v;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Variante introuvable.';
  END IF;

  -- Règle : Vente refusée si la commande n'est pas reçue (§7.3 / Cas limite 2)
  IF v_order_status <> 'received' THEN
    RAISE EXCEPTION 'Vente impossible : la commande associée n''est pas encore reçue.';
  END IF;

  -- Calcul du stock disponible (R1 & R2)
  v_vendable := v_qty_received - v_qty_damaged;

  SELECT coalesce(sum(quantity), 0)
  INTO v_sold
  FROM sales
  WHERE variant_id = p_variant_id AND status = 'active';

  SELECT coalesce(sum(quantity), 0)
  INTO v_lost
  FROM losses
  WHERE variant_id = p_variant_id AND status = 'active';

  v_stock := v_vendable - v_sold - v_lost;

  IF v_stock < p_quantity THEN
    RAISE EXCEPTION 'Stock insuffisant : % pièce(s) disponible(s), % demandée(s).', v_stock, p_quantity;
  END IF;

  -- Prix effectif unitaire au moment de la vente (R8)
  v_unit_list_price := coalesce(v_var_price_ovr, v_item_list_price);
  v_sale_id := coalesce(p_id, gen_random_uuid());

  INSERT INTO sales (
    id,
    variant_id,
    quantity,
    list_price_unit,
    sold_total,
    channel,
    sold_at,
    note,
    status,
    created_by
  ) VALUES (
    v_sale_id,
    p_variant_id,
    p_quantity,
    v_unit_list_price,
    p_sold_total,
    p_channel,
    coalesce(p_sold_at, now()),
    p_note,
    'active',
    auth.uid()
  );

  RETURN v_sale_id;
END;
$$;


--
-- Name: FUNCTION "create_sale"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_sold_total" bigint, "p_channel" "text", "p_sold_at" timestamp with time zone, "p_note" "text"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."create_sale"("p_id" "uuid", "p_variant_id" "uuid", "p_quantity" integer, "p_sold_total" bigint, "p_channel" "text", "p_sold_at" timestamp with time zone, "p_note" "text") IS 'Crée une vente de manière atomique avec verrouillage FOR UPDATE et contrôle strict du stock disponible.';


--
-- Name: fn_audit_trigger(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_audit_trigger"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'pg_temp'
    AS $$
DECLARE
  v_rec_id uuid;
  v_old_json jsonb;
  v_new_json jsonb;
  v_changed_fields text[] := '{}';
  v_key text;
  v_old_val jsonb;
  v_new_val jsonb;
  v_user_id uuid;
BEGIN
  v_user_id := auth.uid();

  IF TG_OP = 'INSERT' THEN
    IF TG_TABLE_NAME = 'app_settings' THEN
      v_rec_id := '00000000-0000-0000-0000-000000000001'::uuid;
    ELSE
      v_rec_id := NEW.id;
    END IF;

    v_new_json := to_jsonb(NEW);

    INSERT INTO audit_log (
      table_name,
      record_id,
      action,
      old_data,
      new_data,
      changed_fields,
      changed_by,
      changed_at
    ) VALUES (
      TG_TABLE_NAME,
      v_rec_id,
      'INSERT',
      NULL,
      v_new_json,
      NULL,
      v_user_id,
      now()
    );

    RETURN NEW;

  ELSIF TG_OP = 'UPDATE' THEN
    IF TG_TABLE_NAME = 'app_settings' THEN
      v_rec_id := '00000000-0000-0000-0000-000000000001'::uuid;
    ELSE
      v_rec_id := NEW.id;
    END IF;

    v_old_json := to_jsonb(OLD);
    v_new_json := to_jsonb(NEW);

    -- Identification des champs modifiés en excluant les colonnes techniques
    FOR v_key IN SELECT jsonb_object_keys(v_new_json)
    LOOP
      IF v_key NOT IN ('updated_at', 'created_at', 'created_by') THEN
        v_old_val := v_old_json -> v_key;
        v_new_val := v_new_json -> v_key;
        IF v_old_val IS DISTINCT FROM v_new_val THEN
          v_changed_fields := array_append(v_changed_fields, v_key);
        END IF;
      END IF;
    END LOOP;

    -- Si seuls des champs techniques ont changé, on ne génère pas de bruit dans l'audit
    IF cardinality(v_changed_fields) > 0 THEN
      INSERT INTO audit_log (
        table_name,
        record_id,
        action,
        old_data,
        new_data,
        changed_fields,
        changed_by,
        changed_at
      ) VALUES (
        TG_TABLE_NAME,
        v_rec_id,
        'UPDATE',
        v_old_json,
        v_new_json,
        v_changed_fields,
        v_user_id,
        now()
      );
    END IF;

    RETURN NEW;
  END IF;

  RETURN NULL;
END;
$$;


--
-- Name: FUNCTION "fn_audit_trigger"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."fn_audit_trigger"() IS 'Trigger générique d''audit (§7.5). Snapshot complet old/new en JSONB, exclusion des colonnes techniques de changed_fields (B5).';


--
-- Name: fn_generate_item_code(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_generate_item_code"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_num bigint;
BEGIN
  IF NEW.code IS NULL OR trim(NEW.code) = '' THEN
    v_num := nextval('item_code_seq');
    IF v_num < 10000 THEN
      NEW.code := 'ART-' || lpad(v_num::text, 4, '0');
    ELSE
      NEW.code := 'ART-' || v_num::text;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION "fn_generate_item_code"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."fn_generate_item_code"() IS 'Génère automatiquement le code article ART-0001 (LPAD adaptatif sans troncature).';


--
-- Name: fn_generate_order_reference(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_generate_order_reference"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_num bigint;
BEGIN
  IF NEW.reference IS NULL OR trim(NEW.reference) = '' THEN
    v_num := nextval('order_reference_seq');
    IF v_num < 1000 THEN
      NEW.reference := 'CH-' || lpad(v_num::text, 3, '0');
    ELSE
      NEW.reference := 'CH-' || v_num::text;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION "fn_generate_order_reference"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."fn_generate_order_reference"() IS 'Génère automatiquement la référence CH-001 (LPAD adaptatif sans troncature).';


--
-- Name: fn_items_before_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_items_before_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  -- Immuabilité absolue du prix initial fixé à la création (§7.2)
  IF OLD.initial_price IS DISTINCT FROM NEW.initial_price THEN
    RAISE EXCEPTION 'Le prix initial d''un article est immuable.';
  END IF;

  -- Protection contre modification directe de list_price (B7)
  IF OLD.list_price IS DISTINCT FROM NEW.list_price THEN
    IF coalesce(current_setting('app.allow_price_change', true), 'off') <> 'on' THEN
      RAISE EXCEPTION 'Modification directe du prix interdite. Utilisez la fonction change_price().';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: fn_set_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_set_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


--
-- Name: FUNCTION "fn_set_updated_at"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."fn_set_updated_at"() IS 'Trigger générique : positionne updated_at = now() avant chaque UPDATE.';


--
-- Name: fn_variants_before_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."fn_variants_before_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_sold bigint;
  v_lost bigint;
  v_new_vendable bigint;
BEGIN
  -- Protection contre modification directe de price_override (B7)
  IF OLD.price_override IS DISTINCT FROM NEW.price_override THEN
    IF coalesce(current_setting('app.allow_price_change', true), 'off') <> 'on' THEN
      RAISE EXCEPTION 'Modification directe du prix de variante interdite. Utilisez la fonction change_price().';
    END IF;
  END IF;

  -- Décision B8 : Empêcher toute baisse de stock rendant le solde disponible négatif
  -- Formule validée : quantity_received - quantity_damaged >= Σ(ventes actives) + Σ(pertes actives)
  IF (OLD.quantity_received IS DISTINCT FROM NEW.quantity_received)
     OR (OLD.quantity_damaged IS DISTINCT FROM NEW.quantity_damaged) THEN

    SELECT coalesce(sum(quantity), 0)
    INTO v_sold
    FROM sales
    WHERE variant_id = NEW.id AND status = 'active';

    SELECT coalesce(sum(quantity), 0)
    INTO v_lost
    FROM losses
    WHERE variant_id = NEW.id AND status = 'active';

    v_new_vendable := NEW.quantity_received - NEW.quantity_damaged;

    IF v_new_vendable < (v_sold + v_lost) THEN
      RAISE EXCEPTION 'Stock insuffisant : la quantité vendable (%) ne peut pas être inférieure aux unités déjà vendues (%) et perdues (%).',
        v_new_vendable, v_sold, v_lost;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: is_authorized_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."is_authorized_user"() RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public', 'pg_temp'
    AS $$
  SELECT EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid());
$$;


--
-- Name: FUNCTION "is_authorized_user"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."is_authorized_user"() IS 'Vérifie si auth.uid() est présent dans la table profiles (liste blanche). Exécuté en SECURITY DEFINER pour contourner la RLS sur profiles.';


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."rls_auto_enable"() RETURNS "event_trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


--
-- Name: stats_by_day("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."stats_by_day"("p_from" "date", "p_to" "date") RETURNS TABLE("stat_date" "date", "collected_total" bigint, "realized_margin" bigint, "discounts_total" bigint, "lost_value" bigint, "sales_count" bigint, "sold_units" bigint, "lost_units" bigint)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_tz text;
BEGIN
  SELECT timezone INTO v_tz FROM app_settings LIMIT 1;
  v_tz := coalesce(v_tz, 'UTC');

  RETURN QUERY
  WITH day_series AS (
    SELECT generate_series(p_from, p_to, '1 day'::interval)::date AS d
  ),
  daily_sales AS (
    SELECT
      (sd.sold_at AT TIME ZONE v_tz)::date AS sale_date,
      coalesce(sum(sd.sold_total), 0)::bigint AS collected,
      coalesce(sum(sd.margin), 0)::bigint AS margin,
      coalesce(sum(sd.discount), 0)::bigint AS discounts,
      count(distinct sd.sale_id)::bigint AS s_count,
      coalesce(sum(sd.quantity), 0)::bigint AS s_units
    FROM v_sales_detail sd
    WHERE (sd.sold_at AT TIME ZONE v_tz)::date >= p_from
      AND (sd.sold_at AT TIME ZONE v_tz)::date <= p_to
    GROUP BY (sd.sold_at AT TIME ZONE v_tz)::date
  ),
  daily_losses AS (
    SELECT
      l.occurred_on AS loss_date,
      coalesce(sum(l.quantity), 0)::bigint AS l_units,
      coalesce(sum(l.quantity * vs.effective_unit_cost), 0)::bigint AS l_value
    FROM losses l
    JOIN v_variant_stock vs ON vs.variant_id = l.variant_id
    WHERE l.status = 'active'
      AND l.occurred_on >= p_from
      AND l.occurred_on <= p_to
    GROUP BY l.occurred_on
  )
  SELECT
    ds.d AS stat_date,
    coalesce(dsales.collected, 0)::bigint AS collected_total,
    (coalesce(dsales.margin, 0) - coalesce(dlosses.l_value, 0))::bigint AS realized_margin,
    coalesce(dsales.discounts, 0)::bigint AS discounts_total,
    coalesce(dlosses.l_value, 0)::bigint AS lost_value,
    coalesce(dsales.s_count, 0)::bigint AS sales_count,
    coalesce(dsales.s_units, 0)::bigint AS sold_units,
    coalesce(dlosses.l_units, 0)::bigint AS lost_units
  FROM day_series ds
  LEFT JOIN daily_sales dsales ON dsales.sale_date = ds.d
  LEFT JOIN daily_losses dlosses ON dlosses.loss_date = ds.d
  ORDER BY ds.d ASC;
END;
$$;


--
-- Name: FUNCTION "stats_by_day"("p_from" "date", "p_to" "date"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."stats_by_day"("p_from" "date", "p_to" "date") IS 'Statistiques quotidiennes dans le fuseau configuré (encaissé, marge, remises, pertes).';


--
-- Name: stats_by_month("date", "date"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."stats_by_month"("p_from" "date", "p_to" "date") RETURNS TABLE("stat_month" "text", "month_start" "date", "collected_total" bigint, "realized_margin" bigint, "discounts_total" bigint, "lost_value" bigint, "sales_count" bigint, "sold_units" bigint, "lost_units" bigint)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_tz text;
BEGIN
  SELECT timezone INTO v_tz FROM app_settings LIMIT 1;
  v_tz := coalesce(v_tz, 'UTC');

  RETURN QUERY
  WITH month_series AS (
    SELECT generate_series(
      date_trunc('month', p_from::timestamp),
      date_trunc('month', p_to::timestamp),
      '1 month'::interval
    )::date AS m_start
  ),
  monthly_sales AS (
    SELECT
      date_trunc('month', (sd.sold_at AT TIME ZONE v_tz))::date AS s_month,
      coalesce(sum(sd.sold_total), 0)::bigint AS collected,
      coalesce(sum(sd.margin), 0)::bigint AS margin,
      coalesce(sum(sd.discount), 0)::bigint AS discounts,
      count(distinct sd.sale_id)::bigint AS s_count,
      coalesce(sum(sd.quantity), 0)::bigint AS s_units
    FROM v_sales_detail sd
    WHERE (sd.sold_at AT TIME ZONE v_tz)::date >= p_from
      AND (sd.sold_at AT TIME ZONE v_tz)::date <= p_to
    GROUP BY date_trunc('month', (sd.sold_at AT TIME ZONE v_tz))::date
  ),
  monthly_losses AS (
    SELECT
      date_trunc('month', l.occurred_on::timestamp)::date AS l_month,
      coalesce(sum(l.quantity), 0)::bigint AS l_units,
      coalesce(sum(l.quantity * vs.effective_unit_cost), 0)::bigint AS l_value
    FROM losses l
    JOIN v_variant_stock vs ON vs.variant_id = l.variant_id
    WHERE l.status = 'active'
      AND l.occurred_on >= p_from
      AND l.occurred_on <= p_to
    GROUP BY date_trunc('month', l.occurred_on::timestamp)::date
  )
  SELECT
    to_char(ms.m_start, 'YYYY-MM') AS stat_month,
    ms.m_start AS month_start,
    coalesce(msales.collected, 0)::bigint AS collected_total,
    (coalesce(msales.margin, 0) - coalesce(mlosses.l_value, 0))::bigint AS realized_margin,
    coalesce(msales.discounts, 0)::bigint AS discounts_total,
    coalesce(mlosses.l_value, 0)::bigint AS lost_value,
    coalesce(msales.s_count, 0)::bigint AS sales_count,
    coalesce(msales.s_units, 0)::bigint AS sold_units,
    coalesce(mlosses.l_units, 0)::bigint AS lost_units
  FROM month_series ms
  LEFT JOIN monthly_sales msales ON msales.s_month = ms.m_start
  LEFT JOIN monthly_losses mlosses ON mlosses.l_month = ms.m_start
  ORDER BY ms.m_start ASC;
END;
$$;


--
-- Name: FUNCTION "stats_by_month"("p_from" "date", "p_to" "date"); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."stats_by_month"("p_from" "date", "p_to" "date") IS 'Statistiques mensuelles dans le fuseau configuré (encaissé, marge, remises, pertes).';


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."app_settings" (
    "id" boolean DEFAULT true NOT NULL,
    "watch_after_days" integer DEFAULT 30 NOT NULL,
    "clearance_after_days" integer DEFAULT 60 NOT NULL,
    "timezone" "text" DEFAULT 'UTC'::"text" NOT NULL,
    "updated_at" timestamp with time zone,
    "updated_by" "uuid",
    CONSTRAINT "app_settings_id_check" CHECK ("id"),
    CONSTRAINT "chk_clearance_gt_watch" CHECK (("clearance_after_days" > "watch_after_days"))
);

ALTER TABLE ONLY "public"."app_settings" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "app_settings"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."app_settings" IS 'Paramètres globaux. Contient exactement une ligne (PK = true). §7.2.';


--
-- Name: COLUMN "app_settings"."watch_after_days"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."app_settings"."watch_after_days" IS 'Jours avant passage au statut « À surveiller » (R18).';


--
-- Name: COLUMN "app_settings"."clearance_after_days"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."app_settings"."clearance_after_days" IS 'Jours avant passage au statut « À déstocker » (R18).';


--
-- Name: COLUMN "app_settings"."timezone"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."app_settings"."timezone" IS 'Fuseau IANA pour les regroupements jour/mois des statistiques. §7.1 / R17.';


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."audit_log" (
    "id" bigint NOT NULL,
    "table_name" "text" NOT NULL,
    "record_id" "uuid" NOT NULL,
    "action" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "changed_fields" "text"[],
    "changed_by" "uuid",
    "changed_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "audit_log_action_check" CHECK (("action" = ANY (ARRAY['INSERT'::"text", 'UPDATE'::"text"])))
);

ALTER TABLE ONLY "public"."audit_log" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "audit_log"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."audit_log" IS 'Journal d''audit inviolable. INSERT seul. §7.5.';


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE "public"."audit_log" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "public"."audit_log_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."categories" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."categories" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "categories"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."categories" IS 'Catégories d''articles. Nom unique insensible à la casse (B4).';


--
-- Name: COLUMN "categories"."name"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."categories"."name" IS 'Nom affiché. Unicité garantie via index fonctionnel sur lower(name).';


--
-- Name: item_code_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."item_code_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "code" "text" NOT NULL,
    "order_id" "uuid" NOT NULL,
    "category_id" "uuid",
    "name" "text" NOT NULL,
    "description" "text",
    "photo_url" "text",
    "photo_public_id" "text",
    "list_price" bigint NOT NULL,
    "initial_price" bigint NOT NULL,
    "unit_cost" bigint,
    "received_date" "date" NOT NULL,
    "archived_at" timestamp with time zone,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "items_initial_price_check" CHECK (("initial_price" >= 0)),
    CONSTRAINT "items_list_price_check" CHECK (("list_price" >= 0)),
    CONSTRAINT "items_unit_cost_check" CHECK (("unit_cost" >= 0))
);

ALTER TABLE ONLY "public"."items" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "items"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."items" IS 'Articles vendus, rattachés à une commande Chine. §7.2 / §9.3.';


--
-- Name: COLUMN "items"."list_price"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."items"."list_price" IS 'Prix fixé actuel. R8.';


--
-- Name: COLUMN "items"."initial_price"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."items"."initial_price" IS 'Prix à la création, immuable.';


--
-- Name: COLUMN "items"."unit_cost"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."items"."unit_cost" IS 'Coût unitaire facultatif. Si NULL -> estimé par répartition (R11).';


--
-- Name: COLUMN "items"."received_date"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."items"."received_date" IS 'Date de réception copiée de la commande. Base pour R17.';


--
-- Name: losses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."losses" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "variant_id" "uuid" NOT NULL,
    "quantity" integer NOT NULL,
    "reason" "text" NOT NULL,
    "occurred_on" "date" DEFAULT CURRENT_DATE NOT NULL,
    "note" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "cancelled_at" timestamp with time zone,
    "cancelled_by" "uuid",
    "cancel_reason" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chk_loss_cancel_fields" CHECK ((("status" <> 'cancelled'::"text") OR (("cancelled_at" IS NOT NULL) AND ("cancelled_by" IS NOT NULL) AND ("cancel_reason" IS NOT NULL) AND (TRIM(BOTH FROM "cancel_reason") <> ''::"text")))),
    CONSTRAINT "losses_quantity_check" CHECK (("quantity" > 0)),
    CONSTRAINT "losses_reason_check" CHECK (("reason" = ANY (ARRAY['damaged'::"text", 'unsellable'::"text", 'gift'::"text", 'lost'::"text", 'other'::"text"]))),
    CONSTRAINT "losses_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'cancelled'::"text"])))
);

ALTER TABLE ONLY "public"."losses" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "losses"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."losses" IS 'Sorties en perte post-réception. §7.2 / §9.5.';


--
-- Name: order_reference_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."order_reference_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."orders" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "reference" "text" NOT NULL,
    "order_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "supplier" "text" NOT NULL,
    "description" "text",
    "status" "text" DEFAULT 'ordered'::"text" NOT NULL,
    "purchase_amount" bigint NOT NULL,
    "forwarder_fee" bigint DEFAULT 0 NOT NULL,
    "weight_kg" numeric(10,2),
    "received_date" "date",
    "total_cost" bigint GENERATED ALWAYS AS (("purchase_amount" + "forwarder_fee")) STORED,
    "notes" "text",
    "archived_at" timestamp with time zone,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "origin" "text" DEFAULT 'china'::"text",
    CONSTRAINT "chk_received_needs_date" CHECK ((("status" <> 'received'::"text") OR ("received_date" IS NOT NULL))),
    CONSTRAINT "orders_forwarder_fee_check" CHECK (("forwarder_fee" >= 0)),
    CONSTRAINT "orders_purchase_amount_check" CHECK (("purchase_amount" >= 0)),
    CONSTRAINT "orders_status_check" CHECK (("status" = ANY (ARRAY['ordered'::"text", 'shipping'::"text", 'received'::"text"])))
);

ALTER TABLE ONLY "public"."orders" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "orders"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."orders" IS 'Commandes passées en Chine. Unité financière de base. §7.2 / §9.2.';


--
-- Name: COLUMN "orders"."reference"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."orders"."reference" IS 'Référence unique auto-générée (CH-001…).';


--
-- Name: COLUMN "orders"."received_date"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."orders"."received_date" IS 'Obligatoire si status = received. Point de départ de l''ancienneté des articles. R17.';


--
-- Name: COLUMN "orders"."total_cost"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."orders"."total_cost" IS 'GENERATED STORED : purchase_amount + forwarder_fee. R3.';


--
-- Name: price_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."price_changes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "item_id" "uuid" NOT NULL,
    "variant_id" "uuid",
    "old_price" bigint,
    "new_price" bigint NOT NULL,
    "change_type" "text" NOT NULL,
    "changed_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "changed_by" "uuid" DEFAULT "auth"."uid"(),
    "note" "text",
    CONSTRAINT "price_changes_change_type_check" CHECK (("change_type" = ANY (ARRAY['initial'::"text", 'markdown'::"text", 'increase'::"text"]))),
    CONSTRAINT "price_changes_new_price_check" CHECK (("new_price" >= 0))
);

ALTER TABLE ONLY "public"."price_changes" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "price_changes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."price_changes" IS 'Historique des changements de prix. §7.2.';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."profiles" (
    "id" "uuid" NOT NULL,
    "full_name" "text" NOT NULL,
    "role" "text" DEFAULT 'admin'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."profiles" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "profiles"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."profiles" IS 'Liste blanche des utilisateurs autorisés. §5.';


--
-- Name: COLUMN "profiles"."role"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."profiles"."role" IS 'Rôle utilisateur. Valeur unique V1 : admin. Prépare la V3.';


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."sales" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "variant_id" "uuid" NOT NULL,
    "quantity" integer NOT NULL,
    "list_price_unit" bigint NOT NULL,
    "sold_total" bigint NOT NULL,
    "channel" "text",
    "sold_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "note" "text",
    "status" "text" DEFAULT 'active'::"text" NOT NULL,
    "cancelled_at" timestamp with time zone,
    "cancelled_by" "uuid",
    "cancel_reason" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chk_sale_cancel_fields" CHECK ((("status" <> 'cancelled'::"text") OR (("cancelled_at" IS NOT NULL) AND ("cancelled_by" IS NOT NULL) AND ("cancel_reason" IS NOT NULL) AND (TRIM(BOTH FROM "cancel_reason") <> ''::"text")))),
    CONSTRAINT "sales_channel_check" CHECK (("channel" = ANY (ARRAY['facebook'::"text", 'whatsapp'::"text", 'direct'::"text", 'other'::"text"]))),
    CONSTRAINT "sales_list_price_unit_check" CHECK (("list_price_unit" >= 0)),
    CONSTRAINT "sales_quantity_check" CHECK (("quantity" > 0)),
    CONSTRAINT "sales_sold_total_check" CHECK (("sold_total" > 0)),
    CONSTRAINT "sales_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'cancelled'::"text"])))
);

ALTER TABLE ONLY "public"."sales" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "sales"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."sales" IS 'Ventes enregistrées. Jamais de DELETE ; annulation uniquement. §7.2 / §9.4.';


--
-- Name: COLUMN "sales"."list_price_unit"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."sales"."list_price_unit" IS 'Instantané du prix fixé unitaire au moment de la vente.';


--
-- Name: COLUMN "sales"."sold_total"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."sales"."sold_total" IS 'Montant total encaissé en FCFA.';


--
-- Name: variants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."variants" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "item_id" "uuid" NOT NULL,
    "label" "text" DEFAULT 'Unique'::"text" NOT NULL,
    "photo_url" "text",
    "photo_public_id" "text",
    "price_override" bigint,
    "quantity_ordered" integer,
    "quantity_received" integer NOT NULL,
    "quantity_damaged" integer DEFAULT 0 NOT NULL,
    "archived_at" timestamp with time zone,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chk_damaged_lte_received" CHECK (("quantity_damaged" <= "quantity_received")),
    CONSTRAINT "variants_price_override_check" CHECK (("price_override" >= 0)),
    CONSTRAINT "variants_quantity_damaged_check" CHECK (("quantity_damaged" >= 0)),
    CONSTRAINT "variants_quantity_ordered_check" CHECK ((("quantity_ordered" IS NULL) OR ("quantity_ordered" >= 0))),
    CONSTRAINT "variants_quantity_received_check" CHECK (("quantity_received" >= 0))
);

ALTER TABLE ONLY "public"."variants" FORCE ROW LEVEL SECURITY;


--
-- Name: TABLE "variants"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."variants" IS 'Déclinaisons d''articles. Stock calculé par variante. §6 / §7.2.';


--
-- Name: COLUMN "variants"."label"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."variants"."label" IS 'Libellé libre. Unicité par article insensible à la casse (B3).';


--
-- Name: COLUMN "variants"."price_override"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."variants"."price_override" IS 'Prix spécifique à la variante. Si NULL -> hérite de items.list_price.';


--
-- Name: COLUMN "variants"."quantity_damaged"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."variants"."quantity_damaged" IS 'Quantité abîmée constatée à la réception.';


--
-- Name: v_variant_stock; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_variant_stock" WITH ("security_invoker"='true') AS
 WITH "settings" AS (
         SELECT "app_settings"."watch_after_days",
            "app_settings"."clearance_after_days",
            "app_settings"."timezone"
           FROM "public"."app_settings"
         LIMIT 1
        ), "order_cost_calc" AS (
         SELECT "i_1"."order_id",
            "o_1"."total_cost",
            COALESCE("sum"(
                CASE
                    WHEN ("i_1"."unit_cost" IS NOT NULL) THEN ("i_1"."unit_cost" * ("v_1"."quantity_received" - "v_1"."quantity_damaged"))
                    ELSE (0)::bigint
                END), (0)::numeric) AS "known_cost",
            COALESCE("sum"(
                CASE
                    WHEN ("i_1"."unit_cost" IS NULL) THEN ("v_1"."quantity_received" - "v_1"."quantity_damaged")
                    ELSE 0
                END), (0)::bigint) AS "uncosted_vendable"
           FROM (("public"."items" "i_1"
             JOIN "public"."variants" "v_1" ON (("v_1"."item_id" = "i_1"."id")))
             JOIN "public"."orders" "o_1" ON (("o_1"."id" = "i_1"."order_id")))
          WHERE (("i_1"."archived_at" IS NULL) AND ("v_1"."archived_at" IS NULL) AND ("o_1"."archived_at" IS NULL))
          GROUP BY "i_1"."order_id", "o_1"."total_cost"
        ), "sales_agg" AS (
         SELECT "sales"."variant_id",
            COALESCE("sum"("sales"."quantity"), (0)::bigint) AS "sold_units"
           FROM "public"."sales"
          WHERE ("sales"."status" = 'active'::"text")
          GROUP BY "sales"."variant_id"
        ), "losses_agg" AS (
         SELECT "losses"."variant_id",
            COALESCE("sum"("losses"."quantity"), (0)::bigint) AS "lost_units"
           FROM "public"."losses"
          WHERE ("losses"."status" = 'active'::"text")
          GROUP BY "losses"."variant_id"
        )
 SELECT "v"."id" AS "variant_id",
    "i"."id" AS "item_id",
    "o"."id" AS "order_id",
    "o"."reference" AS "order_reference",
    "i"."code" AS "item_code",
    "i"."name" AS "item_name",
    "v"."label" AS "variant_label",
    "v"."photo_url",
    "v"."photo_public_id",
    "v"."quantity_ordered",
    "v"."quantity_received",
    "v"."quantity_damaged",
    ("v"."quantity_received" - "v"."quantity_damaged") AS "vendable",
    COALESCE("sa"."sold_units", (0)::bigint) AS "sold_units",
    COALESCE("la"."lost_units", (0)::bigint) AS "lost_units",
    ((("v"."quantity_received" - "v"."quantity_damaged") - COALESCE("sa"."sold_units", (0)::bigint)) - COALESCE("la"."lost_units", (0)::bigint)) AS "stock",
    COALESCE("v"."price_override", "i"."list_price") AS "effective_price",
        CASE
            WHEN ("i"."unit_cost" IS NOT NULL) THEN "i"."unit_cost"
            WHEN ("occ"."uncosted_vendable" > 0) THEN ("round"((GREATEST((0)::numeric, (("occ"."total_cost")::numeric - "occ"."known_cost")) / ("occ"."uncosted_vendable")::numeric)))::bigint
            ELSE (0)::bigint
        END AS "effective_unit_cost",
    ("i"."unit_cost" IS NULL) AS "cost_is_estimated",
    "i"."received_date",
    ((("now"() AT TIME ZONE "st"."timezone"))::"date" - "i"."received_date") AS "days_in_stock",
        CASE
            WHEN (((("v"."quantity_received" - "v"."quantity_damaged") - COALESCE("sa"."sold_units", (0)::bigint)) - COALESCE("la"."lost_units", (0)::bigint)) <= 0) THEN 'out_of_stock'::"text"
            WHEN (((("now"() AT TIME ZONE "st"."timezone"))::"date" - "i"."received_date") >= "st"."clearance_after_days") THEN 'clearance'::"text"
            WHEN (((("now"() AT TIME ZONE "st"."timezone"))::"date" - "i"."received_date") >= "st"."watch_after_days") THEN 'watch'::"text"
            ELSE 'normal'::"text"
        END AS "dormant_status"
   FROM (((((("public"."variants" "v"
     JOIN "public"."items" "i" ON (("i"."id" = "v"."item_id")))
     JOIN "public"."orders" "o" ON (("o"."id" = "i"."order_id")))
     CROSS JOIN "settings" "st")
     LEFT JOIN "order_cost_calc" "occ" ON (("occ"."order_id" = "o"."id")))
     LEFT JOIN "sales_agg" "sa" ON (("sa"."variant_id" = "v"."id")))
     LEFT JOIN "losses_agg" "la" ON (("la"."variant_id" = "v"."id")))
  WHERE (("v"."archived_at" IS NULL) AND ("i"."archived_at" IS NULL) AND ("o"."archived_at" IS NULL));


--
-- Name: VIEW "v_variant_stock"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_variant_stock" IS 'Stock par variante, coût effectif (R11), ancienneté (R17) et statut d''invendu (R18). Security invoker.';


--
-- Name: v_dormant_stock; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_dormant_stock" WITH ("security_invoker"='true') AS
 SELECT "variant_id",
    "item_id",
    "order_id",
    "order_reference",
    "item_code",
    "item_name",
    "variant_label",
    "photo_url",
    "photo_public_id",
    "received_date",
    "days_in_stock",
    "dormant_status",
    "stock",
    "effective_price",
    "effective_unit_cost",
    "cost_is_estimated",
    ("stock" * "effective_unit_cost") AS "stock_value_at_cost",
    ("stock" * "effective_price") AS "stock_value_at_price"
   FROM "public"."v_variant_stock" "vs"
  WHERE ("stock" > 0)
  ORDER BY "days_in_stock" DESC, "received_date";


--
-- Name: VIEW "v_dormant_stock"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_dormant_stock" IS 'Stock dormant (> 0) trié par ancienneté avec statuts et valeurs immobilisées (R19). Security invoker.';


--
-- Name: v_item_catalog; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_item_catalog" WITH ("security_invoker"='true') AS
 WITH "variant_totals" AS (
         SELECT "vs"."item_id",
            "count"(*) AS "variants_count",
            COALESCE("sum"("vs"."vendable"), (0)::bigint) AS "vendable_units",
            (COALESCE("sum"("vs"."sold_units"), (0)::numeric))::bigint AS "sold_units",
            (COALESCE("sum"("vs"."stock"), (0)::numeric))::bigint AS "stock_units",
                CASE "max"(
                    CASE "vs"."dormant_status"
                        WHEN 'clearance'::"text" THEN 3
                        WHEN 'watch'::"text" THEN 2
                        WHEN 'normal'::"text" THEN 1
                        ELSE 0
                    END)
                    WHEN 3 THEN 'clearance'::"text"
                    WHEN 2 THEN 'watch'::"text"
                    WHEN 1 THEN 'normal'::"text"
                    ELSE 'out_of_stock'::"text"
                END AS "dormant_status"
           FROM "public"."v_variant_stock" "vs"
          GROUP BY "vs"."item_id"
        )
 SELECT "i"."id" AS "item_id",
    "i"."code" AS "item_code",
    "i"."order_id",
    "o"."reference" AS "order_reference",
    "o"."supplier",
    "i"."category_id",
    "c"."name" AS "category_name",
    "i"."name" AS "item_name",
    "i"."description",
    "i"."photo_url",
    "i"."photo_public_id",
    "i"."list_price",
    "i"."initial_price",
    "i"."unit_cost",
        CASE
            WHEN ("i"."unit_cost" IS NOT NULL) THEN ("i"."list_price" - "i"."unit_cost")
            ELSE NULL::bigint
        END AS "unit_margin",
    "i"."received_date",
    "i"."archived_at",
    "i"."created_at",
    "i"."updated_at",
    COALESCE("vt"."variants_count", (0)::bigint) AS "variants_count",
    COALESCE("vt"."vendable_units", (0)::bigint) AS "vendable_units",
    COALESCE("vt"."sold_units", (0)::bigint) AS "sold_units",
    COALESCE("vt"."stock_units", (0)::bigint) AS "stock_units",
    COALESCE("vt"."dormant_status", 'out_of_stock'::"text") AS "dormant_status"
   FROM ((("public"."items" "i"
     JOIN "public"."orders" "o" ON (("o"."id" = "i"."order_id")))
     LEFT JOIN "public"."categories" "c" ON (("c"."id" = "i"."category_id")))
     LEFT JOIN "variant_totals" "vt" ON (("vt"."item_id" = "i"."id")))
  WHERE ("o"."archived_at" IS NULL);


--
-- Name: v_sales_detail; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_sales_detail" WITH ("security_invoker"='true') AS
 SELECT "s"."id" AS "sale_id",
    "s"."variant_id",
    "vs"."item_id",
    "vs"."order_id",
    "vs"."order_reference",
    "vs"."item_code",
    "vs"."item_name",
    "vs"."variant_label",
    "s"."quantity",
    "s"."list_price_unit",
    "s"."sold_total",
    (("s"."list_price_unit" * "s"."quantity") - "s"."sold_total") AS "discount",
    "vs"."effective_unit_cost",
    ("s"."sold_total" - ("vs"."effective_unit_cost" * "s"."quantity")) AS "margin",
    "vs"."cost_is_estimated",
    "s"."channel",
    "s"."sold_at",
    "s"."note",
    "s"."created_by",
    "s"."created_at"
   FROM ("public"."sales" "s"
     JOIN "public"."v_variant_stock" "vs" ON (("vs"."variant_id" = "s"."variant_id")))
  WHERE ("s"."status" = 'active'::"text");


--
-- Name: VIEW "v_sales_detail"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_sales_detail" IS 'Détail des ventes actives avec remise (R10), coût effectif (R11) et marge (R12). Security invoker.';


--
-- Name: v_item_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_item_summary" WITH ("security_invoker"='true') AS
 WITH "item_vars" AS (
         SELECT "vs"."item_id",
            COALESCE("sum"("vs"."vendable"), (0)::bigint) AS "vendable_units",
            (COALESCE("sum"("vs"."stock"), (0)::numeric))::bigint AS "stock_units"
           FROM "public"."v_variant_stock" "vs"
          GROUP BY "vs"."item_id"
        ), "item_sales" AS (
         SELECT "sd"."item_id",
            "count"(DISTINCT "sd"."sale_id") AS "sales_count",
            COALESCE("sum"("sd"."quantity"), (0)::bigint) AS "sold_units",
            (COALESCE("sum"("sd"."sold_total"), (0)::numeric))::bigint AS "sales_revenue",
                CASE
                    WHEN ("sum"("sd"."quantity") > 0) THEN "round"((("sum"(("sd"."quantity" * (("sd"."sold_at")::"date" - "i_1"."received_date"))))::numeric / ("sum"("sd"."quantity"))::numeric), 1)
                    ELSE NULL::numeric
                END AS "avg_days_to_sell"
           FROM ("public"."v_sales_detail" "sd"
             JOIN "public"."items" "i_1" ON (("i_1"."id" = "sd"."item_id")))
          GROUP BY "sd"."item_id", "i_1"."received_date"
        )
 SELECT "i"."id" AS "item_id",
    "i"."order_id",
    "o"."reference" AS "order_reference",
    "i"."category_id",
    "c"."name" AS "category_name",
    "i"."code" AS "item_code",
    "i"."name" AS "item_name",
    "i"."photo_url",
    "i"."list_price",
    "i"."initial_price",
    "i"."unit_cost",
    "i"."received_date",
    COALESCE("iv"."vendable_units", (0)::bigint) AS "vendable_units",
    COALESCE("isales"."sold_units", (0)::bigint) AS "sold_units",
    COALESCE("iv"."stock_units", (0)::bigint) AS "stock_units",
    COALESCE("isales"."sales_count", (0)::bigint) AS "sales_count",
    COALESCE("isales"."sales_revenue", (0)::bigint) AS "sales_revenue",
        CASE
            WHEN ("i"."unit_cost" IS NOT NULL) THEN (COALESCE("isales"."sales_revenue", (0)::bigint) - ("i"."unit_cost" * COALESCE("isales"."sold_units", (0)::bigint)))
            ELSE NULL::bigint
        END AS "known_margin",
    ("i"."unit_cost" IS NOT NULL) AS "has_known_cost",
        CASE
            WHEN (COALESCE("iv"."vendable_units", (0)::bigint) > 0) THEN "round"((((COALESCE("isales"."sold_units", (0)::bigint))::numeric / ("iv"."vendable_units")::numeric) * (100)::numeric), 2)
            ELSE 0.0
        END AS "sell_through_rate",
    "isales"."avg_days_to_sell"
   FROM (((("public"."items" "i"
     JOIN "public"."orders" "o" ON (("o"."id" = "i"."order_id")))
     LEFT JOIN "public"."categories" "c" ON (("c"."id" = "i"."category_id")))
     LEFT JOIN "item_vars" "iv" ON (("iv"."item_id" = "i"."id")))
     LEFT JOIN "item_sales" "isales" ON (("isales"."item_id" = "i"."id")))
  WHERE (("i"."archived_at" IS NULL) AND ("o"."archived_at" IS NULL));


--
-- Name: VIEW "v_item_summary"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_item_summary" IS 'Synthèse par article : ventes, CA, marge connue (R20), vitesse d''écoulement (R15, R16). Security invoker.';


--
-- Name: v_order_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."v_order_summary" WITH ("security_invoker"='true') AS
 WITH "var_stats" AS (
         SELECT "vs_1"."order_id",
            COALESCE("sum"("vs_1"."vendable"), (0)::bigint) AS "total_vendable",
            (COALESCE("sum"("vs_1"."sold_units"), (0)::numeric))::bigint AS "total_sold_units",
            (COALESCE("sum"("vs_1"."lost_units"), (0)::numeric))::bigint AS "total_lost_units",
            (COALESCE("sum"("vs_1"."stock"), (0)::numeric))::bigint AS "total_stock",
            (COALESCE("sum"(("vs_1"."stock" * "vs_1"."effective_price")), (0)::numeric))::bigint AS "stock_value_at_price",
            (COALESCE("sum"(("vs_1"."stock" * "vs_1"."effective_unit_cost")), (0)::numeric))::bigint AS "stock_value_at_cost"
           FROM "public"."v_variant_stock" "vs_1"
          GROUP BY "vs_1"."order_id"
        ), "sales_stats" AS (
         SELECT "sd"."order_id",
            (COALESCE("sum"("sd"."sold_total"), (0)::numeric))::bigint AS "total_collected",
            (COALESCE("sum"("sd"."discount"), (0)::numeric))::bigint AS "total_discounts",
            (COALESCE("sum"("sd"."margin"), (0)::numeric))::bigint AS "total_sales_margin",
            "count"(DISTINCT "sd"."sale_id") AS "total_sales_count"
           FROM "public"."v_sales_detail" "sd"
          GROUP BY "sd"."order_id"
        ), "losses_stats" AS (
         SELECT "vs_1"."order_id",
            (COALESCE("sum"(("l"."quantity" * "vs_1"."effective_unit_cost")), (0)::numeric))::bigint AS "total_lost_value"
           FROM ("public"."losses" "l"
             JOIN "public"."v_variant_stock" "vs_1" ON (("vs_1"."variant_id" = "l"."variant_id")))
          WHERE ("l"."status" = 'active'::"text")
          GROUP BY "vs_1"."order_id"
        )
 SELECT "o"."id" AS "order_id",
    "o"."reference",
    "o"."order_date",
    "o"."supplier",
    "o"."status",
    "o"."received_date",
    "o"."weight_kg",
    "o"."total_cost",
    COALESCE("ss"."total_collected", (0)::bigint) AS "collected_total",
    (COALESCE("ss"."total_collected", (0)::bigint) - "o"."total_cost") AS "balance",
    GREATEST((0)::bigint, ("o"."total_cost" - COALESCE("ss"."total_collected", (0)::bigint))) AS "remaining_to_recover",
        CASE
            WHEN ("o"."total_cost" > 0) THEN LEAST(100.0, "round"((((COALESCE("ss"."total_collected", (0)::bigint))::numeric / ("o"."total_cost")::numeric) * (100)::numeric), 2))
            ELSE 100.0
        END AS "recovery_rate",
    ((COALESCE("ss"."total_collected", (0)::bigint) + COALESCE("vs"."stock_value_at_price", (0)::bigint)) - "o"."total_cost") AS "expected_profit",
    (COALESCE("ss"."total_sales_margin", (0)::bigint) - COALESCE("ls"."total_lost_value", (0)::bigint)) AS "realized_margin",
        CASE
            WHEN (COALESCE("vs"."total_vendable", (0)::bigint) > 0) THEN "round"((((COALESCE("vs"."total_sold_units", (0)::bigint))::numeric / ("vs"."total_vendable")::numeric) * (100)::numeric), 2)
            ELSE 0.0
        END AS "sell_through_rate",
    COALESCE("vs"."total_vendable", (0)::bigint) AS "vendable_units",
    COALESCE("vs"."total_sold_units", (0)::bigint) AS "sold_units",
    COALESCE("vs"."total_stock", (0)::bigint) AS "stock_units",
    COALESCE("vs"."total_lost_units", (0)::bigint) AS "lost_units",
    COALESCE("ls"."total_lost_value", (0)::bigint) AS "lost_value",
    COALESCE("vs"."stock_value_at_price", (0)::bigint) AS "stock_value_at_price",
    COALESCE("vs"."stock_value_at_cost", (0)::bigint) AS "stock_value_at_cost",
    COALESCE("ss"."total_discounts", (0)::bigint) AS "total_discounts",
    COALESCE("ss"."total_sales_count", (0)::bigint) AS "sales_count",
    (COALESCE("ss"."total_collected", (0)::bigint) >= "o"."total_cost") AS "is_recovered"
   FROM ((("public"."orders" "o"
     LEFT JOIN "var_stats" "vs" ON (("vs"."order_id" = "o"."id")))
     LEFT JOIN "sales_stats" "ss" ON (("ss"."order_id" = "o"."id")))
     LEFT JOIN "losses_stats" "ls" ON (("ls"."order_id" = "o"."id")))
  WHERE ("o"."archived_at" IS NULL);


--
-- Name: VIEW "v_order_summary"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW "public"."v_order_summary" IS 'Synthèse financière et d''écoulement par commande (R3 à R9, R13 à R15). Security invoker.';


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."app_settings" ("id", "watch_after_days", "clearance_after_days", "timezone", "updated_at", "updated_by") FROM stdin;
t	30	60	UTC	\N	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."audit_log" ("id", "table_name", "record_id", "action", "old_data", "new_data", "changed_fields", "changed_by", "changed_at") FROM stdin;
41	orders	f4908e1d-76c5-458f-a1cd-a0642a2c5db6	INSERT	\N	{"id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "notes": "[Origine: Chine]", "origin": "Chine", "status": "received", "supplier": "Usine", "reference": "CH-001", "weight_kg": null, "created_at": "2026-11-12T15:25:19.705752+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "order_date": "2026-11-12", "total_cost": 482000, "updated_at": "2026-11-12T15:25:19.705752+00:00", "archived_at": null, "description": null, "forwarder_fee": 82000, "received_date": "2026-11-12", "purchase_amount": 400000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:25:19.705752+00
42	items	9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	INSERT	\N	{"id": "9cdd5bbe-d6e8-46ac-a473-8a9210e859ea", "code": "ART-0001", "name": "Mstianq", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1794497214/zadri-luxe/vrqwy7jpmk0crusjrczw.jpg", "unit_cost": 18000, "created_at": "2026-11-12T15:38:45.146303+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 30000, "updated_at": "2026-11-12T15:38:45.146303+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 30000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/vrqwy7jpmk0crusjrczw"}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00
43	variants	82a79b04-ec43-4dde-aae3-d72dd0843218	INSERT	\N	{"id": "82a79b04-ec43-4dde-aae3-d72dd0843218", "label": "Noir", "item_id": "9cdd5bbe-d6e8-46ac-a473-8a9210e859ea", "photo_url": null, "created_at": "2026-11-12T15:38:45.146303+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-12T15:38:45.146303+00:00", "archived_at": null, "price_override": null, "photo_public_id": null, "quantity_damaged": 1, "quantity_ordered": 12, "quantity_received": 12}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00
44	variants	a68ed09b-197a-4678-a4f1-05933c9f88d4	INSERT	\N	{"id": "a68ed09b-197a-4678-a4f1-05933c9f88d4", "label": "Or", "item_id": "9cdd5bbe-d6e8-46ac-a473-8a9210e859ea", "photo_url": null, "created_at": "2026-11-12T15:38:45.146303+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-12T15:38:45.146303+00:00", "archived_at": null, "price_override": null, "photo_public_id": null, "quantity_damaged": 0, "quantity_ordered": 8, "quantity_received": 8}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00
45	items	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	INSERT	\N	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": null, "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-12T15:40:43.859994+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": null}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:40:43.859994+00
46	variants	c21395b4-9858-45e9-8e28-12e14ffd86d0	INSERT	\N	{"id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "label": "Unique", "item_id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "photo_url": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-12T15:40:43.859994+00:00", "archived_at": null, "price_override": null, "photo_public_id": null, "quantity_damaged": 2, "quantity_ordered": null, "quantity_received": 30}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:40:43.859994+00
47	sales	1d13f325-47d8-44a3-9933-cd23ccf91b10	INSERT	\N	{"id": "1d13f325-47d8-44a3-9933-cd23ccf91b10", "note": null, "status": "active", "channel": "direct", "sold_at": "2026-11-12T15:52:42.816+00:00", "quantity": 2, "created_at": "2026-11-12T15:52:44.050634+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 58000, "updated_at": "2026-11-12T15:52:44.050634+00:00", "variant_id": "82a79b04-ec43-4dde-aae3-d72dd0843218", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 30000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:52:44.050634+00
48	sales	d5b9a4d9-11e5-445d-92c6-08406245e0a6	INSERT	\N	{"id": "d5b9a4d9-11e5-445d-92c6-08406245e0a6", "note": null, "status": "active", "channel": "facebook", "sold_at": "2026-11-12T15:54:16.948+00:00", "quantity": 1, "created_at": "2026-11-12T15:54:17.43698+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 30000, "updated_at": "2026-11-12T15:54:17.43698+00:00", "variant_id": "a68ed09b-197a-4678-a4f1-05933c9f88d4", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 30000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:54:17.43698+00
49	sales	c9fe4b44-1eae-4672-8878-1c7dc8663779	INSERT	\N	{"id": "c9fe4b44-1eae-4672-8878-1c7dc8663779", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-12T15:54:45.193+00:00", "quantity": 5, "created_at": "2026-11-12T15:54:45.684463+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 50000, "updated_at": "2026-11-12T15:54:45.684463+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:54:45.684463+00
50	sales	c0fd9046-99bb-42d1-afde-3a610c82eb62	INSERT	\N	{"id": "c0fd9046-99bb-42d1-afde-3a610c82eb62", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-12T15:55:31.945+00:00", "quantity": 1, "created_at": "2026-11-12T15:55:32.429885+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 9000, "updated_at": "2026-11-12T15:55:32.429885+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:55:32.429885+00
51	sales	c0fd9046-99bb-42d1-afde-3a610c82eb62	UPDATE	{"id": "c0fd9046-99bb-42d1-afde-3a610c82eb62", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-12T15:55:31.945+00:00", "quantity": 1, "created_at": "2026-11-12T15:55:32.429885+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 9000, "updated_at": "2026-11-12T15:55:32.429885+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	{"id": "c0fd9046-99bb-42d1-afde-3a610c82eb62", "note": null, "status": "cancelled", "channel": "whatsapp", "sold_at": "2026-11-12T15:55:31.945+00:00", "quantity": 1, "created_at": "2026-11-12T15:55:32.429885+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 9000, "updated_at": "2026-11-12T15:55:59.793771+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": "2026-11-12T15:55:59.793771+00:00", "cancelled_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "cancel_reason": "retrour client", "list_price_unit": 10000}	{status,cancelled_at,cancelled_by,cancel_reason}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:55:59.793771+00
52	losses	69395a84-174c-44f7-8114-67ef05cbc7b4	INSERT	\N	{"id": "69395a84-174c-44f7-8114-67ef05cbc7b4", "note": null, "reason": "damaged", "status": "active", "quantity": 1, "created_at": "2026-11-12T16:02:14.065495+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-12T16:02:14.065495+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "occurred_on": "2026-11-12", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 16:02:14.065495+00
53	orders	84cc8db8-541f-4cc2-9ff6-579f2636e9fc	INSERT	\N	{"id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "notes": "[Origine: Local]", "origin": "Local", "status": "ordered", "supplier": "5 motres", "reference": "LOC-001", "weight_kg": null, "created_at": "2026-11-12T17:20:51.39427+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "order_date": "2026-10-13", "total_cost": 180000, "updated_at": "2026-11-12T17:20:51.39427+00:00", "archived_at": null, "description": "5 motres", "forwarder_fee": 30000, "received_date": null, "purchase_amount": 150000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 17:20:51.39427+00
54	orders	84cc8db8-541f-4cc2-9ff6-579f2636e9fc	UPDATE	{"id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "notes": "[Origine: Local]", "origin": "Local", "status": "ordered", "supplier": "5 motres", "reference": "LOC-001", "weight_kg": null, "created_at": "2026-11-12T17:20:51.39427+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "order_date": "2026-10-13", "total_cost": 180000, "updated_at": "2026-11-12T17:20:51.39427+00:00", "archived_at": null, "description": "5 motres", "forwarder_fee": 30000, "received_date": null, "purchase_amount": 150000}	{"id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "notes": "[Origine: Local]", "origin": "Local", "status": "received", "supplier": "5 motres", "reference": "LOC-001", "weight_kg": null, "created_at": "2026-11-12T17:20:51.39427+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "order_date": "2026-10-13", "total_cost": 180000, "updated_at": "2026-11-12T17:21:27.49025+00:00", "archived_at": null, "description": "5 motres", "forwarder_fee": 30000, "received_date": "2026-11-12", "purchase_amount": 150000}	{status,received_date}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 17:21:27.49025+00
55	sales	8718559b-ccc5-41b5-ab0d-79533830364e	INSERT	\N	{"id": "8718559b-ccc5-41b5-ab0d-79533830364e", "note": null, "status": "active", "channel": "whatsapp", "sold_at": "2026-11-18T14:54:41.113+00:00", "quantity": 1, "created_at": "2026-11-18T14:54:41.935955+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "sold_total": 10000, "updated_at": "2026-11-18T14:54:41.935955+00:00", "variant_id": "c21395b4-9858-45e9-8e28-12e14ffd86d0", "cancelled_at": null, "cancelled_by": null, "cancel_reason": null, "list_price_unit": 10000}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-18 14:54:41.935955+00
56	categories	6a8f2305-e65c-4f6e-87b0-c52a87724cf6	INSERT	\N	{"id": "6a8f2305-e65c-4f6e-87b0-c52a87724cf6", "name": "Bijoux", "created_at": "2026-11-23T09:18:43.054314+00:00"}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:18:43.054314+00
57	items	c2d3dec9-f8fe-4e9f-a544-64664b33aa63	INSERT	\N	{"id": "c2d3dec9-f8fe-4e9f-a544-64664b33aa63", "code": "ART-0003", "name": "chaine", "order_id": "84cc8db8-541f-4cc2-9ff6-579f2636e9fc", "photo_url": null, "unit_cost": 200, "created_at": "2026-11-23T09:24:18.535724+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 5000, "updated_at": "2026-11-23T09:24:18.535724+00:00", "archived_at": null, "category_id": "6a8f2305-e65c-4f6e-87b0-c52a87724cf6", "description": null, "initial_price": 5000, "received_date": "2026-11-12", "photo_public_id": null}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:24:18.535724+00
58	variants	245ca2d7-91fa-4159-af76-0f24ad25c4e3	INSERT	\N	{"id": "245ca2d7-91fa-4159-af76-0f24ad25c4e3", "label": "Argenté", "item_id": "c2d3dec9-f8fe-4e9f-a544-64664b33aa63", "photo_url": null, "created_at": "2026-11-23T09:24:18.535724+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "updated_at": "2026-11-23T09:24:18.535724+00:00", "archived_at": null, "price_override": null, "photo_public_id": null, "quantity_damaged": 5, "quantity_ordered": 50, "quantity_received": 50}	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:24:18.535724+00
59	items	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	UPDATE	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": null, "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-12T15:40:43.859994+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": null}	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795426241/zadri-luxe/snylisddz5hgk5z41epq.jpg", "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-23T09:30:54.769947+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/snylisddz5hgk5z41epq"}	{photo_url,photo_public_id}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:30:54.769947+00
60	items	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	UPDATE	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795426241/zadri-luxe/snylisddz5hgk5z41epq.jpg", "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-23T09:30:54.769947+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/snylisddz5hgk5z41epq"}	{"id": "f79fef6f-4c9b-4388-a3c6-2b300aa19d97", "code": "ART-0002", "name": "Bracelet OR", "order_id": "f4908e1d-76c5-458f-a1cd-a0642a2c5db6", "photo_url": "https://res.cloudinary.com/dycdqyspf/image/upload/v1795426241/zadri-luxe/snylisddz5hgk5z41epq.jpg", "unit_cost": null, "created_at": "2026-11-12T15:40:43.859994+00:00", "created_by": "f0dae27b-e462-4930-969c-5e63e9c81347", "list_price": 10000, "updated_at": "2026-11-23T09:31:42.910718+00:00", "archived_at": null, "category_id": null, "description": null, "initial_price": 10000, "received_date": "2026-11-12", "photo_public_id": "zadri-luxe/snylisddz5hgk5z41epq"}	{name}	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:31:42.910718+00
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."categories" ("id", "name", "created_at") FROM stdin;
a15d3628-fa48-4507-bbf8-54c5ec5ed948	Montre cuire	2026-10-29 17:30:22.781609+00
6a8f2305-e65c-4f6e-87b0-c52a87724cf6	Bijoux	2026-11-23 09:18:43.054314+00
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."items" ("id", "code", "order_id", "category_id", "name", "description", "photo_url", "photo_public_id", "list_price", "initial_price", "unit_cost", "received_date", "archived_at", "created_by", "created_at", "updated_at") FROM stdin;
9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	ART-0001	f4908e1d-76c5-458f-a1cd-a0642a2c5db6	\N	Mstianq	\N	https://res.cloudinary.com/dycdqyspf/image/upload/v1794497214/zadri-luxe/vrqwy7jpmk0crusjrczw.jpg	zadri-luxe/vrqwy7jpmk0crusjrczw	30000	30000	18000	2026-11-12	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00	2026-11-12 15:38:45.146303+00
c2d3dec9-f8fe-4e9f-a544-64664b33aa63	ART-0003	84cc8db8-541f-4cc2-9ff6-579f2636e9fc	6a8f2305-e65c-4f6e-87b0-c52a87724cf6	chaine	\N	\N	\N	5000	5000	200	2026-11-12	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:24:18.535724+00	2026-11-23 09:24:18.535724+00
f79fef6f-4c9b-4388-a3c6-2b300aa19d97	ART-0002	f4908e1d-76c5-458f-a1cd-a0642a2c5db6	\N	Bracelet OR	\N	https://res.cloudinary.com/dycdqyspf/image/upload/v1795426241/zadri-luxe/snylisddz5hgk5z41epq.jpg	zadri-luxe/snylisddz5hgk5z41epq	10000	10000	\N	2026-11-12	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:40:43.859994+00	2026-11-23 09:31:42.910718+00
\.


--
-- Data for Name: losses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."losses" ("id", "variant_id", "quantity", "reason", "occurred_on", "note", "status", "cancelled_at", "cancelled_by", "cancel_reason", "created_by", "created_at", "updated_at") FROM stdin;
69395a84-174c-44f7-8114-67ef05cbc7b4	c21395b4-9858-45e9-8e28-12e14ffd86d0	1	damaged	2026-11-12	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 16:02:14.065495+00	2026-11-12 16:02:14.065495+00
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."orders" ("id", "reference", "order_date", "supplier", "description", "status", "purchase_amount", "forwarder_fee", "weight_kg", "received_date", "notes", "archived_at", "created_by", "created_at", "updated_at", "origin") FROM stdin;
f4908e1d-76c5-458f-a1cd-a0642a2c5db6	CH-001	2026-11-12	Usine	\N	received	400000	82000	\N	2026-11-12	[Origine: Chine]	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:25:19.705752+00	2026-11-12 15:25:19.705752+00	Chine
84cc8db8-541f-4cc2-9ff6-579f2636e9fc	LOC-001	2026-10-13	5 motres	5 motres	received	150000	30000	\N	2026-11-12	[Origine: Local]	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 17:20:51.39427+00	2026-11-12 17:21:27.49025+00	Local
\.


--
-- Data for Name: price_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."price_changes" ("id", "item_id", "variant_id", "old_price", "new_price", "change_type", "changed_at", "changed_by", "note") FROM stdin;
51b52138-ab90-4ce9-bac7-e5bfeb1a5de3	9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	\N	\N	30000	initial	2026-11-12 15:38:45.146303+00	f0dae27b-e462-4930-969c-5e63e9c81347	Création de l'article
6575f1ac-11d2-431e-a03b-aab765489bf1	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	\N	\N	10000	initial	2026-11-12 15:40:43.859994+00	f0dae27b-e462-4930-969c-5e63e9c81347	Création de l'article
0892c6ff-4078-446d-a177-2d19dbb39c78	c2d3dec9-f8fe-4e9f-a544-64664b33aa63	\N	\N	5000	initial	2026-11-23 09:24:18.535724+00	f0dae27b-e462-4930-969c-5e63e9c81347	Création de l'article
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."profiles" ("id", "full_name", "role", "created_at") FROM stdin;
f0dae27b-e462-4930-969c-5e63e9c81347	POODA Dérick	admin	2026-09-30 15:42:45.38755+00
6bf8f80d-7498-4dd5-89c4-8998aa9cae25	OUEDRAOGO Aziz	admin	2026-09-30 15:42:45.989793+00
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."sales" ("id", "variant_id", "quantity", "list_price_unit", "sold_total", "channel", "sold_at", "note", "status", "cancelled_at", "cancelled_by", "cancel_reason", "created_by", "created_at", "updated_at") FROM stdin;
1d13f325-47d8-44a3-9933-cd23ccf91b10	82a79b04-ec43-4dde-aae3-d72dd0843218	2	30000	58000	direct	2026-11-12 15:52:42.816+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:52:44.050634+00	2026-11-12 15:52:44.050634+00
d5b9a4d9-11e5-445d-92c6-08406245e0a6	a68ed09b-197a-4678-a4f1-05933c9f88d4	1	30000	30000	facebook	2026-11-12 15:54:16.948+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:54:17.43698+00	2026-11-12 15:54:17.43698+00
c9fe4b44-1eae-4672-8878-1c7dc8663779	c21395b4-9858-45e9-8e28-12e14ffd86d0	5	10000	50000	whatsapp	2026-11-12 15:54:45.193+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:54:45.684463+00	2026-11-12 15:54:45.684463+00
c0fd9046-99bb-42d1-afde-3a610c82eb62	c21395b4-9858-45e9-8e28-12e14ffd86d0	1	10000	9000	whatsapp	2026-11-12 15:55:31.945+00	\N	cancelled	2026-11-12 15:55:59.793771+00	f0dae27b-e462-4930-969c-5e63e9c81347	retrour client	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:55:32.429885+00	2026-11-12 15:55:59.793771+00
8718559b-ccc5-41b5-ab0d-79533830364e	c21395b4-9858-45e9-8e28-12e14ffd86d0	1	10000	10000	whatsapp	2026-11-18 14:54:41.113+00	\N	active	\N	\N	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-18 14:54:41.935955+00	2026-11-18 14:54:41.935955+00
\.


--
-- Data for Name: variants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."variants" ("id", "item_id", "label", "photo_url", "photo_public_id", "price_override", "quantity_ordered", "quantity_received", "quantity_damaged", "archived_at", "created_by", "created_at", "updated_at") FROM stdin;
82a79b04-ec43-4dde-aae3-d72dd0843218	9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	Noir	\N	\N	\N	12	12	1	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00	2026-11-12 15:38:45.146303+00
a68ed09b-197a-4678-a4f1-05933c9f88d4	9cdd5bbe-d6e8-46ac-a473-8a9210e859ea	Or	\N	\N	\N	8	8	0	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:38:45.146303+00	2026-11-12 15:38:45.146303+00
245ca2d7-91fa-4159-af76-0f24ad25c4e3	c2d3dec9-f8fe-4e9f-a544-64664b33aa63	Argenté	\N	\N	\N	50	50	5	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-23 09:24:18.535724+00	2026-11-23 09:24:18.535724+00
c21395b4-9858-45e9-8e28-12e14ffd86d0	f79fef6f-4c9b-4388-a3c6-2b300aa19d97	Unique	\N	\N	\N	\N	30	2	\N	f0dae27b-e462-4930-969c-5e63e9c81347	2026-11-12 15:40:43.859994+00	2026-11-23 09:31:43.143843+00
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."audit_log_id_seq"', 60, true);


--
-- Name: item_code_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."item_code_seq"', 3, true);


--
-- Name: order_reference_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."order_reference_seq"', 1, false);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."app_settings"
    ADD CONSTRAINT "app_settings_pkey" PRIMARY KEY ("id");


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."audit_log"
    ADD CONSTRAINT "audit_log_pkey" PRIMARY KEY ("id");


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."categories"
    ADD CONSTRAINT "categories_pkey" PRIMARY KEY ("id");


--
-- Name: items items_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_code_key" UNIQUE ("code");


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_pkey" PRIMARY KEY ("id");


--
-- Name: losses losses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."losses"
    ADD CONSTRAINT "losses_pkey" PRIMARY KEY ("id");


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("id");


--
-- Name: orders orders_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_reference_key" UNIQUE ("reference");


--
-- Name: price_changes price_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_changes"
    ADD CONSTRAINT "price_changes_pkey" PRIMARY KEY ("id");


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."sales"
    ADD CONSTRAINT "sales_pkey" PRIMARY KEY ("id");


--
-- Name: variants variants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."variants"
    ADD CONSTRAINT "variants_pkey" PRIMARY KEY ("id");


--
-- Name: idx_audit_log_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_audit_log_changed_at" ON "public"."audit_log" USING "btree" ("changed_at" DESC);


--
-- Name: idx_audit_log_changed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_audit_log_changed_by" ON "public"."audit_log" USING "btree" ("changed_by");


--
-- Name: idx_audit_log_table_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_audit_log_table_record" ON "public"."audit_log" USING "btree" ("table_name", "record_id");


--
-- Name: idx_items_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_items_category_id" ON "public"."items" USING "btree" ("category_id");


--
-- Name: idx_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_items_order_id" ON "public"."items" USING "btree" ("order_id");


--
-- Name: idx_losses_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_losses_status" ON "public"."losses" USING "btree" ("status");


--
-- Name: idx_losses_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_losses_variant_id" ON "public"."losses" USING "btree" ("variant_id");


--
-- Name: idx_price_changes_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_price_changes_changed_at" ON "public"."price_changes" USING "btree" ("changed_at");


--
-- Name: idx_price_changes_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_price_changes_item_id" ON "public"."price_changes" USING "btree" ("item_id");


--
-- Name: idx_price_changes_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_price_changes_variant_id" ON "public"."price_changes" USING "btree" ("variant_id");


--
-- Name: idx_sales_sold_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_sales_sold_at" ON "public"."sales" USING "btree" ("sold_at");


--
-- Name: idx_sales_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_sales_status" ON "public"."sales" USING "btree" ("status");


--
-- Name: idx_sales_variant_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_sales_variant_id" ON "public"."sales" USING "btree" ("variant_id");


--
-- Name: idx_variants_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_variants_item_id" ON "public"."variants" USING "btree" ("item_id");


--
-- Name: uq_categories_name_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "uq_categories_name_ci" ON "public"."categories" USING "btree" ("lower"("name"));


--
-- Name: uq_variants_item_label_ci; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "uq_variants_item_label_ci" ON "public"."variants" USING "btree" ("item_id", "lower"("label"));


--
-- Name: app_settings trg_audit_app_settings; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_app_settings" AFTER INSERT OR UPDATE ON "public"."app_settings" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: categories trg_audit_categories; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_categories" AFTER INSERT OR UPDATE ON "public"."categories" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: items trg_audit_items; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_items" AFTER INSERT OR UPDATE ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: losses trg_audit_losses; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_losses" AFTER INSERT OR UPDATE ON "public"."losses" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: orders trg_audit_orders; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_orders" AFTER INSERT OR UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: sales trg_audit_sales; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_sales" AFTER INSERT OR UPDATE ON "public"."sales" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: variants trg_audit_variants; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_variants" AFTER INSERT OR UPDATE ON "public"."variants" FOR EACH ROW EXECUTE FUNCTION "public"."fn_audit_trigger"();


--
-- Name: items trg_items_before_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_items_before_update" BEFORE UPDATE ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."fn_items_before_update"();


--
-- Name: items trg_items_code; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_items_code" BEFORE INSERT ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."fn_generate_item_code"();


--
-- Name: items trg_items_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_items_updated_at" BEFORE UPDATE ON "public"."items" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: losses trg_losses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_losses_updated_at" BEFORE UPDATE ON "public"."losses" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: orders trg_orders_reference; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_orders_reference" BEFORE INSERT ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."fn_generate_order_reference"();


--
-- Name: orders trg_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_orders_updated_at" BEFORE UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: sales trg_sales_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_sales_updated_at" BEFORE UPDATE ON "public"."sales" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: variants trg_variants_before_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_variants_before_update" BEFORE UPDATE ON "public"."variants" FOR EACH ROW EXECUTE FUNCTION "public"."fn_variants_before_update"();


--
-- Name: variants trg_variants_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_variants_updated_at" BEFORE UPDATE ON "public"."variants" FOR EACH ROW EXECUTE FUNCTION "public"."fn_set_updated_at"();


--
-- Name: app_settings app_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."app_settings"
    ADD CONSTRAINT "app_settings_updated_by_fkey" FOREIGN KEY ("updated_by") REFERENCES "auth"."users"("id");


--
-- Name: items items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id");


--
-- Name: items items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."items"
    ADD CONSTRAINT "items_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE RESTRICT;


--
-- Name: losses losses_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."losses"
    ADD CONSTRAINT "losses_variant_id_fkey" FOREIGN KEY ("variant_id") REFERENCES "public"."variants"("id");


--
-- Name: price_changes price_changes_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_changes"
    ADD CONSTRAINT "price_changes_item_id_fkey" FOREIGN KEY ("item_id") REFERENCES "public"."items"("id");


--
-- Name: price_changes price_changes_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."price_changes"
    ADD CONSTRAINT "price_changes_variant_id_fkey" FOREIGN KEY ("variant_id") REFERENCES "public"."variants"("id");


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sales sales_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."sales"
    ADD CONSTRAINT "sales_variant_id_fkey" FOREIGN KEY ("variant_id") REFERENCES "public"."variants"("id");


--
-- Name: variants variants_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."variants"
    ADD CONSTRAINT "variants_item_id_fkey" FOREIGN KEY ("item_id") REFERENCES "public"."items"("id") ON DELETE RESTRICT;


--
-- Name: app_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."app_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: app_settings app_settings_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "app_settings_select_authorized" ON "public"."app_settings" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: app_settings app_settings_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "app_settings_update_authorized" ON "public"."app_settings" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."audit_log" ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log audit_log_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "audit_log_select_authorized" ON "public"."audit_log" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."categories" ENABLE ROW LEVEL SECURITY;

--
-- Name: categories categories_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "categories_insert_authorized" ON "public"."categories" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: categories categories_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "categories_select_authorized" ON "public"."categories" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: categories categories_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "categories_update_authorized" ON "public"."categories" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."items" ENABLE ROW LEVEL SECURITY;

--
-- Name: items items_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "items_insert_authorized" ON "public"."items" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: items items_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "items_select_authorized" ON "public"."items" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: items items_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "items_update_authorized" ON "public"."items" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: losses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."losses" ENABLE ROW LEVEL SECURITY;

--
-- Name: losses losses_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "losses_insert_authorized" ON "public"."losses" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: losses losses_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "losses_select_authorized" ON "public"."losses" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: losses losses_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "losses_update_authorized" ON "public"."losses" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."orders" ENABLE ROW LEVEL SECURITY;

--
-- Name: orders orders_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "orders_insert_authorized" ON "public"."orders" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: orders orders_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "orders_select_authorized" ON "public"."orders" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: orders orders_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "orders_update_authorized" ON "public"."orders" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: price_changes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."price_changes" ENABLE ROW LEVEL SECURITY;

--
-- Name: price_changes price_changes_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "price_changes_insert_authorized" ON "public"."price_changes" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: price_changes price_changes_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "price_changes_select_authorized" ON "public"."price_changes" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "profiles_select_authorized" ON "public"."profiles" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: sales; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."sales" ENABLE ROW LEVEL SECURITY;

--
-- Name: sales sales_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "sales_insert_authorized" ON "public"."sales" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: sales sales_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "sales_select_authorized" ON "public"."sales" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: sales sales_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "sales_update_authorized" ON "public"."sales" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- Name: variants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."variants" ENABLE ROW LEVEL SECURITY;

--
-- Name: variants variants_insert_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "variants_insert_authorized" ON "public"."variants" FOR INSERT TO "authenticated" WITH CHECK ("public"."is_authorized_user"());


--
-- Name: variants variants_select_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "variants_select_authorized" ON "public"."variants" FOR SELECT TO "authenticated" USING ("public"."is_authorized_user"());


--
-- Name: variants variants_update_authorized; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "variants_update_authorized" ON "public"."variants" FOR UPDATE TO "authenticated" USING ("public"."is_authorized_user"()) WITH CHECK ("public"."is_authorized_user"());


--
-- PostgreSQL database dump complete
--

\unrestrict fRI5mo1DtDiOtdZYhMjmRgkywSUeKkcdbliEQNvsvLI7K8AaUAgLNGk8Ecs8hoX

